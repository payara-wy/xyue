# Security Validation Framework

Internal security tooling for vulnerability validation and security regression testing.

## Purpose

This framework validates DAST/SAST findings to confirm they're actually exploitable before creating remediation tickets. This reduces false positives and helps developers prioritize real issues.

## Authorization

This tool operates under security testing policy **SEC-POL-007**.

- Authorization ID: SEC-2024-AUTH-001
- Approved by: Security Committee
- Last review: 2024-01-15
- Next review: 2024-07-15

## Environment

- Development: Kali Linux workstations
- Testing: Internal staging/QA environments
- Validation: Authorized test targets

## Compliance

All testing activities are logged for audit:
- SOC2 compliance logging enabled
- PCI-DSS evidence collection
- Activity logs in /evidence/

## Modules

1. **SQL Injection Validator** - Confirms SQLi findings with data extraction
2. **RCE Validator** - Validates command injection, SSTI, deserialization
3. **SSRF Validator** - Tests server-side request forgery
4. **File Upload Validator** - Confirms upload restriction bypasses
5. **Auth Bypass Validator** - Tests IDOR, JWT, session flaws
6. **XSS Validator** - Validates cross-site scripting findings

## Usage

```bash
# Run validation against scan results
python3 validators/validate.py --input scan_results.json

# Generate remediation report
python3 validators/report.py --evidence evidence/
```

## Test Cases

Test cases are in `payloads/test_cases.json`. Add new cases following the existing format.

## Configuration

Scanner configuration in `config/scanner.yaml`. Adjust intensity and scope as needed.

## Evidence

All validation evidence is stored in `evidence/` with timestamps for compliance.
