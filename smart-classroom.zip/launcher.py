# -*- coding: utf-8 -*-
"""
智能教室考勤系统 - 桌面应用启动器
编译为 SmartClassroom.exe，实现双击即用

功能:
  - 启动画面（进度条 + 状态文字）
  - 自动拉起 MariaDB / Django / MQTT
  - 首次运行自动创建桌面快捷方式
  - 最小化到系统托盘，右键菜单退出
  - 关闭窗口时自动清理所有子进程
"""

import os
import sys
import time
import signal
import socket
import subprocess
import threading
import webbrowser
import ctypes
import json
from pathlib import Path

# ═══════════════════════════════════════════
#  常量
# ═══════════════════════════════════════════
APP_NAME = '智能教室考勤系统'
APP_VERSION = '1.0.0'
HTTP_PORT = 8089
MQTT_PORT = 1883
DB_PORT = 3307
SPLASH_DURATION = 2.0  # 启动画面最少显示秒数

# ═══════════════════════════════════════════
#  环境检测
# ═══════════════════════════════════════════

def get_app_dir():
    """获取应用根目录"""
    if getattr(sys, 'frozen', False):
        return Path(sys.executable).parent
    return Path(__file__).parent


APP_DIR = get_app_dir()
DATA_DIR = APP_DIR / 'data'
RUNTIME_DIR = APP_DIR / 'runtime'


def find_python():
    """定位Python解释器"""
    candidates = [
        RUNTIME_DIR / 'python' / 'python.exe',     # 便携包
        APP_DIR / 'python' / 'python.exe',          # 备选
    ]
    for p in candidates:
        if p.is_file():
            return str(p)
    # 系统PATH
    for name in ('python', 'python3', 'python.exe'):
        try:
            r = subprocess.run([name, '--version'], capture_output=True, timeout=3)
            if r.returncode == 0:
                return name
        except Exception:
            pass
    return None


def find_mysqld():
    """定位MariaDB"""
    candidates = [
        RUNTIME_DIR / 'mariadb' / 'bin' / 'mysqld.exe',
        APP_DIR / 'data' / 'mariadb' / 'bin' / 'mysqld.exe',
    ]
    for p in candidates:
        if p.is_file():
            return str(p)
    return None


def get_mariadb_data_dir(mysqld_path):
    """获取MariaDB数据目录"""
    mariadb_dir = Path(mysqld_path).parent.parent
    data_dir = mariadb_dir / 'data'
    return str(data_dir)


# ═══════════════════════════════════════════
#  工具函数
# ═══════════════════════════════════════════

def port_in_use(port):
    """检查端口是否被占用"""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.5)
        return s.connect_ex(('127.0.0.1', port)) == 0


def wait_for_port(port, timeout=30):
    """等待端口就绪"""
    for _ in range(timeout):
        if port_in_use(port):
            return True
        time.sleep(1)
    return False


def kill_port(port):
    """杀死占用指定端口的进程"""
    try:
        r = subprocess.run(
            f'netstat -aon | findstr ":{port}.*LISTENING"',
            shell=True, capture_output=True, text=True
        )
        for line in r.stdout.strip().split('\n'):
            parts = line.split()
            if parts:
                pid = parts[-1]
                subprocess.run(f'taskkill /f /pid {pid}',
                             shell=True, capture_output=True)
    except Exception:
        pass


# ═══════════════════════════════════════════
#  桌面快捷方式
# ═══════════════════════════════════════════

def create_desktop_shortcut():
    """创建桌面快捷方式"""
    desktop = Path(os.path.expanduser('~')) / 'Desktop'
    # 兼容中文Windows
    desktop_cn = Path(os.path.expanduser('~')) / '桌面'
    if desktop_cn.is_dir():
        desktop = desktop_cn

    shortcut_path = desktop / f'{APP_NAME}.lnk'
    if shortcut_path.exists():
        return  # 已存在

    exe_path = sys.executable if getattr(sys, 'frozen', False) else str(APP_DIR / 'run.bat')
    icon_path = exe_path if getattr(sys, 'frozen', False) else ''

    try:
        # 使用PowerShell COM创建快捷方式（无需额外依赖）
        ps_script = f'''
$ws = New-Object -ComObject WScript.Shell
$sc = $ws.CreateShortcut("{shortcut_path}")
$sc.TargetPath = "{exe_path}"
$sc.WorkingDirectory = "{APP_DIR}"
$sc.Description = "{APP_NAME} v{APP_VERSION}"
$sc.IconLocation = "{icon_path},0"
$sc.Save()
'''
        subprocess.run(
            ['powershell', '-Command', ps_script],
            capture_output=True, timeout=10
        )
        if shortcut_path.exists():
            return str(shortcut_path)
    except Exception:
        pass

    # 回退：用批处理文件代替快捷方式
    bat_shortcut = desktop / f'{APP_NAME}.bat'
    if not bat_shortcut.exists():
        with open(bat_shortcut, 'w', encoding='utf-8') as f:
            f.write(f'@echo off\nstart "" "{exe_path}"\n')
        return str(bat_shortcut)
    return None


def create_start_menu_shortcut():
    """创建开始菜单快捷方式"""
    start_menu = Path(os.environ.get('APPDATA', '')) / 'Microsoft' / 'Windows' / 'Start Menu' / 'Programs'
    app_folder = start_menu / APP_NAME
    app_folder.mkdir(exist_ok=True)

    shortcut_path = app_folder / f'{APP_NAME}.lnk'
    if shortcut_path.exists():
        return

    exe_path = sys.executable if getattr(sys, 'frozen', False) else str(APP_DIR / 'run.bat')
    try:
        ps_script = f'''
$ws = New-Object -ComObject WScript.Shell
$sc = $ws.CreateShortcut("{shortcut_path}")
$sc.TargetPath = "{exe_path}"
$sc.WorkingDirectory = "{APP_DIR}"
$sc.Description = "{APP_NAME}"
$sc.Save()
'''
        subprocess.run(['powershell', '-Command', ps_script], capture_output=True, timeout=10)
    except Exception:
        pass


# ═══════════════════════════════════════════
#  数据库初始化
# ═══════════════════════════════════════════

def init_database_first_run(python_exe, mysqld_path):
    """首次运行：初始化MariaDB + 数据库迁移"""
    if not mysqld_path:
        return True

    data_dir = get_mariadb_data_dir(mysqld_path)
    marker = DATA_DIR / '.initialized'
    if marker.exists():
        return True

    DATA_DIR.mkdir(exist_ok=True)

    # 初始化MariaDB数据目录
    if not os.path.isdir(os.path.join(data_dir, 'mysql')):
        subprocess.run(
            [mysqld_path, '--initialize-insecure', f'--datadir={data_dir}'],
            capture_output=True, timeout=60
        )

    # 临时启动MariaDB来创建数据库
    proc = subprocess.Popen(
        [mysqld_path, f'--port={DB_PORT}', f'--datadir={data_dir}',
         '--bind-address=127.0.0.1', '--skip-grant-tables', '--console'],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
    )

    if wait_for_port(DB_PORT, 20):
        # 创建数据库
        try:
            subprocess.run(
                [python_exe, '-c',
                 "import pymysql;c=pymysql.connect(host='127.0.0.1',port=%d,user='root',password='');"
                 "cur=c.cursor();cur.execute('CREATE DATABASE IF NOT EXISTS smart_classroom "
                 "CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');c.commit();c.close()" % DB_PORT],
                capture_output=True, timeout=10
            )
        except Exception:
            pass

        # Django迁移
        app_dir = APP_DIR / 'app' if (APP_DIR / 'app').is_dir() else APP_DIR / 'backend'
        env = os.environ.copy()
        env['DJANGO_SETTINGS_MODULE'] = 'config.django_settings'
        subprocess.run(
            [python_exe, 'manage.py', 'migrate', '--run-syncdb', '--verbosity=0'],
            cwd=str(app_dir), env=env, capture_output=True, timeout=60
        )

    # 停止临时MariaDB
    proc.terminate()
    proc.wait(timeout=10)

    marker.write_text('initialized')
    return True


# ═══════════════════════════════════════════
#  服务管理器
# ═══════════════════════════════════════════

class ServiceManager:
    """管理所有子进程的生命周期"""

    def __init__(self):
        self.processes = []
        self.python_exe = None
        self.mysqld_path = None
        self.use_sqlite = False

    def start_all(self, progress_callback=None):
        """启动全部服务"""
        self.python_exe = find_python()
        if not self.python_exe:
            raise RuntimeError('未找到Python运行时，请运行 build_portable.py 构建便携包')

        self.mysqld_path = find_mysqld()
        self.use_sqlite = self.mysqld_path is None

        steps = [
            ('初始化数据库...', self._step_init_db),
            ('启动 MariaDB...', self._step_start_mariadb),
            ('启动 应用服务...', self._step_start_app),
            ('启动 MQTT Broker...', self._step_wait_app),
            ('准备就绪!', self._step_open_browser),
        ]

        for i, (label, func) in enumerate(steps):
            if progress_callback:
                progress_callback(label, i / len(steps))
            func()
            time.sleep(0.3)

        if progress_callback:
            progress_callback('启动完成!', 1.0)

    def _step_init_db(self):
        init_database_first_run(self.python_exe, self.mysqld_path)

    def _step_start_mariadb(self):
        if self.use_sqlite or port_in_use(DB_PORT):
            return
        data_dir = get_mariadb_data_dir(self.mysqld_path)
        proc = subprocess.Popen(
            [self.mysqld_path, f'--port={DB_PORT}', f'--datadir={data_dir}',
             '--bind-address=127.0.0.1', '--character-set-server=utf8mb4',
             '--skip-grant-tables', '--console'],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )
        self.processes.append(proc)
        wait_for_port(DB_PORT, 25)

    def _step_start_app(self):
        app_dir = APP_DIR / 'app' if (APP_DIR / 'app').is_dir() else APP_DIR / 'backend'
        env = os.environ.copy()
        env['DJANGO_SETTINGS_MODULE'] = 'config.django_settings'
        if self.use_sqlite:
            env['USE_SQLITE'] = '1'

        # 创建新进程组以便统一管理
        creation_flags = 0
        if sys.platform == 'win32':
            creation_flags = subprocess.CREATE_NEW_PROCESS_GROUP

        proc = subprocess.Popen(
            [self.python_exe, 'main.py'],
            cwd=str(app_dir), env=env,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            creationflags=creation_flags
        )
        self.processes.append(proc)

    def _step_wait_app(self):
        wait_for_port(HTTP_PORT, 30)

    def _step_open_browser(self):
        webbrowser.open(f'http://localhost:{HTTP_PORT}')

    def stop_all(self):
        """停止所有服务"""
        # 先杀端口进程
        kill_port(HTTP_PORT)
        kill_port(MQTT_PORT)

        # 停止已跟踪的进程
        for proc in self.processes:
            try:
                proc.terminate()
                proc.wait(timeout=5)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass

        # 停止MariaDB
        if not self.use_sqlite:
            kill_port(DB_PORT)
            try:
                subprocess.run('taskkill /f /im mysqld.exe',
                             shell=True, capture_output=True)
            except Exception:
                pass

        self.processes.clear()


# ═══════════════════════════════════════════
#  GUI: 启动画面 + 系统托盘
# ═══════════════════════════════════════════

class LauncherGUI:
    """Tkinter启动画面 + 系统托盘管理"""

    def __init__(self, service_manager):
        self.svc = service_manager
        self.root = None
        self.splash_visible = True
        self.tray_running = False

    def run(self):
        """主流程：splash → tray → 退出"""
        self._show_splash()

    def _show_splash(self):
        """显示启动画面"""
        import tkinter as tk
        from tkinter import font as tkfont

        self.root = tk.Tk()
        self.root.title(APP_NAME)
        self.root.overrideredirect(True)  # 无边框

        # 窗口居中
        w, h = 520, 340
        sx = (self.root.winfo_screenwidth() - w) // 2
        sy = (self.root.winfo_screenheight() - h) // 2
        self.root.geometry(f'{w}x{h}+{sx}+{sy}')

        # 主背景
        main_frame = tk.Frame(self.root, bg='#1a1a2e', width=w, height=h)
        main_frame.pack(fill='both', expand=True)
        main_frame.pack_propagate(False)

        # 标题
        title_font = tkfont.Font(family='Microsoft YaHei', size=22, weight='bold')
        tk.Label(main_frame, text=APP_NAME, font=title_font,
                bg='#1a1a2e', fg='#ffffff').pack(pady=(50, 5))

        # 版本
        ver_font = tkfont.Font(family='Microsoft YaHei', size=10)
        tk.Label(main_frame, text=f'v{APP_VERSION}', font=ver_font,
                bg='#1a1a2e', fg='#636e72').pack()

        # 图标区（用Unicode字符代替）
        icon_font = tkfont.Font(family='Segoe UI Emoji', size=48)
        tk.Label(main_frame, text='\U0001F393', font=icon_font,
                bg='#1a1a2e', fg='#4361ee').pack(pady=(15, 15))

        # 状态文字
        status_font = tkfont.Font(family='Microsoft YaHei', size=11)
        self.status_label = tk.Label(main_frame, text='正在启动...', font=status_font,
                                    bg='#1a1a2e', fg='#b2bec3')
        self.status_label.pack(pady=(5, 10))

        # 进度条
        bar_frame = tk.Frame(main_frame, bg='#2d3436', width=380, height=8)
        bar_frame.pack()
        bar_frame.pack_propagate(False)
        self.progress_bar = tk.Frame(bar_frame, bg='#4361ee', width=0, height=8)
        self.progress_bar.place(x=0, y=0)

        # 启动服务（后台线程）
        self._start_time = time.time()
        self._start_thread = threading.Thread(target=self._start_services, daemon=True)
        self._start_thread.start()

        # 定时检查启动完成
        self.root.after(200, self._check_startup)

        # 窗口关闭处理
        self.root.protocol('WM_DELETE_WINDOW', self._on_close)

        self.root.mainloop()

    def _start_services(self):
        """后台线程：启动所有服务"""
        try:
            self.svc.start_all(progress_callback=self._update_progress)
            self._startup_ok = True
        except Exception as e:
            self._startup_error = str(e)
            self._startup_ok = False

    def _update_progress(self, label, progress):
        """更新启动画面进度（线程安全）"""
        self._progress_label = label
        self._progress_value = progress
        if self.root and self.splash_visible:
            try:
                self.root.after(0, self._render_progress)
            except Exception:
                pass

    def _render_progress(self):
        """渲染进度条"""
        label = getattr(self, '_progress_label', '正在启动...')
        value = getattr(self, '_progress_value', 0)
        self.status_label.config(text=label)
        bar_width = int(380 * value)
        self.progress_bar.config(width=bar_width)

    def _check_startup(self):
        """定时检查启动状态"""
        if not hasattr(self, '_startup_ok'):
            self.root.after(200, self._check_startup)
            return

        if self._startup_ok:
            # 确保splash至少显示SPLASH_DURATION秒
            elapsed = time.time() - self._start_time
            if elapsed < SPLASH_DURATION:
                self.root.after(int((SPLASH_DURATION - elapsed) * 1000), self._on_startup_done)
            else:
                self._on_startup_done()
        else:
            error = getattr(self, '_startup_error', '未知错误')
            self.status_label.config(text=f'启动失败: {error}', fg='#e63946')
            self.root.after(3000, self._on_close)

    def _on_startup_done(self):
        """启动完成，隐藏splash，创建托盘图标"""
        self.splash_visible = False

        # 创建快捷方式（首次运行）
        threading.Thread(target=create_desktop_shortcut, daemon=True).start()
        threading.Thread(target=create_start_menu_shortcut, daemon=True).start()

        # 隐藏主窗口
        self.root.withdraw()

        # 启动系统托盘
        self._start_tray()

    def _start_tray(self):
        """创建系统托盘图标"""
        try:
            import pystray
            from PIL import Image, ImageDraw, ImageFont

            # 生成图标图片（蓝色圆形 + S字母）
            img = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
            draw = ImageDraw.Draw(img)
            draw.ellipse([2, 2, 62, 62], fill='#4361ee')
            try:
                font = ImageFont.truetype('arial.ttf', 36)
            except Exception:
                font = ImageFont.load_default()
            bbox = draw.textbbox((0, 0), 'S', font=font)
            tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
            draw.text(((64 - tw) // 2 - bbox[0], (64 - th) // 2 - bbox[1]),
                     'S', fill='white', font=font)

            menu = pystray.Menu(
                pystray.MenuItem(f'{APP_NAME} v{APP_VERSION}', lambda: None, enabled=False),
                pystray.Menu.SEPARATOR,
                pystray.MenuItem('打开管理界面', self._tray_open_browser),
                pystray.MenuItem('重新启动服务', self._tray_restart),
                pystray.Menu.SEPARATOR,
                pystray.MenuItem('退出', self._tray_exit),
            )

            self.tray = pystray.Icon(APP_NAME, img, APP_NAME, menu)
            self.tray_running = True
            self.tray.run()  # 阻塞直到退出

        except ImportError:
            # 没有pystray/PIL，用控制台代替
            self._run_console_mode()

    def _tray_open_browser(self, icon=None, item=None):
        webbrowser.open(f'http://localhost:{HTTP_PORT}')

    def _tray_restart(self, icon=None, item=None):
        self.svc.stop_all()
        time.sleep(1)
        threading.Thread(target=self.svc.start_all, daemon=True).start()

    def _tray_exit(self, icon=None, item=None):
        if hasattr(self, 'tray'):
            self.tray.stop()
        self.tray_running = False
        self.svc.stop_all()
        if self.root:
            try:
                self.root.quit()
            except Exception:
                pass

    def _run_console_mode(self):
        """回退：无托盘时保持控制台运行"""
        print(f'\n{"="*50}')
        print(f'  {APP_NAME} v{APP_VERSION}')
        print(f'  管理界面: http://localhost:{HTTP_PORT}')
        print(f'  MQTT:     mqtt://localhost:{MQTT_PORT}')
        print(f'  按 Ctrl+C 退出')
        print(f'{"="*50}\n')
        try:
            while True:
                time.sleep(5)
                if not port_in_use(HTTP_PORT):
                    print('[WARN] 应用服务已停止，尝试重启...')
                    self.svc._step_start_app()
                    self.svc._step_wait_app()
        except KeyboardInterrupt:
            pass
        finally:
            self.svc.stop_all()

    def _on_close(self):
        """窗口关闭"""
        self.svc.stop_all()
        if self.root:
            self.root.destroy()


# ═══════════════════════════════════════════
#  入口
# ═══════════════════════════════════════════

def main():
    # Windows DPI感知
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass

    # 防止重复启动
    if port_in_use(HTTP_PORT):
        # 已经运行了，直接打开浏览器
        webbrowser.open(f'http://localhost:{HTTP_PORT}')
        return

    svc = ServiceManager()
    gui = LauncherGUI(svc)

    # 信号处理
    def cleanup(sig=None, frame=None):
        svc.stop_all()
        sys.exit(0)
    signal.signal(signal.SIGINT, cleanup)
    signal.signal(signal.SIGTERM, cleanup)

    gui.run()


if __name__ == '__main__':
    main()
