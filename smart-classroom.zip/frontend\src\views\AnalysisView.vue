<template>
  <div class="fade-in">
    <div class="page-header">
      <h2>🔥 座位偏好分析</h2>
      <p>分析学生在教室中的座位选择偏好</p>
    </div>

    <div class="controls-bar">
      <select v-model="selectedId" @change="fetchHeatmap">
        <option v-if="!store.classrooms.length" disabled value="">加载中...</option>
        <option v-for="c in store.classrooms" :key="c.id" :value="c.id">
          {{ c.name }}
        </option>
      </select>
      <button class="btn btn-primary" @click="fetchHeatmap" :disabled="loading">
        🔄 刷新
      </button>
    </div>

    <div v-if="loading" class="loading">
      <div class="spinner"></div>
    </div>

    <template v-else-if="heatmapData">
      <!-- Preference tags -->
      <div class="preference-tags" v-if="heatmapData.zones">
        <div
          v-for="(pref, key) in zonePreferences"
          :key="key"
          class="preference-tag"
        >
          {{ pref }}
        </div>
      </div>

      <!-- Zone analysis -->
      <div class="zone-analysis" v-if="heatmapData.zones">
        <div class="zone-card">
          <h4>📍 前后分布</h4>
          <div v-for="zone in rowZones" :key="zone.label" class="zone-bar-item">
            <div class="zone-bar-label">
              <span>{{ zone.label }}</span>
              <span>{{ zone.count }}次</span>
            </div>
            <div class="zone-bar">
              <div
                class="zone-bar-fill"
                :class="zone.cls"
                :style="{ width: zone.percent + '%' }"
              ></div>
            </div>
          </div>
        </div>

        <div class="zone-card">
          <h4>📍 左右分布</h4>
          <div v-for="zone in colZones" :key="zone.label" class="zone-bar-item">
            <div class="zone-bar-label">
              <span>{{ zone.label }}</span>
              <span>{{ zone.count }}次</span>
            </div>
            <div class="zone-bar">
              <div
                class="zone-bar-fill"
                :class="zone.cls"
                :style="{ width: zone.percent + '%' }"
              ></div>
            </div>
          </div>
        </div>
      </div>

      <!-- Heatmap -->
      <div class="card">
        <div class="card-title">座位使用热力图</div>
        <HeatMap
          :rows="heatmapData.grid ? heatmapData.grid.length : 0"
          :cols="heatmapData.grid && heatmapData.grid[0] ? heatmapData.grid[0].length : 0"
          :grid="heatmapData.grid"
          :max-count="heatmapData.max_count || 1"
        />
      </div>
    </template>

    <div v-else class="empty-state">
      <div class="empty-state-icon">🔥</div>
      <div class="empty-state-text">请选择教室查看偏好分析</div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useAppStore } from '../stores'
import { getHeatmap } from '../api'
import HeatMap from '../components/HeatMap.vue'

const store = useAppStore()
const selectedId = ref(store.selectedClassroomId)
const heatmapData = ref(null)
const loading = ref(false)

async function fetchHeatmap() {
  if (!selectedId.value) return
  loading.value = true
  try {
    const res = await getHeatmap(selectedId.value)
    heatmapData.value = res.data
    store.selectedClassroomId = selectedId.value
  } catch (e) {
    console.error('Failed to fetch heatmap:', e)
    heatmapData.value = null
  } finally {
    loading.value = false
  }
}

const zonePreferences = computed(() => {
  if (!heatmapData.value || !heatmapData.value.zones) return []
  const zones = heatmapData.value.zones
  const tags = []
  if (zones.row_preference) tags.push(`行偏好: ${zones.row_preference}`)
  if (zones.col_preference) tags.push(`列偏好: ${zones.col_preference}`)
  if (zones.preferred_zone) tags.push(`偏好区域: ${zones.preferred_zone}`)
  return tags
})

const rowZones = computed(() => {
  if (!heatmapData.value || !heatmapData.value.zones) return []
  const z = heatmapData.value.zones
  const maxVal = Math.max(z.front || 0, z.middle || 0, z.back || 0, 1)
  return [
    { label: '前排', count: z.front || 0, percent: ((z.front || 0) / maxVal) * 100, cls: 'front' },
    { label: '中排', count: z.middle || 0, percent: ((z.middle || 0) / maxVal) * 100, cls: 'middle' },
    { label: '后排', count: z.back || 0, percent: ((z.back || 0) / maxVal) * 100, cls: 'back' }
  ]
})

const colZones = computed(() => {
  if (!heatmapData.value || !heatmapData.value.zones) return []
  const z = heatmapData.value.zones
  const maxVal = Math.max(z.left || 0, z.center || 0, z.right || 0, 1)
  return [
    { label: '左侧', count: z.left || 0, percent: ((z.left || 0) / maxVal) * 100, cls: 'left' },
    { label: '中间', count: z.center || 0, percent: ((z.center || 0) / maxVal) * 100, cls: 'center' },
    { label: '右侧', count: z.right || 0, percent: ((z.right || 0) / maxVal) * 100, cls: 'right' }
  ]
})

onMounted(() => {
  if (selectedId.value) {
    fetchHeatmap()
  }
})
</script>
