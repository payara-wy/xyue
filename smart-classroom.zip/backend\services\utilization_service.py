# -*- coding: utf-8 -*-
"""利用率服务 - 教室利用率、时段分析、对比排名"""

from datetime import timedelta
from django.utils import timezone
from django.db.models import Count, Q, F, Avg

from core.models import Classroom, Course, AttendanceRecord


# 标准时间段定义
TIME_SLOTS = [
    {'label': '第1-2节', 'start': '08:00', 'end': '09:40'},
    {'label': '第3-4节', 'start': '10:00', 'end': '11:40'},
    {'label': '第5-6节', 'start': '14:00', 'end': '15:40'},
    {'label': '第7-8节', 'start': '16:00', 'end': '17:40'},
    {'label': '第9-10节', 'start': '19:00', 'end': '20:40'},
]

WEEKDAY_LABELS = {1: '周一', 2: '周二', 3: '周三', 4: '周四', 5: '周五', 6: '周六', 7: '周日'}


class UtilizationService:
    """教室利用率相关业务逻辑"""

    @staticmethod
    def get_classroom_utilization(classroom_id, date_from=None, date_to=None):
        """
        获取单个教室的利用率详情
        按时间段和星期几分组统计
        """
        classroom = Classroom.objects.get(id=classroom_id)

        # 默认查询最近30天
        if not date_to:
            date_to = timezone.now().date()
        if not date_from:
            date_from = date_to - timedelta(days=30)

        # 查询该教室在日期范围内的所有课程
        courses = Course.objects.filter(classroom=classroom)

        # 查询考勤记录
        records = AttendanceRecord.objects.filter(
            course__classroom=classroom,
            course_date__gte=date_from,
            course_date__lte=date_to,
            status__in=['present', 'late'],
        ).values(
            'course__weekday', 'course__start_time', 'course__end_time',
        ).annotate(
            avg_count=Avg('seat_row'),  # 占位，下面用更好的方式
            total=Count('id'),
        )

        # 按星期统计课程数和出勤人次
        weekday_stats = {}
        for wd in range(1, 8):
            day_courses = courses.filter(weekday=wd)
            day_records = AttendanceRecord.objects.filter(
                course__in=day_courses,
                course_date__gte=date_from,
                course_date__lte=date_to,
                status__in=['present', 'late'],
            )
            weekday_stats[WEEKDAY_LABELS[wd]] = {
                'weekday': wd,
                'course_count': day_courses.count(),
                'total_attendance': day_records.count(),
            }

        # 按时段统计
        # 获取该教室所有课程的开始时间，映射到时段
        slot_stats = []
        all_courses = courses.values('start_time', 'end_time', 'weekday')
        course_list = list(all_courses)

        for slot in TIME_SLOTS:
            slot_courses = [
                c for c in course_list
                if slot['start'] <= str(c['start_time'])[:5] <= slot['end']
            ]
            # 统计该时段课程的考勤人数
            if slot_courses:
                course_ids = courses.filter(
                    start_time__gte=slot['start'],
                    start_time__lte=slot['end'],
                ).values_list('id', flat=True)
                attendance_count = AttendanceRecord.objects.filter(
                    course_id__in=course_ids,
                    course_date__gte=date_from,
                    course_date__lte=date_to,
                    status__in=['present', 'late'],
                ).count()
            else:
                attendance_count = 0

            slot_stats.append({
                'label': slot['label'],
                'start': slot['start'],
                'end': slot['end'],
                'course_count': len(slot_courses),
                'total_attendance': attendance_count,
            })

        # 总体利用率计算
        # 总课程节次 * 教室座位数 = 最大容量，实际出勤人次 / 最大容量
        total_seats = classroom.total_seats
        total_course_sessions = courses.count()  # 每周课程数
        # 计算日期范围内的周数
        days_diff = (date_to - date_from).days
        weeks = max(days_diff / 7, 1)

        total_capacity = int(total_course_sessions * weeks * total_seats)
        total_actual = AttendanceRecord.objects.filter(
            course__classroom=classroom,
            course_date__gte=date_from,
            course_date__lte=date_to,
            status__in=['present', 'late'],
        ).count()

        overall_rate = round(total_actual / total_capacity * 100, 1) if total_capacity > 0 else 0

        return {
            'classroom_id': classroom.id,
            'classroom_name': str(classroom),
            'total_seats': total_seats,
            'date_from': date_from.isoformat(),
            'date_to': date_to.isoformat(),
            'weeks': round(weeks, 1),
            'overall_utilization_rate': overall_rate,
            'total_attendance': total_actual,
            'total_capacity': total_capacity,
            'weekday_breakdown': weekday_stats,
            'time_slot_breakdown': slot_stats,
        }

    @staticmethod
    def compare_all_classrooms(date_from=None, date_to=None):
        """
        对比所有教室的利用率并排名
        """
        if not date_to:
            date_to = timezone.now().date()
        if not date_from:
            date_from = date_to - timedelta(days=30)

        classrooms = Classroom.objects.all()
        results = []

        for classroom in classrooms:
            courses = Course.objects.filter(classroom=classroom)
            total_seats = classroom.total_seats
            total_course_sessions = courses.count()

            days_diff = (date_to - date_from).days
            weeks = max(days_diff / 7, 1)
            total_capacity = int(total_course_sessions * weeks * total_seats)

            total_actual = AttendanceRecord.objects.filter(
                course__classroom=classroom,
                course_date__gte=date_from,
                course_date__lte=date_to,
                status__in=['present', 'late'],
            ).count()

            rate = round(total_actual / total_capacity * 100, 1) if total_capacity > 0 else 0

            results.append({
                'classroom_id': classroom.id,
                'classroom_name': str(classroom),
                'building': classroom.building,
                'total_seats': total_seats,
                'course_count': total_course_sessions,
                'total_attendance': total_actual,
                'total_capacity': total_capacity,
                'utilization_rate': rate,
            })

        # 按利用率降序排列
        results.sort(key=lambda x: x['utilization_rate'], reverse=True)

        # 添加排名
        for i, item in enumerate(results):
            item['rank'] = i + 1

        avg_rate = round(
            sum(r['utilization_rate'] for r in results) / len(results), 1
        ) if results else 0

        return {
            'date_from': date_from.isoformat(),
            'date_to': date_to.isoformat(),
            'total_classrooms': len(results),
            'average_utilization_rate': avg_rate,
            'classrooms': results,
        }
