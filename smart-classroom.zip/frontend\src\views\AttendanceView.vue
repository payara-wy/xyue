<template>
  <div class="fade-in">
    <div class="page-header">
      <h2>📋 考勤统计</h2>
      <p>查看每日考勤数据与课程出勤详情</p>
    </div>

    <div class="controls-bar">
      <input type="date" v-model="selectedDate" />
      <button class="btn btn-primary" @click="fetchDailySummary" :disabled="loading">
        🔍 查询
      </button>
    </div>

    <div v-if="loading" class="loading">
      <div class="spinner"></div>
    </div>

    <template v-else>
      <!-- Overview stats -->
      <div class="stats-row" v-if="summary">
        <StatsCard icon="📊" :value="summary.total_records || 0" label="总记录" color="blue" />
        <StatsCard icon="✅" :value="summary.present || 0" label="出勤" color="green" />
        <StatsCard icon="⏰" :value="summary.late || 0" label="迟到" color="yellow" />
        <StatsCard icon="🚪" :value="summary.early_leave || 0" label="早退" color="yellow" />
        <StatsCard icon="❌" :value="summary.absent || 0" label="缺勤" color="red" />
      </div>

      <!-- Course attendance table -->
      <div class="card" v-if="summary && summary.courses && summary.courses.length">
        <div class="card-title">课程考勤概览</div>
        <div class="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>课程名称</th>
                <th>教师</th>
                <th>教室</th>
                <th>时间</th>
                <th>出勤</th>
                <th>迟到</th>
                <th>早退</th>
                <th>缺勤</th>
                <th>出勤率</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="course in summary.courses" :key="course.course_id || course.course_name">
                <td>{{ course.course_name }}</td>
                <td>{{ course.teacher }}</td>
                <td>{{ course.classroom }}</td>
                <td>{{ course.time_slot || '-' }}</td>
                <td>{{ course.present || 0 }}</td>
                <td>{{ course.late || 0 }}</td>
                <td>{{ course.early_leave || 0 }}</td>
                <td>{{ course.absent || 0 }}</td>
                <td>
                  <div style="display:flex;align-items:center;gap:8px;">
                    <div class="progress-bar" style="flex:1;">
                      <div
                        class="fill"
                        :class="getProgressColor(course.attendance_rate)"
                        :style="{ width: (course.attendance_rate * 100).toFixed(0) + '%' }"
                      ></div>
                    </div>
                    <span style="font-size:12px;white-space:nowrap;">
                      {{ (course.attendance_rate * 100).toFixed(1) }}%
                    </span>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Course detail section -->
      <div class="card">
        <div class="card-title">课程考勤详情</div>
        <div class="controls-bar" style="margin-bottom:16px;">
          <select v-model="detailCourseId" @change="fetchCourseAttendance">
            <option value="">选择课程</option>
            <option v-for="c in store.courses" :key="c.id" :value="c.id">
              {{ c.name }}
            </option>
          </select>
        </div>

        <div v-if="courseLoading" class="loading">
          <div class="spinner"></div>
        </div>

        <div v-else-if="courseAttendance && courseAttendance.records && courseAttendance.records.length" class="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>学号</th>
                <th>姓名</th>
                <th>班级</th>
                <th>状态</th>
                <th>座位</th>
                <th>签到时间</th>
                <th>签退时间</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="rec in courseAttendance.records" :key="rec.student_id">
                <td>{{ rec.student_id }}</td>
                <td>{{ rec.student_name }}</td>
                <td>{{ rec.class_name || '-' }}</td>
                <td>
                  <StatusTag :status="rec.status" />
                </td>
                <td>{{ rec.seat_position || '-' }}</td>
                <td>{{ rec.check_in_time || '-' }}</td>
                <td>{{ rec.check_out_time || '-' }}</td>
              </tr>
            </tbody>
          </table>
        </div>

        <div v-else-if="detailCourseId" class="empty-state">
          <div class="empty-state-text">暂无考勤数据</div>
        </div>
      </div>
    </template>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useAppStore } from '../stores'
import { getDailySummary, getCourseAttendance } from '../api'
import StatsCard from '../components/StatsCard.vue'
import StatusTag from '../components/StatusTag.vue'

const store = useAppStore()

const today = new Date().toISOString().split('T')[0]
const selectedDate = ref(today)
const summary = ref(null)
const loading = ref(false)
const detailCourseId = ref('')
const courseAttendance = ref(null)
const courseLoading = ref(false)

async function fetchDailySummary() {
  loading.value = true
  try {
    const res = await getDailySummary(selectedDate.value)
    summary.value = res.data
  } catch (e) {
    console.error('Failed to fetch daily summary:', e)
    summary.value = null
  } finally {
    loading.value = false
  }
}

async function fetchCourseAttendance() {
  if (!detailCourseId.value) return
  courseLoading.value = true
  try {
    const res = await getCourseAttendance(detailCourseId.value, selectedDate.value)
    courseAttendance.value = res.data
  } catch (e) {
    console.error('Failed to fetch course attendance:', e)
    courseAttendance.value = null
  } finally {
    courseLoading.value = false
  }
}

function getProgressColor(rate) {
  if (rate >= 0.9) return 'green'
  if (rate >= 0.7) return 'yellow'
  return 'red'
}

onMounted(() => {
  fetchDailySummary()
})
</script>
