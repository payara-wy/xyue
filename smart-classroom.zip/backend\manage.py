#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Django管理脚本"""

import os
import sys

if __name__ == '__main__':
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.django_settings')
    from django.core.management import execute_from_command_line
    execute_from_command_line(sys.argv)
