# -*- coding: utf-8 -*-
"""下载并配置内嵌MariaDB Portable"""

import os
import sys
import zipfile
import urllib.request
import shutil

# 路径配置
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, 'data')
MARIADB_DIR = os.path.join(DATA_DIR, 'mariadb')

# MariaDB 10.11 LTS Windows x64 ZIP
MARIADB_URL = 'https://dlm.mariadb.com/3740826/MariaDB/mariadb-10.11.10/winx64-packages/mariadb-10.11.10-winx64.zip'
MARIADB_ZIP = os.path.join(DATA_DIR, 'mariadb-download.zip')


def download_mariadb():
    """下载MariaDB Portable"""
    os.makedirs(DATA_DIR, exist_ok=True)

    if os.path.isdir(MARIADB_DIR):
        print(f'MariaDB目录已存在: {MARIADB_DIR}')
        resp = input('是否重新下载? (y/N): ').strip().lower()
        if resp != 'y':
            return True

    print(f'正在下载MariaDB...')
    print(f'URL: {MARIADB_URL}')
    print(f'目标: {MARIADB_ZIP}')
    print('（约200MB，请耐心等待）\n')

    try:
        def report_progress(block_num, block_size, total_size):
            downloaded = block_num * block_size
            if total_size > 0:
                pct = min(100, downloaded * 100 // total_size)
                mb = downloaded / (1024 * 1024)
                total_mb = total_size / (1024 * 1024)
                print(f'\r  下载进度: {pct}% ({mb:.1f}/{total_mb:.1f} MB)', end='', flush=True)

        urllib.request.urlretrieve(MARIADB_URL, MARIADB_ZIP, report_progress)
        print('\n  下载完成!')
    except Exception as e:
        print(f'\n  下载失败: {e}')
        print('  请手动下载并解压到:', MARIADB_DIR)
        return False

    return True


def extract_mariadb():
    """解压MariaDB"""
    if not os.path.isfile(MARIADB_ZIP):
        print('ZIP文件不存在，请先下载')
        return False

    print('正在解压...')

    # 清理旧目录
    if os.path.isdir(MARIADB_DIR):
        shutil.rmtree(MARIADB_DIR)

    # 解压
    with zipfile.ZipFile(MARIADB_ZIP, 'r') as z:
        z.extractall(DATA_DIR)

    # 找到解压后的目录（通常有一个版本号的子目录）
    for item in os.listdir(DATA_DIR):
        item_path = os.path.join(DATA_DIR, item)
        if os.path.isdir(item_path) and item.startswith('mariadb-') and item != 'mariadb':
            os.rename(item_path, MARIADB_DIR)
            break

    # 验证
    mysqld = os.path.join(MARIADB_DIR, 'bin', 'mysqld.exe')
    if os.path.isfile(mysqld):
        print(f'MariaDB已安装到: {MARIADB_DIR}')
        return True
    else:
        print('解压后未找到 mysqld.exe，请检查目录结构')
        return False


def init_data_dir():
    """初始化MariaDB数据目录"""
    data_dir = os.path.join(MARIADB_DIR, 'data')
    if os.path.isdir(data_dir) and os.listdir(data_dir):
        print('数据目录已存在，跳过初始化')
        return True

    print('正在初始化MariaDB数据目录...')
    mysqld = os.path.join(MARIADB_DIR, 'bin', 'mysqld.exe')

    import subprocess
    result = subprocess.run(
        [mysqld, '--initialize-insecure', f'--datadir={data_dir}'],
        capture_output=True, text=True, timeout=60
    )

    if result.returncode == 0:
        print('数据目录初始化完成')
        return True
    else:
        print(f'初始化失败: {result.stderr}')
        return False


def main():
    print('=' * 50)
    print('  MariaDB 内嵌数据库安装向导')
    print('=' * 50 + '\n')

    if download_mariadb() and extract_mariadb() and init_data_dir():
        print('\n安装完成！')
        print(f'MariaDB路径: {MARIADB_DIR}')
        print(f'启动命令: python backend/main.py')

        # 清理ZIP文件
        if os.path.isfile(MARIADB_ZIP):
            os.remove(MARIADB_ZIP)
            print('已清理下载的ZIP文件')
    else:
        print('\n安装过程中出现错误，请检查日志')


if __name__ == '__main__':
    main()
