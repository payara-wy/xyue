# -*- coding: utf-8 -*-
"""种子数据生成器 - 填充演示用模拟数据"""

import random
from datetime import datetime, timedelta, time, date
import logging

logger = logging.getLogger(__name__)

SURNAMES = list('张李王刘陈杨黄赵吴周徐孙马朱胡')
GIVEN_NAMES = ['伟', '芳', '娜', '秀英', '敏', '静', '丽', '强', '磊', '洋', '勇', '艳', '杰', '涛', '明',
               '超', '秀兰', '霞', '平', '刚', '桂英', '文', '华', '军', '玲', '婷', '宇', '飞', '鑫', '浩']
COURSE_DATA = [
    ('高等数学', 'MATH101'), ('线性代数', 'MATH201'), ('大学物理', 'PHY101'),
    ('程序设计基础', 'CS101'), ('数据结构', 'CS201'), ('计算机网络', 'CS301'),
    ('英语听说', 'ENG101'), ('概率论', 'MATH301'), ('操作系统', 'CS302'),
    ('人工智能导论', 'CS401'), ('数据库原理', 'CS303'), ('软件工程', 'CS402'),
]
TEACHERS = ['王教授', '李教授', '张教授', '陈教授', '刘教授', '赵教授', '周教授', '吴教授']
CLASSROOM_DATA = [
    ('A101', '教学楼A', 8, 10), ('A102', '教学楼A', 6, 12), ('A201', '教学楼A', 8, 10),
    ('A202', '教学楼A', 10, 8), ('B101', '教学楼B', 8, 10), ('B102', '教学楼B', 6, 8),
    ('B201', '教学楼B', 8, 12), ('B301', '教学楼B', 10, 10),
    ('C101', '实验楼C', 6, 8), ('C201', '实验楼C', 8, 8),
]
CLASS_NAMES = ['计算机2301班', '计算机2302班', '数学2301班', '电子2301班', '软件2301班']
TIME_SLOTS = [
    (time(8, 0), time(9, 40)), (time(10, 0), time(11, 40)),
    (time(14, 0), time(15, 40)), (time(16, 0), time(17, 40)),
    (time(19, 0), time(20, 40)),
]


def seed_database():
    """填充数据库演示数据"""
    from core.models import Classroom, Course, Student, SeatOccupancy, AttendanceRecord, DeviceStatus, Alert

    if Classroom.objects.exists():
        logger.info('数据库已有数据，跳过种子数据填充')
        return

    logger.info('开始填充种子数据...')

    # 1. 教室
    classrooms = []
    for name, building, rows, cols in CLASSROOM_DATA:
        cr = Classroom.objects.create(
            name=name, building=building,
            rows_count=rows, cols_count=cols, has_projector=True
        )
        classrooms.append(cr)
    logger.info(f'  创建 {len(classrooms)} 个教室')

    # 2. 学生（60人）
    students = []
    for i in range(60):
        s = Student.objects.create(
            student_id=f'STU2023{i+1:04d}',
            name=random.choice(SURNAMES) + random.choice(GIVEN_NAMES),
            class_name=random.choice(CLASS_NAMES),
            beacon_id=f'BEACON{i+1:04d}'
        )
        students.append(s)
    logger.info(f'  创建 {len(students)} 名学生')

    # 3. 课程
    courses = []
    for (cname, ccode) in COURSE_DATA:
        c = Course.objects.create(
            name=cname, course_code=ccode,
            teacher=random.choice(TEACHERS),
            classroom=random.choice(classrooms[:8]),
            weekday=random.randint(1, 5),
            start_time=random.choice(TIME_SLOTS)[0],
            end_time=random.choice(TIME_SLOTS)[1],
        )
        courses.append(c)
    logger.info(f'  创建 {len(courses)} 门课程')

    # 4. 最近7天的座位占用和考勤记录
    today = date.today()
    occupancy_count = 0
    attendance_count = 0

    for day_offset in range(7):
        d = today - timedelta(days=day_offset)
        weekday = d.isoweekday()

        for course in courses:
            if course.weekday != weekday:
                continue

            cr = course.classroom
            # 出勤率 80%-95%
            course_students = random.sample(students, k=int(len(students) * random.uniform(0.8, 0.95)))
            start_dt = datetime.combine(d, course.start_time)

            for student in course_students:
                r = random.random()
                if r < 0.75:
                    status = 'present'
                    late_min = random.randint(-15, -1)
                elif r < 0.88:
                    status = 'late'
                    late_min = random.randint(1, 15)
                elif r < 0.95:
                    status = 'early_leave'
                    late_min = random.randint(-10, -1)
                else:
                    status = 'absent'
                    late_min = 0

                check_in = None
                check_out = None
                seat_r = random.randint(0, cr.rows_count - 1)
                seat_c = random.randint(0, cr.cols_count - 1)

                if status != 'absent':
                    check_in = start_dt + timedelta(minutes=late_min)
                    end_dt = datetime.combine(d, course.end_time)
                    if status == 'early_leave':
                        check_out = end_dt - timedelta(minutes=random.randint(10, 30))
                    else:
                        check_out = end_dt + timedelta(minutes=random.randint(-5, 5))

                    SeatOccupancy.objects.create(
                        classroom=cr, row_num=seat_r, col_num=seat_c,
                        is_occupied=True, student_id=student.student_id,
                        source='simulator', timestamp=check_in
                    )
                    occupancy_count += 1

                AttendanceRecord.objects.create(
                    course=course, student=student, status=status,
                    seat_row=seat_r, seat_col=seat_c,
                    check_in_time=check_in, check_out_time=check_out,
                    course_date=d
                )
                attendance_count += 1

    logger.info(f'  创建 {occupancy_count} 条座位占用记录')
    logger.info(f'  创建 {attendance_count} 条考勤记录')

    # 5. 设备状态
    device_count = 0
    for cr in classrooms:
        for dtype in ['projector', 'light', 'ac']:
            DeviceStatus.objects.create(
                classroom=cr, device_type=dtype,
                is_on=random.choice([True, False])
            )
            device_count += 1
    logger.info(f'  创建 {device_count} 个设备状态记录')

    # 6. 告警记录
    alert_templates = [
        ('energy', '教室无人但投影仪处于开启状态，建议关闭以节约能源', 'warning'),
        ('energy', '教室无人但灯光系统仍开启，建议关闭', 'warning'),
        ('absence', '当前课程出勤率低于80%，请关注', 'info'),
        ('device', '设备运行时间超过8小时，请检查是否需要维护', 'critical'),
    ]
    alert_count = 0
    for _ in range(20):
        cr = random.choice(classrooms)
        atype, msg, sev = random.choice(alert_templates)
        created = datetime.now() - timedelta(hours=random.randint(1, 168))
        resolved = random.choice([True, False])
        resolved_at = None
        if resolved:
            resolved_at = created + timedelta(hours=random.randint(1, 4))
        Alert.objects.create(
            classroom=cr, alert_type=atype, message=msg, severity=sev,
            is_resolved=resolved, resolved_at=resolved_at
        )
        alert_count += 1
    logger.info(f'  创建 {alert_count} 条告警记录')

    logger.info('种子数据填充完成！')
