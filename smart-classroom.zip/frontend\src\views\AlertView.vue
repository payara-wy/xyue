<template>
  <div class="fade-in">
    <div class="page-header">
      <h2>🔔 告警与设备控制</h2>
      <p>查看系统告警并管理教室设备</p>
    </div>

    <div class="controls-bar">
      <button class="btn btn-primary" @click="runDetection" :disabled="actionLoading">
        🔍 执行异常检测
      </button>
      <button class="btn btn-success" @click="resolveAll" :disabled="actionLoading">
        ✅ 全部标记已解决
      </button>
      <button class="btn btn-outline" @click="fetchAllData">
        🔄 刷新
      </button>
    </div>

    <div v-if="loading" class="loading">
      <div class="spinner"></div>
    </div>

    <template v-else>
      <!-- Alert stats -->
      <div class="stats-row">
        <StatsCard icon="🚨" :value="alertStats.active || 0" label="活跃告警" color="red" />
        <StatsCard icon="✅" :value="alertStats.resolved || 0" label="已解决" color="green" />
        <StatsCard icon="📊" :value="alertStats.total || 0" label="总告警" color="blue" />
        <StatsCard icon="⚡" :value="energyAlerts" label="能耗告警" color="yellow" />
      </div>

      <!-- Alert list -->
      <div class="card">
        <div class="card-title">告警列表</div>
        <div class="alert-list" v-if="alerts.length">
          <div class="alert-item" v-for="alert in alerts" :key="alert.id">
            <div class="alert-dot" :class="getSeverityClass(alert.severity)"></div>
            <div class="alert-content">
              <div class="alert-message">{{ alert.message || alert.title || '未知告警' }}</div>
              <div class="alert-meta">
                <span v-if="alert.classroom_name">📍 {{ alert.classroom_name }}</span>
                <span v-if="alert.alert_type">🏷️ {{ alert.alert_type }}</span>
                <span v-if="alert.created_at">🕐 {{ formatDate(alert.created_at) }}</span>
                <StatusTag :severity="alert.status || alert.severity" />
              </div>
            </div>
            <div class="alert-actions" v-if="alert.status !== 'resolved'">
              <button class="btn btn-sm btn-outline" @click="resolveOne(alert.id)">
                解决
              </button>
            </div>
          </div>
        </div>
        <div v-else class="empty-state">
          <div class="empty-state-icon">✅</div>
          <div class="empty-state-text">暂无活跃告警</div>
        </div>
      </div>

      <!-- Device control -->
      <div class="card">
        <div class="card-title">设备控制</div>
        <div class="device-grid" v-if="devices.length">
          <div class="device-card" v-for="device in devices" :key="`${device.classroom_id}-${device.device_type}`">
            <div class="device-card-header">
              <div>
                <div class="device-card-title">{{ getDeviceIcon(device.device_type) }} {{ getDeviceName(device.device_type) }}</div>
                <div class="device-card-subtitle">{{ device.classroom_name || `教室 ${device.classroom_id}` }}</div>
              </div>
              <label class="toggle-switch">
                <input
                  type="checkbox"
                  :checked="device.is_on"
                  @change="toggleDevice(device)"
                />
                <span class="toggle-slider"></span>
              </label>
            </div>
            <div style="font-size:12px;color:var(--gray-500);">
              状态: {{ device.is_on ? '开启' : '关闭' }}
            </div>
          </div>
        </div>
        <div v-else class="empty-state">
          <div class="empty-state-icon">🔌</div>
          <div class="empty-state-text">暂无设备数据</div>
        </div>
      </div>
    </template>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import {
  getAlerts,
  getAlertStatistics,
  resolveAlert,
  resolveAllAlerts,
  runDetection as runDetectionApi,
  getDevices,
  toggleDevice as toggleDeviceApi
} from '../api'
import StatsCard from '../components/StatsCard.vue'
import StatusTag from '../components/StatusTag.vue'

const alerts = ref([])
const alertStats = ref({})
const devices = ref([])
const loading = ref(false)
const actionLoading = ref(false)

const energyAlerts = computed(() => {
  if (!alertStats.value || !alertStats.value.by_type) return 0
  return alertStats.value.by_type.energy || alertStats.value.by_type['energy'] || 0
})

async function fetchAllData() {
  loading.value = true
  try {
    const [alertsRes, statsRes, devicesRes] = await Promise.all([
      getAlerts(),
      getAlertStatistics(),
      getDevices()
    ])
    alerts.value = alertsRes.data || []
    alertStats.value = statsRes.data || {}
    devices.value = devicesRes.data || []
  } catch (e) {
    console.error('Failed to fetch alert data:', e)
  } finally {
    loading.value = false
  }
}

async function resolveOne(id) {
  try {
    await resolveAlert(id)
    await fetchAllData()
  } catch (e) {
    console.error('Failed to resolve alert:', e)
  }
}

async function resolveAll() {
  actionLoading.value = true
  try {
    await resolveAllAlerts()
    await fetchAllData()
  } catch (e) {
    console.error('Failed to resolve all:', e)
  } finally {
    actionLoading.value = false
  }
}

async function runDetection() {
  actionLoading.value = true
  try {
    await runDetectionApi()
    await fetchAllData()
  } catch (e) {
    console.error('Failed to run detection:', e)
  } finally {
    actionLoading.value = false
  }
}

async function toggleDevice(device) {
  try {
    await toggleDeviceApi({
      classroom_id: device.classroom_id,
      device_type: device.device_type,
      is_on: !device.is_on
    })
    device.is_on = !device.is_on
  } catch (e) {
    console.error('Failed to toggle device:', e)
  }
}

function getSeverityClass(severity) {
  if (severity === 'critical') return 'critical'
  if (severity === 'warning') return 'warning'
  return 'info'
}

function getDeviceName(type) {
  const map = {
    projector: '投影仪',
    light: '灯光',
    ac: '空调',
    screen: '屏幕',
    speaker: '音响'
  }
  return map[type] || type || '设备'
}

function getDeviceIcon(type) {
  const map = {
    projector: '📽️',
    light: '💡',
    ac: '❄️',
    screen: '🖥️',
    speaker: '🔊'
  }
  return map[type] || '🔌'
}

function formatDate(dateStr) {
  if (!dateStr) return ''
  try {
    const d = new Date(dateStr)
    return d.toLocaleString('zh-CN', {
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    })
  } catch {
    return dateStr
  }
}

onMounted(() => {
  fetchAllData()
})
</script>
