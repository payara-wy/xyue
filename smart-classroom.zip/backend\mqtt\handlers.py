# -*- coding: utf-8 -*-
"""MQTT消息处理器 - 接收传感器/设备消息并写入数据库"""

import json
import logging
import re
from datetime import datetime, time as time_type, timedelta

import django
from django.db import connection
from django.utils import timezone

logger = logging.getLogger(__name__)

# 从主题中提取classroom_id的正则
_CLASSROOM_ID_PATTERN = re.compile(r'classroom/(\d+)/')


class MqttMessageHandler:
    """
    MQTT消息处理器
    负责解析从Broker收到的JSON消息，并通过Django ORM写入数据库
    所有数据库操作都包裹在connection管理中，确保线程安全
    """

    def handle_occupancy(self, client, userdata, msg):
        """
        处理座位占用消息
        消息格式: {row, col, occupied, student_id, timestamp}
        主题: classroom/{id}/sensor/occupancy
        """
        try:
            payload = json.loads(msg.payload.decode('utf-8'))
            classroom_id = self._extract_classroom_id(msg.topic)
            if not classroom_id:
                logger.warning('无法从主题提取classroom_id: %s', msg.topic)
                return

            row = payload.get('row')
            col = payload.get('col')
            occupied = payload.get('occupied', False)
            student_id = payload.get('student_id', '')

            logger.debug('座位占用更新: 教室%s [%d,%d] 占用=%s 学生=%s',
                         classroom_id, row, col, occupied, student_id)

            # 延迟导入模型，避免模块加载顺序问题
            from core.models import SeatOccupancy, Classroom

            with connection.cursor():
                # 保存座位占用记录
                SeatOccupancy.objects.create(
                    classroom_id=classroom_id,
                    row_num=row,
                    col_num=col,
                    is_occupied=occupied,
                    student_id=student_id,
                    source='mqtt',
                )

            # 如果有学生信息且处于上课时间，触发考勤逻辑
            if occupied and student_id:
                self._try_mark_attendance(classroom_id, student_id, row, col)

        except json.JSONDecodeError as e:
            logger.error('座位占用消息JSON解析失败: %s, payload: %s', e, msg.payload)
        except Exception as e:
            logger.error('处理座位占用消息出错: %s', e, exc_info=True)
        finally:
            # 确保数据库连接被释放
            connection.close()

    def handle_device_status(self, client, userdata, msg):
        """
        处理设备状态上报
        消息格式: {is_on, timestamp}
        主题: classroom/{id}/device/{type}/status
        """
        try:
            payload = json.loads(msg.payload.decode('utf-8'))
            classroom_id = self._extract_classroom_id(msg.topic)
            if not classroom_id:
                return

            # 从主题中提取设备类型
            # 主题格式: classroom/{id}/device/{type}/status
            parts = msg.topic.split('/')
            if len(parts) >= 4:
                device_type = parts[3]  # classroom/1/device/projector/status -> projector
            else:
                logger.warning('设备状态主题格式异常: %s', msg.topic)
                return

            is_on = payload.get('is_on', False)

            logger.info('设备状态更新: 教室%s %s -> %s', classroom_id, device_type, '开' if is_on else '关')

            from core.models import DeviceStatus

            with connection.cursor():
                # 使用update_or_create确保记录存在且最新
                DeviceStatus.objects.update_or_create(
                    classroom_id=classroom_id,
                    device_type=device_type,
                    defaults={'is_on': is_on},
                )

        except json.JSONDecodeError as e:
            logger.error('设备状态消息JSON解析失败: %s', e)
        except Exception as e:
            logger.error('处理设备状态消息出错: %s', e, exc_info=True)
        finally:
            connection.close()

    def handle_heartbeat(self, client, userdata, msg):
        """
        处理传感器心跳消息
        消息格式: {sensor_count, timestamp}
        主题: classroom/{id}/sensor/heartbeat
        """
        try:
            payload = json.loads(msg.payload.decode('utf-8'))
            classroom_id = self._extract_classroom_id(msg.topic)
            if not classroom_id:
                return

            sensor_count = payload.get('sensor_count', 0)
            ts = payload.get('timestamp', 0)

            logger.info('传感器心跳: 教室%s, 传感器数量=%d, 时间=%s',
                        classroom_id, sensor_count,
                        datetime.fromtimestamp(ts).strftime('%H:%M:%S') if ts else 'N/A')

        except json.JSONDecodeError as e:
            logger.error('心跳消息JSON解析失败: %s', e)
        except Exception as e:
            logger.error('处理心跳消息出错: %s', e, exc_info=True)
        finally:
            connection.close()

    def _extract_classroom_id(self, topic):
        """从MQTT主题中提取教室ID"""
        match = _CLASSROOM_ID_PATTERN.search(topic)
        if match:
            return int(match.group(1))
        return None

    def _try_mark_attendance(self, classroom_id, student_id, row, col):
        """
        尝试标记考勤
        逻辑：
        1. 检查当前时间是否在某门课程的上课时间段内
        2. 如果是，查找学生，创建或更新考勤记录
        3. 根据迟到阈值判断是"出勤"还是"迟到"
        """
        try:
            from core.models import Course, Student, AttendanceRecord, Classroom
            from config.settings import ATTENDANCE_RULES

            now = timezone.now()
            today = now.date()
            current_time = now.time()

            # 今天是星期几 (Django: Monday=1 ... Sunday=7)
            weekday = now.isoweekday()

            # 查找当前教室、当前时段正在上课的课程
            courses = Course.objects.filter(
                classroom_id=classroom_id,
                weekday=weekday,
                start_time__lte=current_time,
                end_time__gte=current_time,
            )

            if not courses.exists():
                # 当前没有课程在进行
                return

            # 查找学生
            try:
                student = Student.objects.get(student_id=student_id)
            except Student.DoesNotExist:
                logger.debug('学生 %s 未注册，跳过考勤', student_id)
                return

            late_threshold = ATTENDANCE_RULES.get('late_threshold_minutes', 10)

            for course in courses:
                # 计算迟到阈值时间：课程开始时间 + 迟到容忍分钟数
                start_dt = datetime.combine(today, course.start_time)
                late_cutoff = start_dt + timedelta(minutes=late_threshold)
                late_cutoff_time = late_cutoff.time()

                # 判断出勤状态
                if current_time <= late_cutoff_time:
                    status = 'present'
                else:
                    status = 'late'

                # 创建或更新考勤记录
                record, created = AttendanceRecord.objects.update_or_create(
                    course=course,
                    student=student,
                    course_date=today,
                    defaults={
                        'status': status,
                        'seat_row': row,
                        'seat_col': col,
                        'check_in_time': now,
                    },
                )

                action = '创建' if created else '更新'
                status_text = '出勤' if status == 'present' else '迟到'
                logger.info('考勤%s: 学生%s[%s] 课程%s -> %s',
                            action, student.name, student_id, course.name, status_text)

        except Exception as e:
            logger.error('考勤标记出错: %s', e, exc_info=True)
        finally:
            connection.close()
