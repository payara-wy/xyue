# -*- coding: utf-8 -*-
"""内嵌MQTT Broker - 使用amqtt实现轻量级消息代理"""

import asyncio
import logging
import threading
from amqtt.broker import Broker

logger = logging.getLogger(__name__)


class EmbeddedBroker:
    """
    内嵌式MQTT Broker封装
    基于amqtt，在独立守护线程中运行自己的asyncio事件循环
    """

    # amqtt配置：监听0.0.0.0:1883，允许匿名连接
    DEFAULT_CONFIG = {
        'listeners': {
            'default': {
                'type': 'tcp',
                'bind': '0.0.0.0:1883',
            }
        },
        'sys_interval': 0,
        'auth': {
            'allow-anonymous': True,
        }
    }

    def __init__(self, config=None):
        self.config = config or self.DEFAULT_CONFIG
        self._broker = None
        self._loop = None
        self._thread = None
        self._running = False

    def start(self):
        """
        启动Broker
        在守护线程中创建新的asyncio事件循环并运行Broker
        """
        if self._running:
            logger.warning('Broker已在运行中')
            return

        self._running = True
        self._thread = threading.Thread(target=self._run, daemon=True, name='mqtt-broker')
        self._thread.start()
        logger.info('MQTT Broker 已在后台线程启动，监听地址: %s',
                    self.config['listeners']['default']['bind'])

    def _run(self):
        """
        在独立线程中运行Broker的asyncio事件循环
        """
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)

        try:
            self._broker = Broker(config=self.config)
            # 启动Broker
            self._loop.run_until_complete(self._broker.start())
            logger.info('amqtt Broker 已成功启动')

            # 保持事件循环运行直到收到停止信号
            self._loop.run_forever()
        except Exception as e:
            logger.error('Broker运行出错: %s', e, exc_info=True)
        finally:
            # 清理资源
            if self._broker:
                try:
                    self._loop.run_until_complete(self._broker.shutdown())
                except Exception:
                    pass
            self._loop.close()
            logger.info('Broker事件循环已关闭')

    def stop(self):
        """
        优雅关闭Broker
        """
        if not self._running:
            return

        logger.info('正在停止MQTT Broker...')
        self._running = False

        if self._loop and self._loop.is_running():
            # 通过call_soon_threadsafe安排停止事件循环
            self._loop.call_soon_threadsafe(self._loop.stop)

        # 等待线程结束，超时5秒
        if self._thread:
            self._thread.join(timeout=5.0)
            if self._thread.is_alive():
                logger.warning('Broker线程未能在超时内停止')

        logger.info('MQTT Broker 已停止')

    @property
    def is_running(self):
        """检查Broker是否正在运行"""
        return self._running and self._thread is not None and self._thread.is_alive()
