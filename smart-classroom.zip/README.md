# 智能教室考勤与座位使用分析系统

基于物联网（MQTT）的智能教室管理系统，**自带全部依赖、零安装、一键运行**。

## 技术架构

| 层次 | 技术选型 |
|------|---------|
| 前端 | Vue 3 + Vite + Pinia + Chart.js |
| 后端 | Django 4 + Django REST Framework |
| 数据库 | 内嵌 MariaDB Portable / SQLite自动回退 |
| IoT通信 | MQTT (paho-mqtt + amqtt 内嵌Broker) |
| 运行时 | 内嵌 Python 嵌入式版 (无需安装Python) |
| 打包 | 便携包 (全自包含) / PyInstaller (.exe) |

## 便携包结构（构建后）

```
SmartClassroom-amd64/            ← 复制到U盘/任意位置即可运行
├── run.bat                      ← 一键启动入口
├── stop.bat                     ← 安全停止
├── first_run.bat                ← 首次运行初始化
├── start_sensor_sim.bat         ← 启动传感器模拟器
├── start_device_sim.bat         ← 启动设备控制模拟器
├── VERSION.txt                  ← 版本信息
├── runtime/
│   ├── python/                  ← 内嵌Python 3.11（含全部依赖）
│   │   ├── python.exe
│   │   ├── Lib/site-packages/   ← Django, DRF, paho-mqtt, amqtt...
│   │   └── Scripts/
│   └── mariadb/                 ← 内嵌MariaDB Portable
│       ├── bin/mysqld.exe
│       └── data/                ← 运行时数据
├── app/                         ← Django后端应用
│   ├── config/
│   ├── core/
│   ├── mqtt/
│   ├── services/
│   └── main.py
├── frontend/dist/               ← 前端构建产物（已编译）
├── simulators/                  ← IoT模拟器
└── data/                        ← 运行时数据目录
```

## 快速开始

### 方式一：便携包（推荐）

```bash
# 1. 构建便携包（需要本机有Python和Node.js）
python build_portable.py

# 2. 解压 dist/SmartClassroom-amd64.zip

# 3. 一键启动
双击 run.bat        # 自动拉起 MariaDB → Django → MQTT → 打开浏览器

# 4. 访问
http://localhost:8089
```

### 方式二：开发模式

```bash
# 后端
cd backend
pip install -r requirements.txt
python main.py        # 自动用SQLite，无需MySQL

# 前端开发
cd frontend
npm install
npm run dev           # Vite开发服务器 + API代理

# 模拟器
python simulators/sensor_simulator.py --broker localhost --classroom 1
python simulators/device_simulator.py --broker localhost --classroom 1
```

### ARM64 打包

```bash
python build_portable.py --arch arm64
# 注意: ARM64 MariaDB暂无官方便携版，自动使用SQLite模式
```

## 五大功能模块

### 1. 实时座位占用图
- 二维网格展示教室座位状态（红/绿色标识）
- 支持MQTT实时数据推送
- 模拟传感器数据更新

### 2. 自动考勤统计
- 按课程/日期查询考勤记录
- 自动识别迟到、早退、缺勤
- 学生考勤历史查询

### 3. 座位偏好分析
- 座位热力图（使用频率可视化）
- 前/中/后排、左/中/右区域偏好分析
- 跨课程座位偏好对比

### 4. 教室利用率报告
- 按时段统计入座率
- 按星期统计使用率
- 多教室利用率排行对比

### 5. 异常行为告警
- 检测无人教室设备开启（节能提醒）
- 设备长时间运行告警
- 设备远程控制（MQTT指令下发）

## MQTT主题设计

| 主题 | 方向 | 说明 |
|------|------|------|
| `classroom/{id}/sensor/occupancy` | 传感器→服务端 | 座位占用数据上报 |
| `classroom/{id}/sensor/heartbeat` | 传感器→服务端 | 传感器心跳 |
| `classroom/{id}/device/{type}/cmd` | 服务端→设备 | 设备控制指令 |
| `classroom/{id}/device/{type}/status` | 设备→服务端 | 设备状态回报 |
| `classroom/{id}/alert` | 服务端→客户端 | 告警推送 |

## 模拟器使用

### 传感器数据模拟器
```bash
python simulators/sensor_simulator.py \
  --broker localhost \      # MQTT Broker地址
  --port 1883 \             # MQTT端口
  --classroom 1 \           # 教室ID
  --interval 5 \            # 上报间隔(秒)
  --occupancy-rate 0.6      # 模拟入座率
```
功能：定时生成座位占用数据，模拟真实入座模式（前排偏好、中间偏好、聚集效应），终端显示ASCII教室网格。

### 设备控制模拟器
```bash
python simulators/device_simulator.py \
  --broker localhost \
  --port 1883 \
  --classroom 1
```
功能：订阅设备控制指令主题，模拟投影仪/灯光/空调的响应延迟，支持键盘手动控制（`on projector`, `off light`），定时回报设备状态。

## 源码项目结构

```
smart-classroom/
├── backend/                  # Django后端
│   ├── config/               # 配置（settings、urls、wsgi）
│   ├── core/                 # Django App（models、views、urls、serializers）
│   ├── mqtt/                 # MQTT集成（broker、client、handlers）
│   ├── services/             # 业务服务层（5个独立模块）
│   ├── utils/                # 工具（seed_data种子数据生成）
│   └── main.py               # 主入口
├── frontend/                 # Vue 3前端
│   ├── src/views/            # 5个模块页面
│   ├── src/components/       # 公共组件
│   ├── src/api/              # Axios API封装
│   └── src/stores/           # Pinia状态管理
├── simulators/               # IoT模拟器（独立运行）
├── scripts/                  # 构建脚本
├── build_portable.py         # 便携包构建器
├── run.bat                   # 一键启动
├── stop.bat                  # 安全停止
└── first_run.bat             # 首次初始化
```

## API接口

所有接口前缀为 `/api/`，返回JSON格式：

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/classrooms/` | 教室列表 |
| GET | `/api/classrooms/{id}/occupancy-grid/` | 座位占用网格 |
| POST | `/api/classrooms/{id}/simulate-sensor/` | 模拟传感器 |
| GET | `/api/courses/` | 课程列表 |
| GET | `/api/students/` | 学生列表 |
| GET | `/api/attendance/course/{id}/?date=` | 课程考勤详情 |
| GET | `/api/attendance/daily-summary/?date=` | 每日考勤汇总 |
| GET | `/api/analysis/heatmap/{id}/` | 座位热力图 |
| GET | `/api/utilization/classroom/{id}/` | 教室利用率 |
| GET | `/api/utilization/compare/` | 教室利用率对比 |
| GET | `/api/alerts/` | 告警列表 |
| POST | `/api/alerts/detection/` | 执行异常检测 |
| POST | `/api/devices/toggle/` | 设备开关控制 |
