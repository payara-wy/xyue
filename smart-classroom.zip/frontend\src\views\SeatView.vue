<template>
  <div class="fade-in">
    <div class="page-header">
      <h2>💺 实时座位占用</h2>
      <p>查看教室座位的实时占用状态</p>
    </div>

    <div class="controls-bar">
      <select v-model="selectedId" @change="fetchOccupancy">
        <option v-if="!store.classrooms.length" disabled value="">加载中...</option>
        <option v-for="c in store.classrooms" :key="c.id" :value="c.id">
          {{ c.name }}
        </option>
      </select>
      <button class="btn btn-primary" @click="fetchOccupancy" :disabled="loading">
        🔄 刷新数据
      </button>
      <button class="btn btn-success" @click="simulateSensor" :disabled="loading">
        📡 模拟传感器更新
      </button>
    </div>

    <div v-if="loading" class="loading">
      <div class="spinner"></div>
    </div>

    <template v-else-if="occupancy">
      <div class="stats-row">
        <StatsCard icon="🪑" :value="occupancy.total_seats" label="总座位数" color="blue" />
        <StatsCard icon="👤" :value="occupancy.occupied" label="已占用" color="red" />
        <StatsCard icon="✅" :value="occupancy.available" label="空闲" color="green" />
        <StatsCard
          icon="📈"
          :value="(occupancy.occupancy_rate * 100).toFixed(1) + '%'"
          label="占用率"
          color="yellow"
        />
      </div>

      <div class="card">
        <div class="card-title">座位分布图</div>
        <SeatGrid
          :rows="occupancy.rows"
          :cols="occupancy.cols"
          :seats="occupancy.seats"
          :show-names="true"
          @seat-click="onSeatClick"
        />
      </div>
    </template>

    <div v-else class="empty-state">
      <div class="empty-state-icon">💺</div>
      <div class="empty-state-text">请选择教室查看座位状态</div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useAppStore } from '../stores'
import { getOccupancyGrid, simulateSensor as simulateSensorApi } from '../api'
import StatsCard from '../components/StatsCard.vue'
import SeatGrid from '../components/SeatGrid.vue'

const store = useAppStore()
const selectedId = ref(store.selectedClassroomId)
const occupancy = ref(null)
const loading = ref(false)

async function fetchOccupancy() {
  if (!selectedId.value) return
  loading.value = true
  try {
    const res = await getOccupancyGrid(selectedId.value)
    occupancy.value = res.data
    store.selectedClassroomId = selectedId.value
  } catch (e) {
    console.error('Failed to fetch occupancy:', e)
  } finally {
    loading.value = false
  }
}

async function simulateSensor() {
  if (!selectedId.value) return
  loading.value = true
  try {
    await simulateSensorApi(selectedId.value)
    await fetchOccupancy()
  } catch (e) {
    console.error('Failed to simulate sensor:', e)
    loading.value = false
  }
}

function onSeatClick(seat) {
  const status = seat.occupied ? `已占用 (${seat.student_name || '未知'})` : '空闲'
  alert(`座位 [${seat.row}, ${seat.col}]: ${status}`)
}

onMounted(() => {
  if (selectedId.value) {
    fetchOccupancy()
  }
})
</script>
