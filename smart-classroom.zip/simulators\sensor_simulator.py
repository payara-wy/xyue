#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
传感器数据模拟器 - 模拟智能教室座位占用传感器

独立运行，不依赖Django。通过paho-mqtt直接连接MQTT Broker，
周期性发布座位占用数据和心跳消息。

用法:
    python sensor_simulator.py [--broker localhost] [--port 1883] [--classroom 1] [--interval 5] [--occupancy-rate 0.6]
"""

import argparse
import json
import random
import signal
import sys
import time
from datetime import datetime

import paho.mqtt.client as mqtt


# ============ ANSI颜色代码 ============
class Colors:
    """终端ANSI颜色"""
    RESET = '\033[0m'
    BOLD = '\033[1m'
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GRAY = '\033[90m'
    BG_GREEN = '\033[42m'
    BG_RED = '\033[41m'
    BG_GRAY = '\033[100m'


# ============ 全局状态 ============
running = True  # 运行标志，Ctrl+C时置为False


def signal_handler(sig, frame):
    """优雅退出信号处理"""
    global running
    print(f'\n{Colors.YELLOW}收到退出信号，正在关闭...{Colors.RESET}')
    running = False


def clear_screen():
    """清屏"""
    print('\033[2J\033[H', end='')


def draw_classroom_grid(grid, rows, cols, classroom_id):
    """
    在终端绘制ASCII教室座位图
    occupied座位显示绿色[X]，空座位显示灰色[·]
    """
    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    occupied_count = sum(1 for r in range(rows) for c in range(cols) if grid[r][c])
    total = rows * cols
    rate = occupied_count / total * 100 if total > 0 else 0

    # 头部
    print(f'{Colors.BOLD}{Colors.CYAN}')
    print(f'  ╔══════════════════════════════════════════════════════════════╗')
    print(f'  ║       智能教室 #{classroom_id} - 座位占用实时状态              ║')
    print(f'  ║       {now_str}                            ║')
    print(f'  ╚══════════════════════════════════════════════════════════════╝')
    print(f'{Colors.RESET}')

    # 讲台
    print(f'  {Colors.BOLD}{"_" * (cols * 5 + 8)}{Colors.RESET}')
    print(f'  {Colors.BOLD}|{"讲  台".center(cols * 5 + 4)}|{Colors.RESET}')
    print(f'  {Colors.BOLD}{"‾" * (cols * 5 + 8)}{Colors.RESET}')
    print()

    # 列号标题
    col_header = '       '
    for c in range(cols):
        col_header += f' {c+1:>2}  '
    print(f'{Colors.GRAY}{col_header}{Colors.RESET}')

    # 座位行
    for r in range(rows):
        row_str = f'  {Colors.BOLD}R{r+1:<2}{Colors.RESET}  '
        for c in range(cols):
            if grid[r][c]:
                row_str += f'{Colors.BG_GREEN}{Colors.BOLD}[X]{Colors.RESET} '
            else:
                row_str += f'{Colors.BG_GRAY}[·]{Colors.RESET} '
        print(row_str)

    print()

    # 统计信息
    print(f'  {Colors.GREEN}■{Colors.RESET} 占用: {Colors.BOLD}{occupied_count}{Colors.RESET}'
          f'   {Colors.GRAY}■{Colors.RESET} 空闲: {Colors.BOLD}{total - occupied_count}{Colors.RESET}'
          f'   占用率: {Colors.BOLD}{rate:.1f}%{Colors.RESET}')
    print()


def generate_student_id():
    """生成模拟学号"""
    return f'STU{random.randint(20230001, 20230200):08d}'


def simulate_occupancy_pattern(grid, rows, cols, occupancy_rate):
    """
    模拟真实的座位占用模式：
    - 前排座位更受欢迎（偏好前排）
    - 座位倾向于聚集（学生喜欢坐在一起）
    - 中间列更受欢迎
    """
    changes = []
    mid_col = cols // 2

    for r in range(rows):
        for c in range(cols):
            # 计算该位置的"吸引力"
            # 前排偏好：行号越小吸引力越高
            front_bonus = (rows - r) / rows * 0.15
            # 中间偏好：离中间列越近吸引力越高
            center_bonus = (1 - abs(c - mid_col) / cols) * 0.1
            # 聚集效应：如果相邻座位有人，吸引力增加
            neighbor_bonus = 0.0
            for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                nr, nc = r + dr, c + dc
                if 0 <= nr < rows and 0 <= nc < cols and grid[nr][nc]:
                    neighbor_bonus += 0.05

            effective_rate = min(occupancy_rate + front_bonus + center_bonus + neighbor_bonus, 0.98)

            new_state = random.random() < effective_rate

            if new_state != grid[r][c]:
                changes.append((r, c, new_state))
                grid[r][c] = new_state

    return changes


def on_connect(client, userdata, flags, rc):
    """连接回调"""
    if rc == 0:
        print(f'{Colors.GREEN}✓ 已连接到MQTT Broker{Colors.RESET}')
    else:
        print(f'{Colors.RED}✗ 连接失败，返回码: {rc}{Colors.RESET}')


def on_disconnect(client, userdata, rc):
    """断连回调"""
    if rc != 0:
        print(f'{Colors.YELLOW}⚠ 连接断开(rc={rc})，等待自动重连...{Colors.RESET}')


def main():
    parser = argparse.ArgumentParser(
        description='智能教室传感器模拟器 - 模拟座位占用数据',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python sensor_simulator.py
  python sensor_simulator.py --broker 192.168.1.100 --classroom 3
  python sensor_simulator.py --interval 10 --occupancy-rate 0.8
  python sensor_simulator.py --rows 6 --cols 8
        """
    )
    parser.add_argument('--broker', default='localhost', help='MQTT Broker地址 (默认: localhost)')
    parser.add_argument('--port', type=int, default=1883, help='MQTT Broker端口 (默认: 1883)')
    parser.add_argument('--classroom', type=int, default=1, help='教室ID (默认: 1)')
    parser.add_argument('--interval', type=int, default=5, help='发布间隔（秒） (默认: 5)')
    parser.add_argument('--occupancy-rate', type=float, default=0.6,
                        help='座位占用率 0.0~1.0 (默认: 0.6)')
    parser.add_argument('--rows', type=int, default=8, help='座位行数 (默认: 8)')
    parser.add_argument('--cols', type=int, default=10, help='座位列数 (默认: 10)')
    args = parser.parse_args()

    # 注册信号处理
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    rows = args.rows
    cols = args.cols
    classroom_id = args.classroom

    # 初始化座位网格（全部为空）
    grid = [[False] * cols for _ in range(rows)]
    # 预先填充一些座位，模拟上课状态
    for r in range(rows):
        for c in range(cols):
            grid[r][c] = random.random() < args.occupancy_rate

    # 为已占用的座位分配固定的学生ID（模拟同一学生持续就坐）
    student_map = {}  # (r, c) -> student_id
    for r in range(rows):
        for c in range(cols):
            if grid[r][c]:
                student_map[(r, c)] = generate_student_id()

    # 主题定义
    occupancy_topic = f'classroom/{classroom_id}/sensor/occupancy'
    heartbeat_topic = f'classroom/{classroom_id}/sensor/heartbeat'

    # 创建MQTT客户端
    client_id = f'sensor_simulator_{classroom_id}_{int(time.time())}'
    client = mqtt.Client(client_id=client_id)
    client.on_connect = on_connect
    client.on_disconnect = on_disconnect

    print(f'{Colors.CYAN}======================================{Colors.RESET}')
    print(f'{Colors.CYAN}  智能教室传感器模拟器{Colors.RESET}')
    print(f'{Colors.CYAN}======================================{Colors.RESET}')
    print(f'  Broker:     {args.broker}:{args.port}')
    print(f'  教室ID:     {classroom_id}')
    print(f'  座位布局:   {rows}行 x {cols}列 = {rows * cols}个座位')
    print(f'  发布间隔:   {args.interval}秒')
    print(f'  占用率:     {args.occupancy_rate * 100:.0f}%')
    print(f'  占用主题:   {occupancy_topic}')
    print(f'  心跳主题:   {heartbeat_topic}')
    print(f'{Colors.CYAN}======================================{Colors.RESET}')
    print()

    # 连接Broker
    try:
        client.connect(args.broker, args.port, keepalive=60)
    except Exception as e:
        print(f'{Colors.RED}✗ 无法连接到Broker: {e}{Colors.RESET}')
        sys.exit(1)

    client.reconnect_delay_set(min_delay=1, max_delay=30)
    client.loop_start()

    # 等待连接建立
    time.sleep(1)

    # 初始发布：发送所有座位的初始状态
    print(f'{Colors.GREEN}发送初始座位状态...{Colors.RESET}')
    for r in range(rows):
        for c in range(cols):
            payload = {
                'row': r + 1,
                'col': c + 1,
                'occupied': grid[r][c],
                'student_id': student_map.get((r, c), ''),
                'timestamp': time.time(),
            }
            client.publish(occupancy_topic, json.dumps(payload), qos=0)
    time.sleep(0.5)

    # 主循环
    cycle = 0
    try:
        while running:
            cycle += 1

            # 模拟座位变化
            changes = simulate_occupancy_pattern(grid, rows, cols, args.occupancy_rate)

            # 为新的占用分配学生ID，释放时清除
            for r, c, occupied in changes:
                if occupied:
                    student_map[(r, c)] = generate_student_id()
                else:
                    student_map.pop((r, c), None)

            # 发布变化的座位状态
            for r, c, occupied in changes:
                payload = {
                    'row': r + 1,
                    'col': c + 1,
                    'occupied': occupied,
                    'student_id': student_map.get((r, c), ''),
                    'timestamp': time.time(),
                }
                client.publish(occupancy_topic, json.dumps(payload), qos=0)

            # 发布心跳
            occupied_count = sum(1 for r in range(rows) for c in range(cols) if grid[r][c])
            heartbeat = {
                'sensor_count': rows * cols,
                'occupied_count': occupied_count,
                'timestamp': time.time(),
            }
            client.publish(heartbeat_topic, json.dumps(heartbeat), qos=0)

            # 清屏并刷新座位图
            clear_screen()
            draw_classroom_grid(grid, rows, cols, classroom_id)

            # 显示最近变化
            if changes:
                print(f'  {Colors.YELLOW}本轮变化 ({len(changes)}个座位):{Colors.RESET}')
                for r, c, occupied in changes[:5]:  # 最多显示5个变化
                    status = f'{Colors.GREEN}就坐{Colors.RESET}' if occupied else f'{Colors.RED}离开{Colors.RESET}'
                    sid = student_map.get((r, c), '')
                    print(f'    R{r+1}C{c+1} -> {status} {Colors.GRAY}{sid}{Colors.RESET}')
                if len(changes) > 5:
                    print(f'    {Colors.GRAY}... 还有{len(changes) - 5}个变化{Colors.RESET}')
            else:
                print(f'  {Colors.GRAY}本轮无座位变化{Colors.RESET}')

            print()
            print(f'  {Colors.GRAY}第 {cycle} 轮 | 按 Ctrl+C 退出{Colors.RESET}')

            # 等待下一个周期
            for _ in range(args.interval * 10):
                if not running:
                    break
                time.sleep(0.1)

    except KeyboardInterrupt:
        pass

    # 清理
    print(f'\n{Colors.YELLOW}正在停止模拟器...{Colors.RESET}')
    client.loop_stop()
    client.disconnect()
    print(f'{Colors.GREEN}模拟器已停止{Colors.RESET}')


if __name__ == '__main__':
    main()
