# -*- coding: utf-8 -*-
"""DRF 视图 - 智能教室全部API端点"""

from datetime import date, datetime, timedelta
from rest_framework import viewsets, status
from rest_framework.decorators import api_view, action
from rest_framework.response import Response

from core.models import (
    Classroom, Course, Student, SeatOccupancy,
    AttendanceRecord, DeviceStatus, Alert,
)
from core.serializers import (
    ClassroomSerializer, CourseSerializer, StudentSerializer,
    SeatOccupancySerializer, AttendanceRecordSerializer,
    DeviceStatusSerializer, AlertSerializer,
    ClassroomOccupancyGridSerializer,
)

# 服务层导入
from services.seat_service import SeatService
from services.attendance_service import AttendanceService
from services.analysis_service import AnalysisService
from services.utilization_service import UtilizationService
from services.alert_service import AlertService


# ============================
# 辅助函数
# ============================

def _parse_date(date_str, default=None):
    """解析日期字符串，返回date对象"""
    if not date_str:
        return default
    try:
        return datetime.strptime(date_str, '%Y-%m-%d').date()
    except (ValueError, TypeError):
        return default


def _parse_int(value, default=None):
    """安全解析整数"""
    try:
        return int(value)
    except (ValueError, TypeError):
        return default


# ============================
# 模块1: 座位管理
# ============================

class ClassroomViewSet(viewsets.ReadOnlyModelViewSet):
    """教室视图集 - 列表与详情"""
    queryset = Classroom.objects.all()
    serializer_class = ClassroomSerializer

    @action(detail=True, methods=['get'], url_path='occupancy-grid')
    def occupancy_grid(self, request, pk=None):
        """获取教室座位占用网格"""
        try:
            data = SeatService.get_occupancy_grid(pk)
            return Response(data)
        except Classroom.DoesNotExist:
            return Response({'error': '教室不存在'}, status=status.HTTP_404_NOT_FOUND)

    @action(detail=True, methods=['post'], url_path='simulate-sensor')
    def simulate_sensor(self, request, pk=None):
        """模拟传感器数据"""
        try:
            data = SeatService.simulate_sensor(pk)
            return Response(data)
        except Classroom.DoesNotExist:
            return Response({'error': '教室不存在'}, status=status.HTTP_404_NOT_FOUND)


# ============================
# 模块2: 考勤管理
# ============================

class CourseViewSet(viewsets.ReadOnlyModelViewSet):
    """课程视图集"""
    queryset = Course.objects.select_related('classroom').all()
    serializer_class = CourseSerializer


class StudentViewSet(viewsets.ModelViewSet):
    """学生视图集"""
    queryset = Student.objects.all()
    serializer_class = StudentSerializer


@api_view(['GET'])
def get_course_attendance(request, course_id):
    """获取某课程某天的考勤详情 ?date=2026-01-15"""
    query_date = _parse_date(
        request.query_params.get('date'),
        default=date.today(),
    )
    try:
        data = AttendanceService.get_course_attendance(course_id, query_date)
        return Response(data)
    except Course.DoesNotExist:
        return Response({'error': '课程不存在'}, status=status.HTTP_404_NOT_FOUND)


@api_view(['GET'])
def get_daily_summary(request):
    """获取某天所有课程考勤汇总 ?date=2026-01-15"""
    query_date = _parse_date(
        request.query_params.get('date'),
        default=date.today(),
    )
    data = AttendanceService.get_daily_summary(query_date)
    return Response(data)


@api_view(['GET'])
def get_student_history(request, student_id):
    """获取学生考勤历史 ?days=30"""
    days = _parse_int(request.query_params.get('days'), default=30)
    try:
        data = AttendanceService.get_student_history(student_id, days)
        return Response(data)
    except Student.DoesNotExist:
        return Response({'error': '学生不存在'}, status=status.HTTP_404_NOT_FOUND)


# ============================
# 模块3: 数据分析
# ============================

@api_view(['GET'])
def get_heatmap(request, classroom_id):
    """获取座位热力图 ?course_id=&date_from=&date_to="""
    course_id = _parse_int(request.query_params.get('course_id'))
    date_from = _parse_date(request.query_params.get('date_from'))
    date_to = _parse_date(request.query_params.get('date_to'))

    try:
        data = AnalysisService.get_heatmap(classroom_id, course_id, date_from, date_to)
        return Response(data)
    except Classroom.DoesNotExist:
        return Response({'error': '教室不存在'}, status=status.HTTP_404_NOT_FOUND)


@api_view(['GET'])
def get_cross_course_analysis(request):
    """跨课程分析 - 各课程选座模式对比"""
    data = AnalysisService.get_cross_course_analysis()
    return Response(data)


# ============================
# 模块4: 利用率
# ============================

@api_view(['GET'])
def get_classroom_utilization(request, classroom_id):
    """获取教室利用率 ?date_from=&date_to="""
    date_from = _parse_date(request.query_params.get('date_from'))
    date_to = _parse_date(request.query_params.get('date_to'))

    try:
        data = UtilizationService.get_classroom_utilization(classroom_id, date_from, date_to)
        return Response(data)
    except Classroom.DoesNotExist:
        return Response({'error': '教室不存在'}, status=status.HTTP_404_NOT_FOUND)


@api_view(['GET'])
def compare_all_classrooms(request):
    """对比所有教室利用率 ?date_from=&date_to="""
    date_from = _parse_date(request.query_params.get('date_from'))
    date_to = _parse_date(request.query_params.get('date_to'))

    data = UtilizationService.compare_all_classrooms(date_from, date_to)
    return Response(data)


# ============================
# 模块5: 告警与设备
# ============================

class AlertViewSet(viewsets.ReadOnlyModelViewSet):
    """告警视图集"""
    serializer_class = AlertSerializer

    def get_queryset(self):
        qs = Alert.objects.select_related('classroom').all()
        # 支持过滤
        classroom_id = self.request.query_params.get('classroom_id')
        if classroom_id:
            qs = qs.filter(classroom_id=classroom_id)
        is_resolved = self.request.query_params.get('is_resolved')
        if is_resolved is not None:
            qs = qs.filter(is_resolved=is_resolved.lower() == 'true')
        return qs


@api_view(['GET'])
def get_active_alerts(request):
    """获取活跃告警 ?classroom_id="""
    classroom_id = _parse_int(request.query_params.get('classroom_id'))
    data = AlertService.get_active_alerts(classroom_id)
    return Response(data)


@api_view(['GET'])
def get_alert_statistics(request):
    """获取告警统计"""
    data = AlertService.get_alert_statistics()
    return Response(data)


@api_view(['POST'])
def resolve_alert(request, alert_id):
    """解决单个告警"""
    try:
        data = AlertService.resolve_alert(alert_id)
        return Response(data)
    except Alert.DoesNotExist:
        return Response({'error': '告警不存在'}, status=status.HTTP_404_NOT_FOUND)


@api_view(['POST'])
def resolve_all_alerts(request):
    """批量解决告警 ?classroom_id="""
    classroom_id = _parse_int(request.query_params.get('classroom_id'))
    data = AlertService.resolve_all(classroom_id)
    return Response(data)


@api_view(['POST'])
def run_detection(request):
    """运行告警检测"""
    data = AlertService.run_detection()
    return Response(data)


class DeviceStatusViewSet(viewsets.ReadOnlyModelViewSet):
    """设备状态视图集"""
    serializer_class = DeviceStatusSerializer

    def get_queryset(self):
        qs = DeviceStatus.objects.select_related('classroom').all()
        classroom_id = self.request.query_params.get('classroom_id')
        if classroom_id:
            qs = qs.filter(classroom_id=classroom_id)
        return qs


@api_view(['POST'])
def toggle_device(request):
    """切换设备开关 {classroom_id, device_type, is_on}"""
    classroom_id = request.data.get('classroom_id')
    device_type = request.data.get('device_type')
    is_on = request.data.get('is_on', False)

    if not classroom_id or not device_type:
        return Response(
            {'error': '缺少必要参数 classroom_id 或 device_type'},
            status=status.HTTP_400_BAD_REQUEST,
        )

    try:
        data = AlertService.toggle_device(classroom_id, device_type, bool(is_on))
        return Response(data)
    except Classroom.DoesNotExist:
        return Response({'error': '教室不存在'}, status=status.HTTP_404_NOT_FOUND)
