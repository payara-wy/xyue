# -*- coding: utf-8 -*-
"""数据模型 - 智能教室全部表结构"""

from django.db import models


class Classroom(models.Model):
    """教室"""
    name = models.CharField('教室名称', max_length=50, unique=True)
    building = models.CharField('楼宇', max_length=50, default='')
    rows_count = models.IntegerField('行数', default=8)
    cols_count = models.IntegerField('列数', default=10)
    has_projector = models.BooleanField('有投影仪', default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'classrooms'
        ordering = ['building', 'name']

    @property
    def total_seats(self):
        return self.rows_count * self.cols_count

    def __str__(self):
        return f'{self.building}-{self.name}'


class Course(models.Model):
    """课程"""
    WEEKDAY_CHOICES = [(i, ['周一','周二','周三','周四','周五','周六','周日'][i-1]) for i in range(1, 8)]

    name = models.CharField('课程名', max_length=100)
    course_code = models.CharField('课程编号', max_length=20, default='')
    teacher = models.CharField('教师', max_length=50, default='')
    classroom = models.ForeignKey(Classroom, on_delete=models.CASCADE, related_name='courses')
    weekday = models.IntegerField('星期', choices=WEEKDAY_CHOICES)
    start_time = models.TimeField('开始时间')
    end_time = models.TimeField('结束时间')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'courses'
        ordering = ['weekday', 'start_time']

    def __str__(self):
        return self.name


class Student(models.Model):
    """学生"""
    student_id = models.CharField('学号', max_length=20, unique=True)
    name = models.CharField('姓名', max_length=50)
    class_name = models.CharField('班级', max_length=50, default='')
    beacon_id = models.CharField('蓝牙信标ID', max_length=30, default='')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'students'
        ordering = ['student_id']

    def __str__(self):
        return f'{self.student_id}-{self.name}'


class SeatOccupancy(models.Model):
    """座位占用记录（传感器上报）"""
    classroom = models.ForeignKey(Classroom, on_delete=models.CASCADE, related_name='occupancies')
    row_num = models.IntegerField('行号')
    col_num = models.IntegerField('列号')
    is_occupied = models.BooleanField('是否占用')
    student_id = models.CharField('学生学号', max_length=20, blank=True, default='')
    source = models.CharField('数据来源', max_length=20, default='mqtt')  # mqtt / simulator / manual
    timestamp = models.DateTimeField('时间戳', auto_now_add=True)

    class Meta:
        db_table = 'seat_occupancy'
        indexes = [
            models.Index(fields=['classroom', 'timestamp']),
            models.Index(fields=['classroom', 'row_num', 'col_num', 'timestamp']),
        ]


class AttendanceRecord(models.Model):
    """考勤记录"""
    STATUS_CHOICES = [
        ('present', '出勤'),
        ('late', '迟到'),
        ('early_leave', '早退'),
        ('absent', '缺勤'),
    ]

    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='attendances')
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name='attendances')
    status = models.CharField('状态', max_length=15, choices=STATUS_CHOICES, default='absent')
    seat_row = models.IntegerField('座位行', default=-1)
    seat_col = models.IntegerField('座位列', default=-1)
    check_in_time = models.DateTimeField('签到时间', null=True, blank=True)
    check_out_time = models.DateTimeField('签退时间', null=True, blank=True)
    course_date = models.DateField('课程日期')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'attendance_records'
        indexes = [
            models.Index(fields=['course', 'course_date']),
            models.Index(fields=['student', 'course_date']),
        ]
        unique_together = ['course', 'student', 'course_date']


class DeviceStatus(models.Model):
    """设备状态"""
    DEVICE_TYPES = [
        ('projector', '投影仪'),
        ('light', '灯光'),
        ('ac', '空调'),
    ]

    classroom = models.ForeignKey(Classroom, on_delete=models.CASCADE, related_name='devices')
    device_type = models.CharField('设备类型', max_length=20, choices=DEVICE_TYPES)
    is_on = models.BooleanField('是否开启', default=False)
    last_changed = models.DateTimeField('最后变更时间', auto_now=True)

    class Meta:
        db_table = 'device_status'
        unique_together = ['classroom', 'device_type']


class Alert(models.Model):
    """告警记录"""
    TYPE_CHOICES = [
        ('energy', '节能告警'),
        ('absence', '出勤异常'),
        ('device', '设备告警'),
    ]
    SEVERITY_CHOICES = [
        ('info', '信息'),
        ('warning', '警告'),
        ('critical', '严重'),
    ]

    classroom = models.ForeignKey(Classroom, on_delete=models.CASCADE, related_name='alerts')
    alert_type = models.CharField('告警类型', max_length=20, choices=TYPE_CHOICES)
    message = models.TextField('告警消息')
    severity = models.CharField('严重程度', max_length=10, choices=SEVERITY_CHOICES, default='warning')
    is_resolved = models.BooleanField('是否已解决', default=False)
    created_at = models.DateTimeField('创建时间', auto_now_add=True)
    resolved_at = models.DateTimeField('解决时间', null=True, blank=True)

    class Meta:
        db_table = 'alerts'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['classroom', 'is_resolved']),
        ]
