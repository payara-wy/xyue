<template>
  <div class="seat-grid-container">
    <div class="podium">讲 台</div>
    <div class="seat-grid">
      <div v-for="(row, rIdx) in seats" :key="rIdx" class="seat-row">
        <template v-for="(seat, cIdx) in row" :key="`${rIdx}-${cIdx}`">
          <div
            v-if="isAisleGap(cIdx, row.length)"
            class="aisle"
          ></div>
          <div
            class="seat"
            :class="seat.occupied ? 'occupied' : 'empty'"
            @click="$emit('seat-click', seat)"
          >
            <span v-if="showNames && seat.occupied && seat.student_name">
              {{ seat.student_name.slice(0, 2) }}
            </span>
            <span v-else>{{ rIdx + 1 }}-{{ cIdx + 1 }}</span>
            <div class="tooltip">
              第{{ rIdx + 1 }}排 第{{ cIdx + 1 }}列
              <template v-if="seat.occupied && seat.student_name">
                · {{ seat.student_name }}
              </template>
            </div>
          </div>
        </template>
      </div>
    </div>
    <div class="seat-legend">
      <div class="seat-legend-item">
        <div class="seat-legend-dot empty"></div>
        <span>空座位</span>
      </div>
      <div class="seat-legend-item">
        <div class="seat-legend-dot occupied"></div>
        <span>已占用</span>
      </div>
    </div>
  </div>
</template>

<script setup>
defineProps({
  rows: { type: Number, default: 0 },
  cols: { type: Number, default: 0 },
  seats: { type: Array, default: () => [] },
  showNames: { type: Boolean, default: true }
})

defineEmits(['seat-click'])

function isAisleGap(colIdx, totalCols) {
  if (totalCols <= 4) return false
  const mid = Math.floor(totalCols / 2)
  return colIdx === mid
}
</script>
