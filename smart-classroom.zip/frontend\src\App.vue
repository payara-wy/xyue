<template>
  <div class="app-container">
    <aside class="sidebar" :class="{ open: sidebarOpen }">
      <div class="sidebar-header">
        <h1>🎓 智能教室系统</h1>
      </div>
      <nav class="sidebar-nav">
        <router-link
          v-for="item in navItems"
          :key="item.path"
          :to="item.path"
          class="nav-item"
          @click="sidebarOpen = false"
        >
          <span class="nav-icon">{{ item.icon }}</span>
          <span class="nav-label">{{ item.label }}</span>
        </router-link>
      </nav>
    </aside>

    <div class="main-wrapper">
      <header class="mobile-header">
        <button class="hamburger" @click="sidebarOpen = !sidebarOpen">☰</button>
        <span class="mobile-title">智能教室系统</span>
      </header>
      <main class="main-content">
        <router-view />
      </main>
    </div>

    <div class="overlay" v-if="sidebarOpen" @click="sidebarOpen = false"></div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useAppStore } from './stores'

const sidebarOpen = ref(false)
const store = useAppStore()

const navItems = [
  { path: '/seat', icon: '💺', label: '座位占用' },
  { path: '/attendance', icon: '📋', label: '考勤统计' },
  { path: '/analysis', icon: '🔥', label: '偏好分析' },
  { path: '/utilization', icon: '📊', label: '使用率' },
  { path: '/alert', icon: '🔔', label: '告警设备' }
]

store.fetchClassrooms()
store.fetchCourses()
store.fetchStudents()
</script>

<style scoped>
.overlay {
  display: none;
}

@media (max-width: 768px) {
  .overlay {
    display: block;
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, 0.4);
    z-index: 90;
  }
}
</style>
