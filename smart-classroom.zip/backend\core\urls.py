# -*- coding: utf-8 -*-
"""URL路由 - 智能教室API"""

from django.urls import path, include
from rest_framework.routers import DefaultRouter

from core.views import (
    ClassroomViewSet, CourseViewSet, StudentViewSet,
    AlertViewSet, DeviceStatusViewSet,
    # 座位
    # 考勤
    get_course_attendance, get_daily_summary, get_student_history,
    # 分析
    get_heatmap, get_cross_course_analysis,
    # 利用率
    get_classroom_utilization, compare_all_classrooms,
    # 告警
    get_active_alerts, get_alert_statistics,
    resolve_alert, resolve_all_alerts, run_detection,
    toggle_device,
)

# DRF Router - 标准ViewSet路由
router = DefaultRouter()
router.register(r'classrooms', ClassroomViewSet, basename='classroom')
router.register(r'courses', CourseViewSet, basename='course')
router.register(r'students', StudentViewSet, basename='student')
router.register(r'alerts', AlertViewSet, basename='alert')
router.register(r'devices', DeviceStatusViewSet, basename='device')

urlpatterns = [
    # ===== 模块1: 座位 =====
    # 教室座位网格和传感器模拟已通过ViewSet @action注册:
    #   GET  /api/classrooms/{id}/occupancy-grid/
    #   POST /api/classrooms/{id}/simulate-sensor/

    # ===== 模块2: 考勤 =====
    path('attendance/course/<int:course_id>/', get_course_attendance, name='course-attendance'),
    path('attendance/daily-summary/', get_daily_summary, name='daily-summary'),
    path('attendance/student/<int:student_id>/history/', get_student_history, name='student-history'),

    # ===== 模块3: 分析 =====
    path('analysis/heatmap/<int:classroom_id>/', get_heatmap, name='heatmap'),
    path('analysis/cross-course/', get_cross_course_analysis, name='cross-course-analysis'),

    # ===== 模块4: 利用率 =====
    path('utilization/classroom/<int:classroom_id>/', get_classroom_utilization, name='classroom-utilization'),
    path('utilization/compare/', compare_all_classrooms, name='compare-classrooms'),

    # ===== 模块5: 告警与设备（必须在router之前，避免被alerts/{pk}/拦截）=====
    path('alerts/active/', get_active_alerts, name='active-alerts'),
    path('alerts/statistics/', get_alert_statistics, name='alert-statistics'),
    path('alerts/<int:alert_id>/resolve/', resolve_alert, name='resolve-alert'),
    path('alerts/resolve-all/', resolve_all_alerts, name='resolve-all-alerts'),
    path('alerts/detection/', run_detection, name='run-detection'),
    path('devices/toggle/', toggle_device, name='toggle-device'),

    # Router生成的标准CRUD路由（放在最后，避免拦截自定义子路径）
    path('', include(router.urls)),
]
