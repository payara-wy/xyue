@echo off
REM ============================================================
REM  智能教室考勤系统 - Windows x64 打包脚本
REM ============================================================
setlocal

set PROJECT_DIR=%~dp0..
set BACKEND_DIR=%PROJECT_DIR%\backend
set FRONTEND_DIR=%PROJECT_DIR%\frontend
set OUTPUT_DIR=%PROJECT_DIR%\dist\x64

echo.
echo ============================================
echo   打包 Windows x64 可执行文件
echo ============================================
echo.

REM 1. 构建前端
echo [1/4] 构建前端...
cd /d "%FRONTEND_DIR%"
call npm install
call npm run build
if errorlevel 1 (
    echo 前端构建失败!
    exit /b 1
)
echo 前端构建完成.

REM 2. 安装后端依赖
echo [2/4] 安装后端依赖...
cd /d "%BACKEND_DIR%"
pip install -r requirements.txt pyinstaller --quiet
if errorlevel 1 (
    echo 后端依赖安装失败!
    exit /b 1
)

REM 3. PyInstaller打包
echo [3/4] PyInstaller打包 (x64)...
cd /d "%BACKEND_DIR%"
pyinstaller ^
    --name "SmartClassroom-x64" ^
    --distpath "%OUTPUT_DIR%" ^
    --workpath "%PROJECT_DIR%\build\x64" ^
    --specpath "%PROJECT_DIR%\build" ^
    --onefile ^
    --console ^
    --add-data "config;config" ^
    --add-data "core;core" ^
    --add-data "api;api" ^
    --add-data "mqtt;mqtt" ^
    --add-data "services;services" ^
    --add-data "utils;utils" ^
    --add-data "%FRONTEND_DIR%\dist;%FRONTEND_DIR%\dist" ^
    --hidden-import=pymysql ^
    --hidden-import=paho.mqtt.client ^
    --hidden-import=rest_framework ^
    --hidden-import=corsheaders ^
    --collect-all django ^
    --collect-all rest_framework ^
    --collect-all corsheaders ^
    main.py

if errorlevel 1 (
    echo PyInstaller打包失败!
    exit /b 1
)
echo PyInstaller打包完成.

REM 4. 复制附加文件
echo [4/4] 复制附加文件...
copy "%PROJECT_DIR%\scripts\setup_mariadb.py" "%OUTPUT_DIR%\setup_mariadb.py"
copy "%PROJECT_DIR%\simulators\sensor_simulator.py" "%OUTPUT_DIR%\sensor_simulator.py"
copy "%PROJECT_DIR%\simulators\device_simulator.py" "%OUTPUT_DIR%\device_simulator.py"
echo.

echo ============================================
echo   打包完成!
echo   输出: %OUTPUT_DIR%\SmartClassroom-x64.exe
echo ============================================
echo.

endlocal
