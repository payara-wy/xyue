# -*- coding: utf-8 -*-
"""考勤服务 - 考勤查询、统计、历史"""

from datetime import timedelta, date as date_type
from django.utils import timezone
from django.db.models import Count, Q, F

from core.models import Course, Student, AttendanceRecord, Classroom


class AttendanceService:
    """考勤相关业务逻辑"""

    @staticmethod
    def get_course_attendance(course_id, query_date):
        """
        获取某课程某天的考勤详情
        包含：课程信息、各状态统计、出勤率、记录列表
        """
        course = Course.objects.select_related('classroom').get(id=course_id)

        # 查询该课程当天的考勤记录
        records = AttendanceRecord.objects.filter(
            course=course,
            course_date=query_date,
        ).select_related('student').order_by('student__student_id')

        # 统计各状态人数
        total = records.count()
        stats = {
            'present': 0,
            'late': 0,
            'early_leave': 0,
            'absent': 0,
        }
        for rec in records:
            if rec.status in stats:
                stats[rec.status] += 1

        # 出勤率 = (出勤+迟到) / 总人数
        effective_present = stats['present'] + stats['late']
        attendance_rate = round(effective_present / total * 100, 1) if total > 0 else 0

        # 记录列表
        record_list = []
        for rec in records:
            record_list.append({
                'id': rec.id,
                'student_id': rec.student.student_id,
                'student_name': rec.student.name,
                'class_name': rec.student.class_name,
                'status': rec.status,
                'status_display': dict(AttendanceRecord.STATUS_CHOICES).get(rec.status, rec.status),
                'seat_row': rec.seat_row,
                'seat_col': rec.seat_col,
                'check_in_time': rec.check_in_time.isoformat() if rec.check_in_time else None,
                'check_out_time': rec.check_out_time.isoformat() if rec.check_out_time else None,
            })

        return {
            'course': {
                'id': course.id,
                'name': course.name,
                'course_code': course.course_code,
                'teacher': course.teacher,
                'classroom': str(course.classroom),
                'weekday': course.weekday,
                'start_time': course.start_time.isoformat(),
                'end_time': course.end_time.isoformat(),
            },
            'date': query_date.isoformat(),
            'total_students': total,
            'stats': stats,
            'attendance_rate': attendance_rate,
            'records': record_list,
        }

    @staticmethod
    def get_daily_summary(query_date):
        """
        获取某天所有课程的考勤汇总
        """
        # 查询当天有考勤记录的课程
        courses_with_records = AttendanceRecord.objects.filter(
            course_date=query_date,
        ).values(
            'course__id', 'course__name', 'course__course_code',
            'course__teacher', 'course__classroom__name',
            'course__start_time', 'course__end_time',
        ).annotate(
            total=Count('id'),
            present=Count('id', filter=Q(status='present')),
            late=Count('id', filter=Q(status='late')),
            early_leave=Count('id', filter=Q(status='early_leave')),
            absent=Count('id', filter=Q(status='absent')),
        ).order_by('course__start_time')

        course_summaries = []
        overall_total = 0
        overall_present = 0

        for item in courses_with_records:
            rate = round(
                (item['present'] + item['late']) / item['total'] * 100, 1
            ) if item['total'] > 0 else 0
            course_summaries.append({
                'course_id': item['course__id'],
                'course_name': item['course__name'],
                'course_code': item['course__course_code'],
                'teacher': item['course__teacher'],
                'classroom': item['course__classroom__name'],
                'start_time': item['course__start_time'].isoformat(),
                'end_time': item['course__end_time'].isoformat(),
                'total_students': item['total'],
                'present': item['present'],
                'late': item['late'],
                'early_leave': item['early_leave'],
                'absent': item['absent'],
                'attendance_rate': rate,
            })
            overall_total += item['total']
            overall_present += item['present'] + item['late']

        overall_rate = round(
            overall_present / overall_total * 100, 1
        ) if overall_total > 0 else 0

        return {
            'date': query_date.isoformat(),
            'total_courses': len(course_summaries),
            'total_students': overall_total,
            'overall_attendance_rate': overall_rate,
            'courses': course_summaries,
        }

    @staticmethod
    def get_student_history(student_id, days):
        """
        获取某学生最近N天的考勤历史
        """
        student = Student.objects.get(id=student_id)
        start_date = timezone.now().date() - timedelta(days=days)

        records = AttendanceRecord.objects.filter(
            student=student,
            course_date__gte=start_date,
        ).select_related('course', 'course__classroom').order_by('-course_date', 'course__start_time')

        history = []
        stats = {'present': 0, 'late': 0, 'early_leave': 0, 'absent': 0}

        for rec in records:
            if rec.status in stats:
                stats[rec.status] += 1
            history.append({
                'id': rec.id,
                'date': rec.course_date.isoformat(),
                'course_name': rec.course.name,
                'course_code': rec.course.course_code,
                'teacher': rec.course.teacher,
                'classroom': str(rec.course.classroom),
                'status': rec.status,
                'status_display': dict(AttendanceRecord.STATUS_CHOICES).get(rec.status, rec.status),
                'check_in_time': rec.check_in_time.isoformat() if rec.check_in_time else None,
                'check_out_time': rec.check_out_time.isoformat() if rec.check_out_time else None,
            })

        total = records.count()
        effective = stats['present'] + stats['late']
        rate = round(effective / total * 100, 1) if total > 0 else 0

        return {
            'student': {
                'id': student.id,
                'student_id': student.student_id,
                'name': student.name,
                'class_name': student.class_name,
            },
            'days': days,
            'start_date': start_date.isoformat(),
            'total_records': total,
            'stats': stats,
            'attendance_rate': rate,
            'records': history,
        }
