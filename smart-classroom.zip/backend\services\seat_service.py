# -*- coding: utf-8 -*-
"""座位服务 - 座位占用网格与传感器模拟"""

import random
from datetime import timedelta
from django.utils import timezone
from django.db.models import Subquery, OuterRef

from core.models import Classroom, SeatOccupancy, Student


class SeatService:
    """座位相关业务逻辑"""

    @staticmethod
    def get_occupancy_grid(classroom_id):
        """
        获取教室今日座位占用网格
        返回2D网格数组，每个元素包含占用状态和学生信息
        """
        classroom = Classroom.objects.get(id=classroom_id)
        rows = classroom.rows_count
        cols = classroom.cols_count

        # 查询今日每个座位的最新占用记录
        today_start = timezone.now().replace(hour=0, minute=0, second=0, microsecond=0)

        # 使用子查询获取每个座位最新一条记录
        latest_occupancies = SeatOccupancy.objects.filter(
            classroom=classroom,
            timestamp__gte=today_start,
        ).order_by('-timestamp')

        # 构建座位字典 (row, col) -> 最新记录
        seat_map = {}
        for occ in latest_occupancies:
            key = (occ.row_num, occ.col_num)
            if key not in seat_map:
                seat_map[key] = occ

        # 预加载涉及的学号对应的学生信息
        student_ids = set()
        for occ in seat_map.values():
            if occ.student_id:
                student_ids.add(occ.student_id)
        students = {s.student_id: s.name for s in Student.objects.filter(student_id__in=student_ids)}

        # 构建2D网格
        seats = []
        occupied_count = 0
        for r in range(1, rows + 1):
            row_data = []
            for c in range(1, cols + 1):
                occ = seat_map.get((r, c))
                if occ and occ.is_occupied:
                    occupied_count += 1
                    row_data.append({
                        'row': r,
                        'col': c,
                        'is_occupied': True,
                        'student_id': occ.student_id,
                        'student_name': students.get(occ.student_id, ''),
                        'source': occ.source,
                        'timestamp': occ.timestamp.isoformat(),
                    })
                else:
                    row_data.append({
                        'row': r,
                        'col': c,
                        'is_occupied': False,
                        'student_id': '',
                        'student_name': '',
                        'source': occ.source if occ else '',
                        'timestamp': occ.timestamp.isoformat() if occ else None,
                    })
            seats.append(row_data)

        total_seats = rows * cols
        occupancy_rate = round(occupied_count / total_seats * 100, 1) if total_seats > 0 else 0

        return {
            'classroom_id': classroom.id,
            'classroom_name': str(classroom),
            'rows': rows,
            'cols': cols,
            'total_seats': total_seats,
            'occupied_count': occupied_count,
            'occupancy_rate': occupancy_rate,
            'seats': seats,
            'updated_at': timezone.now().isoformat(),
        }

    @staticmethod
    def simulate_sensor(classroom_id):
        """
        模拟传感器数据：随机占用30%-70%的座位
        创建 SeatOccupancy 记录
        """
        classroom = Classroom.objects.get(id=classroom_id)
        rows = classroom.rows_count
        cols = classroom.cols_count
        total_seats = rows * cols

        # 随机占用比例 30% - 70%
        ratio = random.uniform(0.3, 0.7)
        target_count = int(total_seats * ratio)

        # 获取所有学生用于随机分配
        students = list(Student.objects.all())
        if not students:
            return {
                'classroom_id': classroom.id,
                'classroom_name': str(classroom),
                'message': '没有学生数据，无法模拟',
                'occupied_count': 0,
            }

        # 随机选座位
        all_positions = [(r, c) for r in range(1, rows + 1) for c in range(1, cols + 1)]
        occupied_positions = random.sample(all_positions, min(target_count, len(all_positions)))

        # 随机选学生（不重复）
        selected_students = random.sample(students, min(len(occupied_positions), len(students)))

        now = timezone.now()
        records = []
        for i, (r, c) in enumerate(occupied_positions):
            student = selected_students[i % len(selected_students)]
            records.append(SeatOccupancy(
                classroom=classroom,
                row_num=r,
                col_num=c,
                is_occupied=True,
                student_id=student.student_id,
                source='simulator',
            ))

        # 未被选中的座位也记录为空
        occupied_set = set(occupied_positions)
        for r, c in all_positions:
            if (r, c) not in occupied_set:
                records.append(SeatOccupancy(
                    classroom=classroom,
                    row_num=r,
                    col_num=c,
                    is_occupied=False,
                    student_id='',
                    source='simulator',
                ))

        SeatOccupancy.objects.bulk_create(records)

        return {
            'classroom_id': classroom.id,
            'classroom_name': str(classroom),
            'total_seats': total_seats,
            'occupied_count': len(occupied_positions),
            'occupancy_rate': round(len(occupied_positions) / total_seats * 100, 1),
            'message': f'模拟完成，占用 {len(occupied_positions)}/{total_seats} 个座位',
        }
