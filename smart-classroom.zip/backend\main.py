# -*- coding: utf-8 -*-
"""
智能教室考勤与座位使用分析系统 - 主入口
启动顺序: MariaDB → Django → MQTT Broker → MQTT Client → 浏览器
"""

import os
import sys
import time
import signal
import logging
import subprocess
import threading
import webbrowser

# 确保项目根目录在路径中
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.django_settings')

from config.settings import (
    SERVER_HOST, SERVER_PORT,
    MQTT_BROKER_HOST, MQTT_BROKER_PORT, MQTT_CLIENT_ID,
    MARIADB_PORTABLE_DIR, MARIADB_DATA_DIR, MARIADB_BIN_DIR,
    MARIADB_USE_EMBEDDED, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD,
    DATA_DIR
)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger('SmartClassroom')


class MariaDBManager:
    """管理内嵌MariaDB的生命周期"""

    def __init__(self):
        self.process = None
        self.ready = False

    def start(self):
        """启动MariaDB"""
        mysqld = os.path.join(MARIADB_BIN_DIR, 'mysqld.exe')

        if not os.path.isfile(mysqld):
            logger.warning(f'MariaDB未找到: {mysqld}')
            logger.info('请运行 scripts/setup_mariadb.py 下载内嵌MariaDB')
            logger.info('或设置环境变量 USE_EMBEDDED_DB=0 并配置外部MySQL连接')
            return False

        logger.info('正在启动内嵌MariaDB...')
        os.makedirs(MARIADB_DATA_DIR, exist_ok=True)

        cmd = [
            mysqld,
            f'--port={DB_PORT}',
            f'--datadir={MARIADB_DATA_DIR}',
            '--bind-address=127.0.0.1',
            '--character-set-server=utf8mb4',
            '--collation-server=utf8mb4_unicode_ci',
            '--skip-grant-tables',  # 简化本地开发
            '--console',
        ]

        self.process = subprocess.Popen(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if sys.platform == 'win32' else 0
        )

        # 等待MariaDB就绪
        for i in range(30):
            if self._check_connection():
                self.ready = True
                logger.info(f'MariaDB已就绪 (端口 {DB_PORT})')
                return True
            time.sleep(1)

        logger.error('MariaDB启动超时')
        return False

    def _check_connection(self):
        """检查数据库是否可连接"""
        try:
            import pymysql
            conn = pymysql.connect(
                host='127.0.0.1', port=DB_PORT,
                user='root', password='',
                connect_timeout=2
            )
            conn.close()
            return True
        except Exception:
            return False

    def init_database(self):
        """初始化数据库（创建database和用户）"""
        try:
            import pymysql
            conn = pymysql.connect(
                host='127.0.0.1', port=DB_PORT,
                user='root', password='',
                connect_timeout=5
            )
            cursor = conn.cursor()
            cursor.execute(f'CREATE DATABASE IF NOT EXISTS `{DB_NAME}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci')
            if DB_PASSWORD:
                cursor.execute(f"CREATE USER IF NOT EXISTS '{DB_USER}'@'localhost' IDENTIFIED BY '{DB_PASSWORD}'")
                cursor.execute(f"GRANT ALL PRIVILEGES ON `{DB_NAME}`.* TO '{DB_USER}'@'localhost'")
                cursor.execute('FLUSH PRIVILEGES')
            conn.commit()
            conn.close()
            logger.info(f'数据库 {DB_NAME} 已就绪')
        except Exception as e:
            logger.error(f'初始化数据库失败: {e}')

    def stop(self):
        """停止MariaDB"""
        if self.process:
            logger.info('正在停止MariaDB...')
            self.process.terminate()
            try:
                self.process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self.process.kill()
            logger.info('MariaDB已停止')


def start_mqtt():
    """启动MQTT Broker和Client（可选，缺少依赖时自动跳过）"""
    try:
        from mqtt.broker import EmbeddedBroker
        from mqtt.client import MqttClient
        from mqtt.handlers import MqttMessageHandler
    except ImportError as e:
        logger.warning(f'MQTT依赖缺失({e})，跳过MQTT服务。如需MQTT请执行: pip install paho-mqtt amqtt')
        return None, None

    try:

        # 启动内嵌Broker
        broker = EmbeddedBroker()
        broker.start()
        logger.info(f'MQTT Broker已启动 ({MQTT_BROKER_HOST}:{MQTT_BROKER_PORT})')
        time.sleep(1)

        # 启动Client
        handler = MqttMessageHandler()
        client = MqttClient(client_id=MQTT_CLIENT_ID)
        client.connect(MQTT_BROKER_HOST, MQTT_BROKER_PORT)

        # 订阅所有教室的传感器和设备状态
        from core.models import Classroom
        for cr in Classroom.objects.all():
            client.subscribe_occupancy(cr.id, handler.handle_occupancy)
            client.subscribe_device_status(cr.id, handler.handle_device_status)

        # 订阅通配主题（新教室自动覆盖）
        client.subscribe('classroom/+/sensor/#', handler.handle_occupancy)
        client.subscribe('classroom/+/device/+/status', handler.handle_device_status)

        client.start()
        logger.info('MQTT Client已启动，正在监听传感器数据')

        return broker, client
    except Exception as e:
        logger.error(f'MQTT启动失败: {e}')
        return None, None


def start_django():
    """启动Django开发服务器"""
    from django.core.management import call_command

    # 数据库迁移
    logger.info('执行数据库迁移...')
    call_command('migrate', '--run-syncdb', verbosity=0)

    # 填充种子数据
    from utils.seed_data import seed_database
    seed_database()


def main():
    """主入口"""
    print('\n' + '=' * 56)
    print('  智能教室考勤与座位使用分析系统 v1.0')
    print(f'  Web管理界面: http://localhost:{SERVER_PORT}')
    print(f'  MQTT Broker: mqtt://localhost:{MQTT_BROKER_PORT}')
    print('=' * 56 + '\n')

    db_manager = None
    mqtt_broker = None
    mqtt_client = None

    def cleanup(signum=None, frame=None):
        """清理资源"""
        print('\n正在关闭系统...')
        if mqtt_client:
            mqtt_client.stop()
        if mqtt_broker:
            mqtt_broker.stop()
        if db_manager:
            db_manager.stop()
        sys.exit(0)

    signal.signal(signal.SIGINT, cleanup)
    signal.signal(signal.SIGTERM, cleanup)

    # 1. 启动MariaDB（仅在使用MySQL模式时）
    from config.django_settings import USE_SQLITE
    if MARIADB_USE_EMBEDDED and not USE_SQLITE:
        db_manager = MariaDBManager()
        if db_manager.start():
            db_manager.init_database()
        else:
            logger.warning('内嵌MariaDB启动失败，回退到SQLite模式')
            os.environ['USE_SQLITE'] = '1'
            # 重新初始化Django设置
            from django.conf import settings as dj_settings
            from importlib import reload
            import config.django_settings
            reload(config.django_settings)
    elif USE_SQLITE:
        logger.info('使用SQLite数据库模式（无需MariaDB）')

    # 2. 初始化Django（迁移 + 种子数据）
    import django
    django.setup()
    start_django()

    # 3. 启动MQTT
    mqtt_broker, mqtt_client = start_mqtt()

    # 4. 自动打开浏览器
    url = f'http://localhost:{SERVER_PORT}'
    threading.Timer(2, lambda: webbrowser.open(url)).start()

    # 5. 启动Django HTTP服务器
    logger.info(f'HTTP服务启动在 {url}')
    from django.core.management import call_command
    try:
        call_command('runserver', f'{SERVER_HOST}:{SERVER_PORT}', use_reloader=False)
    except KeyboardInterrupt:
        cleanup()


if __name__ == '__main__':
    main()
