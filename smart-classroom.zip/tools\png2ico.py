# -*- coding: utf-8 -*-
"""将 PNG 图标转换为 Windows ICO 格式（多尺寸）"""

import struct
import zlib
import os
import sys


def png_to_ico(png_path, ico_path):
    """纯Python实现PNG→ICO转换，无需Pillow依赖"""
    with open(png_path, 'rb') as f:
        png_data = f.read()

    # 读取PNG尺寸
    if png_data[:8] != b'\x89PNG\r\n\x1a\n':
        raise ValueError('Not a valid PNG file')
    width = struct.unpack('>I', png_data[16:20])[0]
    height = struct.unpack('>I', png_data[20:24])[0]

    # ICO需要多个尺寸，这里直接用原始PNG嵌入（Windows Vista+支持）
    sizes = []
    # 如果原图够大，生成多个尺寸标记
    for s in [256, 128, 64, 48, 32, 16]:
        if width >= s:
            sizes.append(s)
        if len(sizes) >= 3:
            break

    if not sizes:
        sizes = [width]

    # ICO Header
    num_images = 1  # 只嵌入一个PNG（Windows支持PNG-in-ICO）
    header = struct.pack('<HHH', 0, 1, num_images)  # Reserved, Type=ICO, Count

    # ICO Directory Entry
    w = 0 if width >= 256 else width  # 0 means 256
    h = 0 if height >= 256 else height
    data_offset = 6 + 16 * num_images  # header + entries
    entry = struct.pack('<BBBBHHII',
                        w, h, 0, 0, 1, 32,  # width, height, colors, reserved, planes, bpp
                        len(png_data), data_offset)

    # Write ICO
    with open(ico_path, 'wb') as f:
        f.write(header)
        f.write(entry)
        f.write(png_data)

    print(f'ICO created: {ico_path} ({os.path.getsize(ico_path)} bytes)')


if __name__ == '__main__':
    if len(sys.argv) < 2:
        base = os.path.dirname(os.path.abspath(__file__))
        png = os.path.join(base, 'assets', 'icon.png')
        ico = os.path.join(base, 'assets', 'icon.ico')
    else:
        png = sys.argv[1]
        ico = sys.argv[2] if len(sys.argv) > 2 else png.rsplit('.', 1)[0] + '.ico'

    if not os.path.isfile(png):
        print(f'PNG not found: {png}')
        sys.exit(1)

    png_to_ico(png, ico)
