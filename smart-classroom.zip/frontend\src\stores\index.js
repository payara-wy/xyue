import { defineStore } from 'pinia'
import { ref } from 'vue'
import { getClassrooms, getCourses, getStudents } from '../api'

export const useAppStore = defineStore('app', () => {
  const classrooms = ref([])
  const courses = ref([])
  const students = ref([])
  const selectedClassroomId = ref(null)
  const selectedCourseId = ref(null)
  const loading = ref(false)

  async function fetchClassrooms() {
    try {
      loading.value = true
      const res = await getClassrooms()
      classrooms.value = res.data || []
      if (classrooms.value.length > 0 && !selectedClassroomId.value) {
        selectedClassroomId.value = classrooms.value[0].id
      }
    } catch (e) {
      console.error('Failed to fetch classrooms:', e)
    } finally {
      loading.value = false
    }
  }

  async function fetchCourses() {
    try {
      const res = await getCourses()
      courses.value = res.data || []
      if (courses.value.length > 0 && !selectedCourseId.value) {
        selectedCourseId.value = courses.value[0].id
      }
    } catch (e) {
      console.error('Failed to fetch courses:', e)
    }
  }

  async function fetchStudents() {
    try {
      const res = await getStudents()
      students.value = res.data || []
    } catch (e) {
      console.error('Failed to fetch students:', e)
    }
  }

  return {
    classrooms,
    courses,
    students,
    selectedClassroomId,
    selectedCourseId,
    loading,
    fetchClassrooms,
    fetchCourses,
    fetchStudents
  }
})
