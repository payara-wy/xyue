@echo off
chcp 65001 >nul 2>&1
setlocal EnableDelayedExpansion

REM ============================================================
REM  智能教室系统 - 设置管理
REM ============================================================

cd /d "%~dp0"

:menu
cls
echo.
echo  ╔══════════════════════════════════════════════╗
echo  ║   智能教室系统 - 设置                        ║
echo  ╠══════════════════════════════════════════════╣
echo  ║                                              ║
echo  ║   1. 开启 开机自启动                         ║
echo  ║   2. 关闭 开机自启动                         ║
echo  ║   3. 重新创建 桌面快捷方式                   ║
echo  ║   4. 重置系统 (清除数据重新初始化)           ║
echo  ║   5. 查看 系统信息                           ║
echo  ║   0. 退出                                    ║
echo  ║                                              ║
echo  ╚══════════════════════════════════════════════╝
echo.
set /p "choice=  请选择 (0-5): "

if "%choice%"=="1" goto enable_autostart
if "%choice%"=="2" goto disable_autostart
if "%choice%"=="3" goto create_shortcut
if "%choice%"=="4" goto reset_system
if "%choice%"=="5" goto show_info
if "%choice%"=="0" exit /b 0
goto menu

:enable_autostart
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "SmartClassroom" /t REG_SZ /d "\"%~dp0run.bat\" --silent" /f >nul 2>&1
echo.
echo  [OK] 已开启开机自启动
timeout /t 2 /nobreak >nul
goto menu

:disable_autostart
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "SmartClassroom" /f >nul 2>&1
echo.
echo  [OK] 已关闭开机自启动
timeout /t 2 /nobreak >nul
goto menu

:create_shortcut
del "%~dp0data\.shortcut_created" >nul 2>&1
"%~dp0run.bat" --silent
echo.
echo  [OK] 桌面快捷方式已重新创建
timeout /t 2 /nobreak >nul
goto menu

:reset_system
echo.
set /p "confirm=  确认重置? 这将清除所有数据 (Y/N): "
if /i not "%confirm%"=="Y" goto menu
if exist "%~dp0data" rmdir /s /q "%~dp0data"
echo  [OK] 数据已清除，下次启动将自动重新初始化
timeout /t 2 /nobreak >nul
goto menu

:show_info
echo.
echo  ══════════════════════════════════
if exist "%~dp0VERSION.txt" type "%~dp0VERSION.txt"
echo.
echo  安装路径: %~dp0
echo  数据目录: %~dp0data
if exist "%~dp0runtime\python\python.exe" (
    echo  Python:   便携版 (runtime\python)
) else (
    echo  Python:   系统安装版
)
if exist "%~dp0runtime\mariadb\bin\mysqld.exe" (
    echo  数据库:   MariaDB 便携版
) else (
    echo  数据库:   SQLite
)
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "SmartClassroom" >nul 2>&1
if !errorlevel! equ 0 (
    echo  自启动:   已开启
) else (
    echo  自启动:   未开启
)
echo  ══════════════════════════════════
echo.
pause
goto menu

endlocal
