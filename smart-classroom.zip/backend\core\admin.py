# -*- coding: utf-8 -*-
"""Django Admin注册（可选，用于调试）"""

from django.contrib import admin
from .models import Classroom, Course, Student, SeatOccupancy, AttendanceRecord, DeviceStatus, Alert

for model in [Classroom, Course, Student, SeatOccupancy, AttendanceRecord, DeviceStatus, Alert]:
    admin.site.register(model)
