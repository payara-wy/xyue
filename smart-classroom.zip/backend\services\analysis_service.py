# -*- coding: utf-8 -*-
"""分析服务 - 热力图、区域偏好、跨课程分析"""

from datetime import timedelta
from django.utils import timezone
from django.db.models import Count, Avg, Q, F

from core.models import Classroom, Course, AttendanceRecord


class AnalysisService:
    """数据分析相关业务逻辑"""

    @staticmethod
    def get_heatmap(classroom_id, course_id=None, date_from=None, date_to=None):
        """
        获取教室座位热力图
        统计每个座位的使用频次，归一化到0-1强度
        同时分析区域偏好（前/中/后、左/中/右）
        """
        classroom = Classroom.objects.get(id=classroom_id)
        rows = classroom.rows_count
        cols = classroom.cols_count

        # 构建查询条件
        filters = Q(course__classroom=classroom)
        if course_id:
            filters &= Q(course_id=course_id)
        if date_from:
            filters &= Q(course_date__gte=date_from)
        if date_to:
            filters &= Q(course_date__lte=date_to)

        # 统计每个座位被使用的次数（status 为 present 或 late 表示有人坐）
        seat_counts = AttendanceRecord.objects.filter(
            filters,
            status__in=['present', 'late'],
            seat_row__gte=1,
            seat_col__gte=1,
        ).values('seat_row', 'seat_col').annotate(
            count=Count('id')
        )

        # 构建计数矩阵
        count_map = {}
        max_count = 0
        for item in seat_counts:
            key = (item['seat_row'], item['seat_col'])
            count_map[key] = item['count']
            if item['count'] > max_count:
                max_count = item['count']

        # 构建强度网格 (0-1)
        grid = []
        total_usage = 0
        for r in range(1, rows + 1):
            row_data = []
            for c in range(1, cols + 1):
                count = count_map.get((r, c), 0)
                intensity = round(count / max_count, 2) if max_count > 0 else 0
                row_data.append({
                    'row': r,
                    'col': c,
                    'count': count,
                    'intensity': intensity,
                })
                total_usage += count
            grid.append(row_data)

        # 区域偏好分析
        zone_analysis = AnalysisService._analyze_zones(count_map, rows, cols)

        return {
            'classroom_id': classroom.id,
            'classroom_name': str(classroom),
            'rows': rows,
            'cols': cols,
            'max_count': max_count,
            'total_usage': total_usage,
            'grid': grid,
            'zone_analysis': zone_analysis,
            'filters': {
                'course_id': course_id,
                'date_from': date_from.isoformat() if date_from else None,
                'date_to': date_to.isoformat() if date_to else None,
            },
        }

    @staticmethod
    def _analyze_zones(count_map, rows, cols):
        """
        分析区域偏好
        纵向分区：前(1/3)、中(1/3)、后(1/3)
        横向分区：左(1/3)、中(1/3)、右(1/3)
        """
        # 纵向分区边界
        front_end = rows // 3
        mid_end = rows * 2 // 3

        # 横向分区边界
        left_end = cols // 3
        center_end = cols * 2 // 3

        vertical = {'front': 0, 'middle': 0, 'back': 0}
        horizontal = {'left': 0, 'center': 0, 'right': 0}

        for (r, c), count in count_map.items():
            # 纵向
            if r <= front_end:
                vertical['front'] += count
            elif r <= mid_end:
                vertical['middle'] += count
            else:
                vertical['back'] += count

            # 横向
            if c <= left_end:
                horizontal['left'] += count
            elif c <= center_end:
                horizontal['center'] += count
            else:
                horizontal['right'] += count

        # 计算百分比
        v_total = sum(vertical.values()) or 1
        h_total = sum(horizontal.values()) or 1

        def _to_pct(d, total):
            return {k: round(v / total * 100, 1) for k, v in d.items()}

        # 找出偏好区域
        v_preferred = max(vertical, key=vertical.get) if v_total > 0 else 'middle'
        h_preferred = max(horizontal, key=horizontal.get) if h_total > 0 else 'center'

        zone_labels = {
            'front': '前排', 'middle': '中排', 'back': '后排',
            'left': '左侧', 'center': '中间', 'right': '右侧',
        }

        return {
            'vertical': {
                'counts': vertical,
                'percentages': _to_pct(vertical, v_total),
                'preferred': v_preferred,
                'preferred_label': zone_labels[v_preferred],
            },
            'horizontal': {
                'counts': horizontal,
                'percentages': _to_pct(horizontal, h_total),
                'preferred': h_preferred,
                'preferred_label': zone_labels[h_preferred],
            },
            'summary': f'学生偏好坐在{zone_labels[v_preferred]}{zone_labels[h_preferred]}区域',
        }

    @staticmethod
    def get_cross_course_analysis():
        """
        跨课程分析：比较各课程在不同教室的平均座位位置
        了解不同课程的选座模式差异
        """
        # 按课程分组，计算平均行号和列号
        course_stats = AttendanceRecord.objects.filter(
            status__in=['present', 'late'],
            seat_row__gte=1,
            seat_col__gte=1,
        ).values(
            'course__id', 'course__name', 'course__course_code',
            'course__teacher', 'course__classroom__id',
            'course__classroom__name',
        ).annotate(
            avg_row=Avg('seat_row'),
            avg_col=Avg('seat_col'),
            total_attendance=Count('id'),
        ).order_by('course__classroom__name', 'course__name')

        # 按教室分组汇总
        classrooms = {}
        for item in course_stats:
            cr_id = item['course__classroom__id']
            cr_name = item['course__classroom__name']
            if cr_id not in classrooms:
                classrooms[cr_id] = {
                    'classroom_id': cr_id,
                    'classroom_name': cr_name,
                    'courses': [],
                }
            classrooms[cr_id]['courses'].append({
                'course_id': item['course__id'],
                'course_name': item['course__name'],
                'course_code': item['course__course_code'],
                'teacher': item['course__teacher'],
                'avg_row': round(item['avg_row'], 1),
                'avg_col': round(item['avg_col'], 1),
                'total_attendance': item['total_attendance'],
            })

        return {
            'classrooms': list(classrooms.values()),
            'total_courses': len(course_stats),
        }
