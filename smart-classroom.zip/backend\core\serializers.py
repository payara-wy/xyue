# -*- coding: utf-8 -*-
"""DRF 序列化器 - 智能教室全部模型"""

from rest_framework import serializers
from core.models import (
    Classroom, Course, Student, SeatOccupancy,
    AttendanceRecord, DeviceStatus, Alert,
)


class ClassroomSerializer(serializers.ModelSerializer):
    """教室序列化器，含计算字段 total_seats"""
    total_seats = serializers.IntegerField(read_only=True)

    class Meta:
        model = Classroom
        fields = [
            'id', 'name', 'building', 'rows_count', 'cols_count',
            'has_projector', 'total_seats', 'created_at',
        ]


class CourseSerializer(serializers.ModelSerializer):
    """课程序列化器，含教室名称"""
    classroom_name = serializers.CharField(source='classroom.__str__', read_only=True)

    class Meta:
        model = Course
        fields = [
            'id', 'name', 'course_code', 'teacher', 'classroom',
            'classroom_name', 'weekday', 'start_time', 'end_time', 'created_at',
        ]


class StudentSerializer(serializers.ModelSerializer):
    """学生序列化器"""

    class Meta:
        model = Student
        fields = ['id', 'student_id', 'name', 'class_name', 'beacon_id', 'created_at']


class SeatOccupancySerializer(serializers.ModelSerializer):
    """座位占用记录序列化器"""

    class Meta:
        model = SeatOccupancy
        fields = [
            'id', 'classroom', 'row_num', 'col_num',
            'is_occupied', 'student_id', 'source', 'timestamp',
        ]


class AttendanceRecordSerializer(serializers.ModelSerializer):
    """考勤记录序列化器，含学生姓名和课程名"""
    student_name = serializers.CharField(source='student.name', read_only=True)
    course_name = serializers.CharField(source='course.name', read_only=True)

    class Meta:
        model = AttendanceRecord
        fields = [
            'id', 'course', 'course_name', 'student', 'student_name',
            'status', 'seat_row', 'seat_col',
            'check_in_time', 'check_out_time', 'course_date', 'created_at',
        ]


class DeviceStatusSerializer(serializers.ModelSerializer):
    """设备状态序列化器，含教室名称"""
    classroom_name = serializers.CharField(source='classroom.__str__', read_only=True)

    class Meta:
        model = DeviceStatus
        fields = [
            'id', 'classroom', 'classroom_name',
            'device_type', 'is_on', 'last_changed',
        ]


class AlertSerializer(serializers.ModelSerializer):
    """告警记录序列化器，含教室名称"""
    classroom_name = serializers.CharField(source='classroom.__str__', read_only=True)

    class Meta:
        model = Alert
        fields = [
            'id', 'classroom', 'classroom_name', 'alert_type',
            'message', 'severity', 'is_resolved',
            'created_at', 'resolved_at',
        ]


class ClassroomOccupancyGridSerializer(serializers.Serializer):
    """教室座位网格序列化器 - 用于返回2D座位图数据"""
    classroom_id = serializers.IntegerField()
    classroom_name = serializers.CharField()
    rows = serializers.IntegerField()
    cols = serializers.IntegerField()
    total_seats = serializers.IntegerField()
    occupied_count = serializers.IntegerField()
    occupancy_rate = serializers.FloatField()
    seats = serializers.ListField()  # 2D数组 [[{row, col, is_occupied, student_id, student_name}, ...]]
    updated_at = serializers.DateTimeField(allow_null=True)
