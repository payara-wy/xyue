import axios from 'axios'

const api = axios.create({
  baseURL: '/api/',
  timeout: 15000
})

api.interceptors.response.use(
  response => response,
  error => {
    console.error('API Error:', error.message)
    return Promise.reject(error)
  }
)

// Classrooms
export const getClassrooms = () => api.get('classrooms/')
export const getOccupancyGrid = (id) => api.get(`classrooms/${id}/occupancy-grid/`)
export const simulateSensor = (id) => api.post(`classrooms/${id}/simulate-sensor/`)

// Courses
export const getCourses = () => api.get('courses/')

// Students
export const getStudents = () => api.get('students/')

// Attendance
export const getCourseAttendance = (id, date) =>
  api.get(`attendance/course/${id}/`, { params: { date } })
export const getDailySummary = (date) =>
  api.get('attendance/daily-summary/', { params: { date } })
export const getStudentHistory = (id, days = 30) =>
  api.get(`attendance/student/${id}/history/`, { params: { days } })

// Analysis
export const getHeatmap = (classroomId, params = {}) =>
  api.get(`analysis/heatmap/${classroomId}/`, { params })
export const getCrossCourse = () => api.get('analysis/cross-course/')

// Utilization
export const getClassroomUtilization = (id, params = {}) =>
  api.get(`utilization/classroom/${id}/`, { params })
export const getUtilizationCompare = (params = {}) =>
  api.get('utilization/compare/', { params })

// Alerts
export const getAlerts = () => api.get('alerts/')
export const getActiveAlerts = (classroomId) =>
  api.get('alerts/active/', { params: { classroom_id: classroomId } })
export const getAlertStatistics = () => api.get('alerts/statistics/')
export const resolveAlert = (id) => api.post(`alerts/${id}/resolve/`)
export const resolveAllAlerts = () => api.post('alerts/resolve-all/')
export const runDetection = () => api.post('alerts/detection/')

// Devices
export const getDevices = () => api.get('devices/')
export const toggleDevice = (data) => api.post('devices/toggle/', data)

export default api
