<template>
  <div class="heatmap-container">
    <div class="podium">讲 台</div>
    <div class="heatmap-grid">
      <div v-for="(row, rIdx) in grid" :key="rIdx" class="heatmap-row">
        <div
          v-for="(cell, cIdx) in row"
          :key="`${rIdx}-${cIdx}`"
          class="heat-cell"
          :style="{ background: getColor(cell.intensity || 0) }"
        >
          {{ cell.count || 0 }}
          <div class="tooltip">
            第{{ rIdx + 1 }}排 第{{ cIdx + 1 }}列 · 使用{{ cell.count || 0 }}次
          </div>
        </div>
      </div>
    </div>
    <div class="heatmap-legend">
      <span>低频</span>
      <div class="heatmap-legend-bar"></div>
      <span>高频</span>
    </div>
  </div>
</template>

<script setup>
const props = defineProps({
  rows: { type: Number, default: 0 },
  cols: { type: Number, default: 0 },
  grid: { type: Array, default: () => [] },
  maxCount: { type: Number, default: 1 }
})

function getColor(intensity) {
  const t = Math.max(0, Math.min(1, intensity || 0))
  if (t < 0.25) {
    return lerpColor('#e8f5e9', '#fff9c4', t / 0.25)
  } else if (t < 0.5) {
    return lerpColor('#fff9c4', '#ffcc02', (t - 0.25) / 0.25)
  } else if (t < 0.75) {
    return lerpColor('#ffcc02', '#ff9800', (t - 0.5) / 0.25)
  } else {
    return lerpColor('#ff9800', '#e63946', (t - 0.75) / 0.25)
  }
}

function lerpColor(a, b, t) {
  const ar = parseInt(a.slice(1, 3), 16)
  const ag = parseInt(a.slice(3, 5), 16)
  const ab = parseInt(a.slice(5, 7), 16)
  const br = parseInt(b.slice(1, 3), 16)
  const bg = parseInt(b.slice(3, 5), 16)
  const bb = parseInt(b.slice(5, 7), 16)
  const rr = Math.round(ar + (br - ar) * t)
  const rg = Math.round(ag + (bg - ag) * t)
  const rb = Math.round(ab + (bb - ab) * t)
  return `#${rr.toString(16).padStart(2, '0')}${rg.toString(16).padStart(2, '0')}${rb.toString(16).padStart(2, '0')}`
}
</script>
