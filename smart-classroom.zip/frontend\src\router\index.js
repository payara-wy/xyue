import { createRouter, createWebHistory } from 'vue-router'

const routes = [
  {
    path: '/',
    redirect: '/seat'
  },
  {
    path: '/seat',
    name: 'Seat',
    component: () => import('../views/SeatView.vue')
  },
  {
    path: '/attendance',
    name: 'Attendance',
    component: () => import('../views/AttendanceView.vue')
  },
  {
    path: '/analysis',
    name: 'Analysis',
    component: () => import('../views/AnalysisView.vue')
  },
  {
    path: '/utilization',
    name: 'Utilization',
    component: () => import('../views/UtilizationView.vue')
  },
  {
    path: '/alert',
    name: 'Alert',
    component: () => import('../views/AlertView.vue')
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router
