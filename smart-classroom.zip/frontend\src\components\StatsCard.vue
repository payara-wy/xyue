<template>
  <div class="stat-card">
    <div class="stat-icon" :class="color">
      {{ icon }}
    </div>
    <div class="stat-info">
      <div class="stat-value">{{ displayValue }}</div>
      <div class="stat-label">{{ label }}</div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  icon: { type: String, default: '📊' },
  value: { type: [Number, String], default: 0 },
  label: { type: String, default: '' },
  color: { type: String, default: 'blue' }
})

const displayValue = computed(() => {
  if (typeof props.value === 'number') {
    if (props.value >= 1000) {
      return props.value.toLocaleString()
    }
    return props.value
  }
  return props.value
})
</script>
