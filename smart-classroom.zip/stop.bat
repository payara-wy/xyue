@echo off
chcp 65001 >nul 2>&1
setlocal EnableDelayedExpansion

REM ============================================================
REM  停止智能教室全部服务 + 系统通知
REM ============================================================

cd /d "%~dp0"

echo.
echo  正在停止智能教室系统...
echo.

REM 停止Django应用
taskkill /f /fi "WINDOWTITLE eq SmartClassroom-Server" >nul 2>&1
for /f "tokens=2" %%p in ('netstat -aon 2^>nul ^| findstr ":8089.*LISTENING"') do (
    taskkill /f /pid %%p >nul 2>&1
)
echo  [OK] 应用服务已停止

REM 停止MariaDB
taskkill /f /im mysqld.exe >nul 2>&1
echo  [OK] MariaDB 已停止

REM 停止MQTT端口上的进程
for /f "tokens=2" %%p in ('netstat -aon 2^>nul ^| findstr ":1883.*LISTENING"') do (
    taskkill /f /pid %%p >nul 2>&1
)
echo  [OK] MQTT Broker 已停止

REM 系统通知
powershell -WindowStyle Hidden -Command "[System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms')|Out-Null;$n=New-Object System.Windows.Forms.NotifyIcon;$n.Icon=[System.Drawing.SystemIcons]::Information;$n.Visible=$true;$n.ShowBalloonTip(3000,'智能教室系统','所有服务已安全停止',[System.Windows.Forms.ToolTipIcon]::Info);Start-Sleep 4;$n.Dispose()" >nul 2>&1

echo.
echo  所有服务已安全停止.
echo.
timeout /t 3 /nobreak >nul

endlocal
