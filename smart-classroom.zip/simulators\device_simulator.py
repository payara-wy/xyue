#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
设备控制模拟器 - 模拟智能教室设备（投影仪/灯光/空调）

独立运行，不依赖Django。订阅设备控制指令主题，
模拟设备响应并回报状态。支持键盘手动控制。

用法:
    python device_simulator.py [--broker localhost] [--port 1883] [--classroom 1]
"""

import argparse
import json
import random
import signal
import sys
import threading
import time
from datetime import datetime

import paho.mqtt.client as mqtt


# ============ ANSI颜色代码 ============
class Colors:
    """终端ANSI颜色"""
    RESET = '\033[0m'
    BOLD = '\033[1m'
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GRAY = '\033[90m'
    MAGENTA = '\033[95m'


# ============ 设备定义 ============
DEVICE_TYPES = {
    'projector': {'name': '投影仪', 'icon': '📽️', 'delay_range': (1.0, 2.5)},
    'light':     {'name': '灯光',   'icon': '💡', 'delay_range': (0.3, 0.8)},
    'ac':        {'name': '空调',   'icon': '❄️', 'delay_range': (1.5, 3.0)},
}


# ============ 全局状态 ============
running = True


def signal_handler(sig, frame):
    """优雅退出信号处理"""
    global running
    print(f'\n{Colors.YELLOW}收到退出信号，正在关闭...{Colors.RESET}')
    running = False


def timestamp_str():
    """当前时间字符串"""
    return datetime.now().strftime('%H:%M:%S')


class DeviceSimulator:
    """设备模拟器，管理单个教室的所有设备状态"""

    def __init__(self, classroom_id, broker, port):
        self.classroom_id = classroom_id
        self.broker = broker
        self.port = port

        # 设备状态: {device_type: {'is_on': bool, 'last_changed': float}}
        self.devices = {}
        for dtype in DEVICE_TYPES:
            self.devices[dtype] = {
                'is_on': False,
                'last_changed': time.time(),
            }

        # MQTT客户端
        client_id = f'device_simulator_{classroom_id}_{int(time.time())}'
        self.client = mqtt.Client(client_id=client_id)
        self.client.on_connect = self._on_connect
        self.client.on_disconnect = self._on_disconnect
        self.client.on_message = self._on_message

        self._lock = threading.Lock()

    def _on_connect(self, client, userdata, flags, rc):
        """连接回调：订阅设备指令主题"""
        if rc == 0:
            print(f'{Colors.GREEN}✓ 已连接到MQTT Broker ({self.broker}:{self.port}){Colors.RESET}')
            # 订阅该教室所有设备类型的指令（通配符）
            cmd_topic = f'classroom/{self.classroom_id}/device/+/cmd'
            client.subscribe(cmd_topic, qos=1)
            print(f'{Colors.CYAN}已订阅指令主题: {cmd_topic}{Colors.RESET}')
        else:
            print(f'{Colors.RED}✗ 连接失败，返回码: {rc}{Colors.RESET}')

    def _on_disconnect(self, client, userdata, rc):
        """断连回调"""
        if rc != 0:
            print(f'{Colors.YELLOW}⚠ 连接断开(rc={rc})，等待自动重连...{Colors.RESET}')

    def _on_message(self, client, userdata, msg):
        """
        消息回调：处理设备控制指令
        主题格式: classroom/{id}/device/{type}/cmd
        消息格式: {"action": "on"/"off", "timestamp": ...}
        """
        try:
            # 从主题中解析设备类型
            parts = msg.topic.split('/')
            if len(parts) < 5:
                print(f'{Colors.RED}主题格式异常: {msg.topic}{Colors.RESET}')
                return

            device_type = parts[3]  # classroom/1/device/projector/cmd -> projector
            payload = json.loads(msg.payload.decode('utf-8'))
            action = payload.get('action', '').lower()

            if device_type not in DEVICE_TYPES:
                print(f'{Colors.YELLOW}未知设备类型: {device_type}{Colors.RESET}')
                return

            if action not in ('on', 'off'):
                print(f'{Colors.YELLOW}无效指令: {action} (应为 on/off){Colors.RESET}')
                return

            device_info = DEVICE_TYPES[device_type]
            target_state = (action == 'on')

            # 打印收到的指令
            print(f'\n{Colors.MAGENTA}[{timestamp_str()}] 收到指令{Colors.RESET}'
                  f' {device_info["icon"]} {device_info["name"]} -> '
                  f'{Colors.GREEN if target_state else Colors.RED}'
                  f'{"开启" if target_state else "关闭"}{Colors.RESET}')

            # 模拟设备响应延迟
            delay_min, delay_max = device_info['delay_range']
            delay = random.uniform(delay_min, delay_max)
            print(f'  {Colors.GRAY}设备响应中... (预计 {delay:.1f}s){Colors.RESET}')

            # 在延迟后更新状态并回报（使用线程避免阻塞消息循环）
            threading.Thread(
                target=self._process_command,
                args=(device_type, target_state, delay),
                daemon=True
            ).start()

        except json.JSONDecodeError as e:
            print(f'{Colors.RED}JSON解析失败: {e}{Colors.RESET}')
        except Exception as e:
            print(f'{Colors.RED}处理指令出错: {e}{Colors.RESET}')

    def _process_command(self, device_type, target_state, delay):
        """处理设备指令：等待延迟后更新状态并回报"""
        time.sleep(delay)

        with self._lock:
            current = self.devices[device_type]['is_on']
            self.devices[device_type]['is_on'] = target_state
            self.devices[device_type]['last_changed'] = time.time()

        device_info = DEVICE_TYPES[device_type]

        if current == target_state:
            print(f'  {Colors.YELLOW}[{timestamp_str()}] {device_info["name"]}已处于'
                  f'{"开启" if target_state else "关闭"}状态，无需操作{Colors.RESET}')
        else:
            print(f'  {Colors.GREEN}[{timestamp_str()}] {device_info["icon"]} {device_info["name"]}'
                  f' 已{"开启" if target_state else "关闭"} (耗时 {delay:.1f}s){Colors.RESET}')

        # 发布状态回报
        status_topic = f'classroom/{self.classroom_id}/device/{device_type}/status'
        status_payload = json.dumps({
            'is_on': target_state,
            'timestamp': time.time(),
        })
        self.client.publish(status_topic, status_payload, qos=1)

    def publish_all_status(self):
        """发布所有设备的当前状态"""
        for dtype, state in self.devices.items():
            status_topic = f'classroom/{self.classroom_id}/device/{dtype}/status'
            payload = json.dumps({
                'is_on': state['is_on'],
                'timestamp': time.time(),
            })
            self.client.publish(status_topic, payload, qos=1)

    def manual_toggle(self, device_type, action):
        """手动控制设备（键盘输入）"""
        if device_type not in DEVICE_TYPES:
            print(f'{Colors.RED}未知设备: {device_type} (可选: projector, light, ac){Colors.RESET}')
            return
        if action not in ('on', 'off'):
            print(f'{Colors.RED}无效操作: {action} (可选: on, off){Colors.RESET}')
            return

        target_state = (action == 'on')
        device_info = DEVICE_TYPES[device_type]

        with self._lock:
            self.devices[device_type]['is_on'] = target_state
            self.devices[device_type]['last_changed'] = time.time()

        # 发布状态
        status_topic = f'classroom/{self.classroom_id}/device/{device_type}/status'
        payload = json.dumps({
            'is_on': target_state,
            'timestamp': time.time(),
        })
        self.client.publish(status_topic, payload, qos=1)

        state_text = '开启' if target_state else '关闭'
        print(f'{Colors.GREEN}[{timestamp_str()}] 手动操作: '
              f'{device_info["icon"]} {device_info["name"]} -> {state_text}{Colors.RESET}')

    def print_status(self):
        """打印所有设备当前状态"""
        print(f'\n{Colors.BOLD}{Colors.CYAN}  ┌─────────────────────────────────┐')
        print(f'  │   教室 #{self.classroom_id} 设备状态    │')
        print(f'  ├─────────────────────────────────┤{Colors.RESET}')

        for dtype, state in self.devices.items():
            info = DEVICE_TYPES[dtype]
            is_on = state['is_on']
            status_color = Colors.GREEN if is_on else Colors.RED
            status_text = 'ON ' if is_on else 'OFF'
            changed = datetime.fromtimestamp(state['last_changed']).strftime('%H:%M:%S')

            print(f'  {Colors.CYAN}│{Colors.RESET}'
                  f' {info["icon"]} {info["name"]:<6} '
                  f'{status_color}{Colors.BOLD}[{status_text}]{Colors.RESET}'
                  f'  {Colors.GRAY}(变更: {changed}){Colors.RESET}'
                  f'{Colors.CYAN}│{Colors.RESET}')

        print(f'{Colors.BOLD}{Colors.CYAN}  └─────────────────────────────────┘{Colors.RESET}')
        print()

    def start(self):
        """启动设备模拟器"""
        # 连接Broker
        try:
            self.client.connect(self.broker, self.port, keepalive=60)
        except Exception as e:
            print(f'{Colors.RED}✗ 无法连接到Broker: {e}{Colors.RESET}')
            sys.exit(1)

        self.client.reconnect_delay_set(min_delay=1, max_delay=30)
        self.client.loop_start()

        # 等待连接
        time.sleep(1)

        # 发布初始状态
        self.publish_all_status()
        self.print_status()

    def stop(self):
        """停止设备模拟器"""
        self.client.loop_stop()
        self.client.disconnect()


def keyboard_input_loop(simulator):
    """
    键盘输入处理循环（在独立线程中运行）
    支持的命令格式:
      on projector   - 开启投影仪
      off light      - 关闭灯光
      on ac          - 开启空调
      status         - 显示设备状态
      help           - 显示帮助
    """
    print(f'{Colors.GRAY}输入命令控制设备 (输入 help 查看帮助, Ctrl+C 退出):{Colors.RESET}')

    while running:
        try:
            user_input = input(f'{Colors.BOLD}> {Colors.RESET}').strip().lower()
            if not user_input:
                continue

            parts = user_input.split()
            cmd = parts[0]

            if cmd == 'help':
                print(f'''
{Colors.CYAN}可用命令:{Colors.RESET}
  {Colors.GREEN}on{Colors.RESET} <device>    开启设备 (projector / light / ac)
  {Colors.RED}off{Colors.RESET} <device>   关闭设备
  {Colors.BLUE}status{Colors.RESET}         显示当前设备状态
  {Colors.YELLOW}help{Colors.RESET}           显示此帮助
  {Colors.GRAY}quit / exit{Colors.RESET}    退出模拟器

{Colors.GRAY}示例: on projector, off ac, status{Colors.RESET}
''')
            elif cmd == 'status':
                simulator.print_status()
            elif cmd in ('quit', 'exit'):
                global running
                running = False
                break
            elif cmd in ('on', 'off') and len(parts) >= 2:
                device_type = parts[1]
                simulator.manual_toggle(device_type, cmd)
            else:
                print(f'{Colors.YELLOW}未知命令: {user_input} (输入 help 查看帮助){Colors.RESET}')

        except EOFError:
            break
        except KeyboardInterrupt:
            running = False
            break


def periodic_status_thread(simulator):
    """周期性发布状态上报（每30秒一次）"""
    while running:
        # 每30秒检查一次，使用短循环以便及时响应退出
        for _ in range(300):  # 30秒 = 300 * 0.1秒
            if not running:
                return
            time.sleep(0.1)

        if running:
            simulator.publish_all_status()
            print(f'{Colors.GRAY}[{timestamp_str()}] 已发布周期状态上报{Colors.RESET}')


def main():
    parser = argparse.ArgumentParser(
        description='智能教室设备控制模拟器 - 模拟投影仪/灯光/空调',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python device_simulator.py
  python device_simulator.py --broker 192.168.1.100 --classroom 3

交互命令:
  on projector   开启投影仪
  off light      关闭灯光
  on ac          开启空调
  status         显示所有设备状态
  help           显示帮助
        """
    )
    parser.add_argument('--broker', default='localhost', help='MQTT Broker地址 (默认: localhost)')
    parser.add_argument('--port', type=int, default=1883, help='MQTT Broker端口 (默认: 1883)')
    parser.add_argument('--classroom', type=int, default=1, help='教室ID (默认: 1)')
    args = parser.parse_args()

    # 注册信号处理
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    print(f'{Colors.CYAN}======================================{Colors.RESET}')
    print(f'{Colors.CYAN}  智能教室设备控制模拟器{Colors.RESET}')
    print(f'{Colors.CYAN}======================================{Colors.RESET}')
    print(f'  Broker:     {args.broker}:{args.port}')
    print(f'  教室ID:     {args.classroom}')
    print(f'  设备类型:   投影仪 / 灯光 / 空调')
    print(f'  指令主题:   classroom/{args.classroom}/device/+/cmd')
    print(f'{Colors.CYAN}======================================{Colors.RESET}')
    print()

    # 创建模拟器并启动
    simulator = DeviceSimulator(args.classroom, args.broker, args.port)
    simulator.start()

    # 启动周期性状态上报线程
    status_thread = threading.Thread(
        target=periodic_status_thread,
        args=(simulator,),
        daemon=True
    )
    status_thread.start()

    # 在主线程运行键盘输入循环
    try:
        keyboard_input_loop(simulator)
    except KeyboardInterrupt:
        pass

    # 清理
    print(f'\n{Colors.YELLOW}正在停止设备模拟器...{Colors.RESET}')
    simulator.stop()
    print(f'{Colors.GREEN}设备模拟器已停止{Colors.RESET}')


if __name__ == '__main__':
    main()
