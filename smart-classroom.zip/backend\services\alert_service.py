# -*- coding: utf-8 -*-
"""告警服务 - 告警检测、设备管理、统计"""

from datetime import timedelta
from django.utils import timezone
from django.db.models import Count, Q

from core.models import (
    Classroom, Course, SeatOccupancy, AttendanceRecord,
    DeviceStatus, Alert,
)


class AlertService:
    """告警与设备相关业务逻辑"""

    @staticmethod
    def get_active_alerts(classroom_id=None):
        """获取未解决的告警"""
        qs = Alert.objects.filter(is_resolved=False)
        if classroom_id:
            qs = qs.filter(classroom_id=classroom_id)
        qs = qs.select_related('classroom').order_by('-created_at')

        return [
            {
                'id': a.id,
                'classroom_id': a.classroom_id,
                'classroom_name': str(a.classroom),
                'alert_type': a.alert_type,
                'alert_type_display': dict(Alert.TYPE_CHOICES).get(a.alert_type, a.alert_type),
                'message': a.message,
                'severity': a.severity,
                'severity_display': dict(Alert.SEVERITY_CHOICES).get(a.severity, a.severity),
                'created_at': a.created_at.isoformat(),
            }
            for a in qs
        ]

    @staticmethod
    def get_all_alerts(limit=50, include_resolved=False):
        """获取告警历史"""
        qs = Alert.objects.select_related('classroom')
        if not include_resolved:
            qs = qs.filter(is_resolved=False)
        qs = qs.order_by('-created_at')[:limit]

        return [
            {
                'id': a.id,
                'classroom_id': a.classroom_id,
                'classroom_name': str(a.classroom),
                'alert_type': a.alert_type,
                'alert_type_display': dict(Alert.TYPE_CHOICES).get(a.alert_type, a.alert_type),
                'message': a.message,
                'severity': a.severity,
                'severity_display': dict(Alert.SEVERITY_CHOICES).get(a.severity, a.severity),
                'is_resolved': a.is_resolved,
                'created_at': a.created_at.isoformat(),
                'resolved_at': a.resolved_at.isoformat() if a.resolved_at else None,
            }
            for a in qs
        ]

    @staticmethod
    def resolve_alert(alert_id):
        """解决单个告警"""
        alert = Alert.objects.select_related('classroom').get(id=alert_id)
        if not alert.is_resolved:
            alert.is_resolved = True
            alert.resolved_at = timezone.now()
            alert.save(update_fields=['is_resolved', 'resolved_at'])

        return {
            'id': alert.id,
            'classroom_name': str(alert.classroom),
            'message': alert.message,
            'is_resolved': alert.is_resolved,
            'resolved_at': alert.resolved_at.isoformat(),
        }

    @staticmethod
    def resolve_all(classroom_id=None):
        """批量解决告警"""
        qs = Alert.objects.filter(is_resolved=False)
        if classroom_id:
            qs = qs.filter(classroom_id=classroom_id)

        now = timezone.now()
        count = qs.update(is_resolved=True, resolved_at=now)

        return {
            'resolved_count': count,
            'classroom_id': classroom_id,
            'resolved_at': now.isoformat(),
        }

    @staticmethod
    def run_detection():
        """
        运行告警检测
        1. 检测空教室中设备仍然开启（能源浪费）
        2. 检测长时间运行的设备（>8小时）
        """
        now = timezone.now()
        alerts_created = []

        classrooms = Classroom.objects.prefetch_related('devices', 'occupancies').all()

        for classroom in classrooms:
            # 获取该教室今天最新的座位占用情况
            today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
            recent_occupancy = SeatOccupancy.objects.filter(
                classroom=classroom,
                timestamp__gte=today_start,
            ).order_by('-timestamp')

            # 统计当前占用座位数
            occupied_seats = set()
            for occ in recent_occupancy:
                if occ.is_occupied:
                    occupied_seats.add((occ.row_num, occ.col_num))
            is_empty = len(occupied_seats) == 0

            # 获取设备状态
            devices = DeviceStatus.objects.filter(classroom=classroom)

            for device in devices:
                if not device.is_on:
                    continue

                # 检测1: 空教室设备开启（能源浪费）
                if is_empty:
                    # 检查是否已有未解决的同类告警
                    existing = Alert.objects.filter(
                        classroom=classroom,
                        alert_type='energy',
                        is_resolved=False,
                        message__contains=device.device_type,
                    ).exists()

                    if not existing:
                        device_label = dict(DeviceStatus.DEVICE_TYPES).get(
                            device.device_type, device.device_type
                        )
                        alert = Alert.objects.create(
                            classroom=classroom,
                            alert_type='energy',
                            severity='warning',
                            message=f'{str(classroom)}的{device_label}在教室无人时仍处于开启状态，存在能源浪费',
                        )
                        alerts_created.append({
                            'id': alert.id,
                            'classroom': str(classroom),
                            'type': 'energy',
                            'message': alert.message,
                        })

                # 检测2: 设备长时间运行（>8小时）
                hours_on = (now - device.last_changed).total_seconds() / 3600
                if hours_on > 8:
                    existing = Alert.objects.filter(
                        classroom=classroom,
                        alert_type='device',
                        is_resolved=False,
                        message__contains='长时间运行',
                    ).exists()

                    if not existing:
                        device_label = dict(DeviceStatus.DEVICE_TYPES).get(
                            device.device_type, device.device_type
                        )
                        alert = Alert.objects.create(
                            classroom=classroom,
                            alert_type='device',
                            severity='info',
                            message=f'{str(classroom)}的{device_label}已连续运行{hours_on:.1f}小时，建议检查是否需要关闭',
                        )
                        alerts_created.append({
                            'id': alert.id,
                            'classroom': str(classroom),
                            'type': 'device',
                            'message': alert.message,
                        })

        return {
            'detection_time': now.isoformat(),
            'alerts_created': len(alerts_created),
            'details': alerts_created,
        }

    @staticmethod
    def toggle_device(classroom_id, device_type, is_on):
        """切换设备开关状态"""
        classroom = Classroom.objects.get(id=classroom_id)

        device, created = DeviceStatus.objects.get_or_create(
            classroom=classroom,
            device_type=device_type,
            defaults={'is_on': is_on},
        )

        if not created:
            device.is_on = is_on
            device.save(update_fields=['is_on', 'last_changed'])

        device_label = dict(DeviceStatus.DEVICE_TYPES).get(device_type, device_type)

        return {
            'classroom_id': classroom.id,
            'classroom_name': str(classroom),
            'device_type': device_type,
            'device_label': device_label,
            'is_on': device.is_on,
            'last_changed': device.last_changed.isoformat(),
        }

    @staticmethod
    def get_device_status(classroom_id=None):
        """获取设备状态列表"""
        qs = DeviceStatus.objects.select_related('classroom')
        if classroom_id:
            qs = qs.filter(classroom_id=classroom_id)
        qs = qs.order_by('classroom__name', 'device_type')

        return [
            {
                'id': d.id,
                'classroom_id': d.classroom_id,
                'classroom_name': str(d.classroom),
                'device_type': d.device_type,
                'device_label': dict(DeviceStatus.DEVICE_TYPES).get(d.device_type, d.device_type),
                'is_on': d.is_on,
                'last_changed': d.last_changed.isoformat(),
            }
            for d in qs
        ]

    @staticmethod
    def get_alert_statistics():
        """获取告警统计数据"""
        # 按类型统计
        type_stats = Alert.objects.values('alert_type').annotate(
            total=Count('id'),
            unresolved=Count('id', filter=Q(is_resolved=False)),
        )

        # 按严重程度统计
        severity_stats = Alert.objects.values('severity').annotate(
            total=Count('id'),
            unresolved=Count('id', filter=Q(is_resolved=False)),
        )

        # 总体统计
        total = Alert.objects.count()
        unresolved = Alert.objects.filter(is_resolved=False).count()
        resolved = total - unresolved

        # 今日新增
        today_start = timezone.now().replace(hour=0, minute=0, second=0, microsecond=0)
        today_count = Alert.objects.filter(created_at__gte=today_start).count()

        return {
            'total': total,
            'unresolved': unresolved,
            'resolved': resolved,
            'today_new': today_count,
            'by_type': [
                {
                    'type': s['alert_type'],
                    'label': dict(Alert.TYPE_CHOICES).get(s['alert_type'], s['alert_type']),
                    'total': s['total'],
                    'unresolved': s['unresolved'],
                }
                for s in type_stats
            ],
            'by_severity': [
                {
                    'severity': s['severity'],
                    'label': dict(Alert.SEVERITY_CHOICES).get(s['severity'], s['severity']),
                    'total': s['total'],
                    'unresolved': s['unresolved'],
                }
                for s in severity_stats
            ],
        }
