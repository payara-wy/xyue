<template>
  <span class="tag" :class="tagClass">{{ tagLabel }}</span>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  status: { type: String, default: '' },
  severity: { type: String, default: '' }
})

const statusMap = {
  present: { label: '出勤', class: 'tag-present' },
  late: { label: '迟到', class: 'tag-late' },
  early_leave: { label: '早退', class: 'tag-early' },
  absent: { label: '缺勤', class: 'tag-absent' }
}

const severityMap = {
  warning: { label: '警告', class: 'tag-warning' },
  critical: { label: '严重', class: 'tag-critical' },
  info: { label: '信息', class: 'tag-info' },
  resolved: { label: '已解决', class: 'tag-resolved' }
}

const tagClass = computed(() => {
  if (props.status && statusMap[props.status]) {
    return statusMap[props.status].class
  }
  if (props.severity && severityMap[props.severity]) {
    return severityMap[props.severity].class
  }
  return ''
})

const tagLabel = computed(() => {
  if (props.status && statusMap[props.status]) {
    return statusMap[props.status].label
  }
  if (props.severity && severityMap[props.severity]) {
    return severityMap[props.severity].label
  }
  return props.status || props.severity || ''
})
</script>
