# -*- coding: utf-8 -*-
"""MQTT客户端管理器 - 封装paho-mqtt客户端，提供主题订阅与消息发布"""

import json
import logging
import time
import paho.mqtt.client as mqtt

from config.settings import MQTT_CLIENT_ID, MQTT_TOPICS

logger = logging.getLogger(__name__)


class MqttClient:
    """
    MQTT客户端封装
    使用paho-mqtt v1.x API，在守护线程中运行消息循环
    支持自动重连、主题订阅、消息发布
    """

    def __init__(self, client_id=None):
        self.client_id = client_id or MQTT_CLIENT_ID
        # paho-mqtt v1.x: 直接传入client_id，不需要CallbackAPIVersion
        self._client = mqtt.Client(client_id=self.client_id)
        self._host = None
        self._port = None
        # 存储需要订阅的主题及对应回调，用于重连后自动重新订阅
        self._subscriptions = {}  # {topic: callback}
        self._setup_callbacks()

    def _setup_callbacks(self):
        """设置paho客户端的内置回调函数"""

        def on_connect(client, userdata, flags, rc):
            """连接回调：成功时自动重新订阅所有已注册的主题"""
            if rc == 0:
                logger.info('已连接到MQTT Broker: %s:%s', self._host, self._port)
                # 重连后自动重新订阅
                self._resubscribe_all()
            else:
                logger.error('连接Broker失败，返回码: %d', rc)

        def on_disconnect(client, userdata, rc):
            """断开回调：记录断线事件，paho会自动尝试重连"""
            if rc != 0:
                logger.warning('与Broker连接意外断开(rc=%d)，将自动重连...', rc)
            else:
                logger.info('已主动断开与Broker的连接')

        def on_message(client, userdata, msg):
            """消息分发回调：根据主题路由到对应的处理器"""
            topic = msg.topic
            for sub_topic, callback in self._subscriptions.items():
                if mqtt.topic_matches_sub(sub_topic, topic):
                    try:
                        callback(client, userdata, msg)
                    except Exception as e:
                        logger.error('处理消息出错 [topic=%s]: %s', topic, e, exc_info=True)
                    break

        self._client.on_connect = on_connect
        self._client.on_disconnect = on_disconnect
        self._client.on_message = on_message

    def _resubscribe_all(self):
        """重新订阅所有已注册的主题"""
        for topic in self._subscriptions:
            self._client.subscribe(topic, qos=1)
            logger.debug('已订阅主题: %s', topic)

    def connect(self, host, port=1883):
        """
        连接到MQTT Broker
        设置自动重连参数：初始间隔1秒，最大间隔60秒
        """
        self._host = host
        self._port = port
        # 设置自动重连：初始1秒，最大60秒
        self._client.reconnect_delay_set(min_delay=1, max_delay=60)
        try:
            self._client.connect(host, port, keepalive=60)
            logger.info('已发起连接至 %s:%d', host, port)
        except Exception as e:
            logger.error('连接Broker失败 [%s:%d]: %s', host, port, e)
            raise

    def subscribe_occupancy(self, classroom_id, callback):
        """
        订阅座位占用传感器数据
        主题格式: classroom/{id}/sensor/occupancy
        """
        topic = MQTT_TOPICS['SENSOR_OCCUPANCY'].format(classroom_id=classroom_id)
        self._subscriptions[topic] = callback
        self._client.subscribe(topic, qos=1)
        logger.info('已订阅座位占用主题: %s', topic)

    def subscribe_heartbeat(self, classroom_id, callback):
        """
        订阅传感器心跳
        主题格式: classroom/{id}/sensor/heartbeat
        """
        topic = MQTT_TOPICS['SENSOR_HEARTBEAT'].format(classroom_id=classroom_id)
        self._subscriptions[topic] = callback
        self._client.subscribe(topic, qos=1)
        logger.info('已订阅心跳主题: %s', topic)

    def subscribe_device_status(self, classroom_id, callback):
        """
        订阅设备状态上报（使用通配符匹配所有设备类型）
        主题格式: classroom/{id}/device/+/status
        """
        topic_pattern = f'classroom/{classroom_id}/device/+/status'
        self._subscriptions[topic_pattern] = callback
        self._client.subscribe(topic_pattern, qos=1)
        logger.info('已订阅设备状态主题: %s', topic_pattern)

    def publish_device_cmd(self, classroom_id, device_type, action):
        """
        发布设备控制指令
        :param classroom_id: 教室ID
        :param device_type: 设备类型 (projector/light/ac)
        :param action: 动作 ("on" 或 "off")
        """
        topic = MQTT_TOPICS['DEVICE_CMD'].format(
            classroom_id=classroom_id,
            device_type=device_type
        )
        payload = json.dumps({
            'action': action,
            'timestamp': time.time()
        })
        result = self._client.publish(topic, payload, qos=1)
        if result.rc == mqtt.MQTT_ERR_SUCCESS:
            logger.info('已发布设备指令: %s -> %s=%s', classroom_id, device_type, action)
        else:
            logger.error('发布设备指令失败(rc=%d): %s', result.rc, topic)
        return result

    def publish_alert(self, classroom_id, alert_data):
        """
        发布告警通知
        :param classroom_id: 教室ID
        :param alert_data: 告警数据 dict，包含 type, message, severity
        """
        topic = MQTT_TOPICS['ALERT_PUSH'].format(classroom_id=classroom_id)
        payload = json.dumps({
            'type': alert_data.get('type', 'device'),
            'message': alert_data.get('message', ''),
            'severity': alert_data.get('severity', 'warning'),
            'timestamp': time.time()
        })
        result = self._client.publish(topic, payload, qos=1)
        if result.rc == mqtt.MQTT_ERR_SUCCESS:
            logger.info('已发布告警: [教室%s] %s', classroom_id, alert_data.get('message', ''))
        else:
            logger.error('发布告警失败(rc=%d): %s', result.rc, topic)
        return result

    def start(self):
        """
        启动客户端消息循环（在守护线程中）
        使用paho的loop_start()方法
        """
        self._client.loop_start()
        logger.info('MQTT客户端消息循环已启动（守护线程）')

    def stop(self):
        """
        停止客户端消息循环并断开连接
        """
        logger.info('正在停止MQTT客户端...')
        self._client.loop_stop()
        self._client.disconnect()
        self._subscriptions.clear()
        logger.info('MQTT客户端已停止')

    @property
    def is_connected(self):
        """检查客户端是否已连接"""
        return self._client.is_connected()
