; ═══════════════════════════════════════════════════
;  智能教室考勤系统 - InnoSetup 安装器脚本
;  生成 Setup.exe，实现一键安装 + 桌面快捷方式
;
;  前提: 先用 build_portable.py 构建便携包
;  然后: iscc setup_installer.iss
; ═══════════════════════════════════════════════════

#define MyAppName "智能教室考勤系统"
#define MyAppVersion "1.0.0"
#define MyAppPublisher "Smart Classroom"
#define MyAppExeName "SmartClassroom.exe"
#define MyAppURL "http://localhost:8089"

[Setup]
AppId={{A1B2C3D4-E5F6-7890-ABCD-EF1234567890}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
AllowNoIcons=yes
OutputDir=..\dist
OutputBaseFilename=SmartClassroom-Setup
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=lowest
SetupIconFile=compiler:SetupClassicIcon.ico
UninstallDisplayIcon={app}\SmartClassroom.exe
ArchitecturesInstallIn64BitMode=x64compatible
DisableProgramGroupPage=yes
LicenseFile=
InfoBeforeFile=

; 界面语言
[Languages]
Name: "chinesesimplified"; MessagesFile: "compiler:Languages\ChineseSimplified.isl"
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "创建桌面快捷方式(&D)"; GroupDescription: "附加选项:"; Flags: checked
Name: "startmenuicon"; Description: "创建开始菜单快捷方式(&S)"; GroupDescription: "附加选项:"; Flags: checked
Name: "autostart"; Description: "安装完成后自动启动(&A)"; GroupDescription: "附加选项:"; Flags: checked

[Files]
; 复制便携包的全部内容
Source: "..\dist\SmartClassroom-amd64\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
; 桌面快捷方式
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon
; 开始菜单
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: startmenuicon
Name: "{group}\卸载 {#MyAppName}"; Filename: "{uninstallexe}"; Tasks: startmenuicon

[Run]
; 安装完成后启动
Filename: "{app}\{#MyAppExeName}"; Description: "启动 {#MyAppName}"; Tasks: autostart; Flags: nowait postinstall skipifsilent

[UninstallDelete]
Type: filesanddir; Name: "{app}\data"
Type: filesanddir; Name: "{app}\runtime\mariadb\data"

[Code]
// 安装前检查端口是否被占用
function IsPortInUse(Port: Integer): Boolean;
var
  ResultCode: Integer;
begin
  Result := False;
  // 简单检查 - 尝试连接端口
  // 实际安装时由应用自行处理端口冲突
end;

// 卸载前确认
procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
begin
  if CurUninstallStep = usUninstall then
  begin
    // 停止正在运行的应用
    Exec('taskkill', '/f /im mysqld.exe', '', SW_HIDE, ewWaitUntilTerminated, ResultCode);
    Exec('netstat', '-aon | findstr ":8089.*LISTENING"', '', SW_HIDE, ewWaitUntilTerminated, ResultCode);
  end;
end;
