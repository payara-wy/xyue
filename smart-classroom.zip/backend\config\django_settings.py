# -*- coding: utf-8 -*-
"""Django settings - 生产/开发统一配置"""

import os
import sys

# 路径设置
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE_DIR)

from config.settings import (
    DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD,
    SERVER_PORT, DEBUG, DATA_DIR
)

SECRET_KEY = 'smart-classroom-secret-key-change-in-production'
DEBUG = DEBUG
ALLOWED_HOSTS = ['*']

# ============ 应用 ============
INSTALLED_APPS = [
    'django.contrib.contenttypes',
    'django.contrib.auth',
    'rest_framework',
    'corsheaders',
    'core',
]

MIDDLEWARE = [
    'corsheaders.middleware.CorsMiddleware',
    'django.middleware.common.CommonMiddleware',
]

# CORS全开（内网应用）
CORS_ALLOW_ALL_ORIGINS = True

ROOT_URLCONF = 'config.urls'
WSGI_APPLICATION = 'config.wsgi.application'

# ============ 数据库 ============
USE_SQLITE = os.getenv('USE_SQLITE', '').lower() in ('1', 'true', 'yes')

# 自动检测：如果pymysql不可用则回退到SQLite
if not USE_SQLITE:
    try:
        import pymysql
        pymysql.install_as_MySQLdb()
    except ImportError:
        USE_SQLITE = True

if USE_SQLITE:
    SQLITE_PATH = os.path.join(DATA_DIR, 'smart_classroom.db')
    DATABASES = {
        'default': {
            'ENGINE': 'django.db.backends.sqlite3',
            'NAME': SQLITE_PATH,
        }
    }
else:
    DATABASES = {
        'default': {
            'ENGINE': 'django.db.backends.mysql',
            'NAME': DB_NAME,
            'USER': DB_USER,
            'PASSWORD': DB_PASSWORD,
            'HOST': DB_HOST,
            'PORT': str(DB_PORT),
            'OPTIONS': {
                'charset': 'utf8mb4',
                'init_command': "SET sql_mode='STRICT_TRANS_TABLES'",
            },
        }
    }

# ============ DRF ============
REST_FRAMEWORK = {
    'DEFAULT_RENDERER_CLASSES': [
        'rest_framework.renderers.JSONRenderer',
    ],
    'DEFAULT_PAGINATION_CLASS': None,
    'UNAUTHENTICATED_USER': None,
}

# ============ 国际化 ============
LANGUAGE_CODE = 'zh-hans'
TIME_ZONE = 'Asia/Shanghai'
USE_I18N = True
USE_TZ = False

# ============ 静态文件 ============
STATIC_URL = '/static/'
STATIC_ROOT = os.path.join(DATA_DIR, 'static')

# 前端构建产物目录 - 多路径探测
_candidate_paths = [
    os.path.join(BASE_DIR, '..', 'frontend', 'dist'),       # 开发模式
    os.path.join(BASE_PATH, 'frontend', 'dist'),             # 便携包模式
]
FRONTEND_DIST = ''
for _p in _candidate_paths:
    if os.path.isdir(_p):
        FRONTEND_DIST = os.path.normpath(_p)
        break

STATICFILES_DIRS = [FRONTEND_DIST] if FRONTEND_DIST else []

# ============ 模板（用于serve前端index.html）============
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [FRONTEND_DIST] if FRONTEND_DIST else [],
        'APP_DIRS': False,
        'OPTIONS': {
            'context_processors': [],
        },
    },
]

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'
