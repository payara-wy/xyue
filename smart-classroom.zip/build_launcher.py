# -*- coding: utf-8 -*-
"""
构建 SmartClassroom.exe 启动器

使用 PyInstaller 将 launcher.py 编译为独立 .exe 文件。
编译后的 .exe 放入便携包的根目录，双击即可启动全部服务。

前提: pip install pyinstaller pystray Pillow

用法: python build_launcher.py
"""

import os
import sys
import subprocess
import shutil
import platform

PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))
LAUNCHER_SCRIPT = os.path.join(PROJECT_DIR, 'launcher.py')
OUTPUT_DIR = os.path.join(PROJECT_DIR, 'dist', 'launcher')


def main():
    arch = 'arm64' if platform.machine().lower() in ('arm64', 'aarch64') else 'amd64'
    print(f'\n  构建 SmartClassroom.exe 启动器 ({arch})\n')

    # 检查依赖
    deps = ['PyInstaller', 'pystray', 'PIL']
    print('  检查构建依赖...')
    for dep in deps:
        try:
            __import__(dep.lower().replace('pil', 'PIL'))
        except ImportError:
            print(f'  安装 {dep}...')
            subprocess.run(
                [sys.executable, '-m', 'pip', 'install', dep.replace('PIL', 'Pillow'), '--quiet'],
                check=True
            )

    # PyInstaller 打包
    print('  编译 launcher.py...')
    cmd = [
        sys.executable, '-m', 'PyInstaller',
        '--name', 'SmartClassroom',
        '--onefile',
        '--windowed',                  # 无控制台窗口
        '--distpath', OUTPUT_DIR,
        '--workpath', os.path.join(PROJECT_DIR, 'build', 'launcher'),
        '--specpath', os.path.join(PROJECT_DIR, 'build'),
        '--add-data', f'{os.path.join(PROJECT_DIR, "backend")}{os.pathsep}backend',
        '--hidden-import', 'pystray',
        '--hidden-import', 'pystray._win32',
        '--hidden-import', 'PIL',
        '--hidden-import', 'PIL._tkinter_finder',
        '--collect-all', 'pystray',
        '--noconfirm',
        LAUNCHER_SCRIPT,
    ]

    # Windows特有参数
    if sys.platform == 'win32':
        cmd.extend([
            '--uac-admin',              # 请求管理员权限（MariaDB需要）
        ])

    result = subprocess.run(cmd, capture_output=True, text=True)

    if result.returncode != 0:
        print(f'  编译失败:\n{result.stderr}')
        sys.exit(1)

    exe_path = os.path.join(OUTPUT_DIR, 'SmartClassroom.exe')
    if os.path.isfile(exe_path):
        size_mb = os.path.getsize(exe_path) / (1024 * 1024)
        print(f'\n  编译成功!')
        print(f'  输出: {exe_path}')
        print(f'  大小: {size_mb:.1f} MB')

        # 复制到便携包目录（如果已构建）
        portable_dir = os.path.join(PROJECT_DIR, 'dist', f'SmartClassroom-{arch}')
        if os.path.isdir(portable_dir):
            shutil.copy2(exe_path, os.path.join(portable_dir, 'SmartClassroom.exe'))
            print(f'  已复制到便携包: {portable_dir}')
        else:
            print(f'  提示: 运行 build_portable.py 后可自动集成到便携包')
    else:
        print('  编译产物未找到，请检查日志')
        sys.exit(1)


if __name__ == '__main__':
    main()
