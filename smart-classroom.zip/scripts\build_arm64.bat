@echo off
REM ============================================================
REM  智能教室考勤系统 - Windows ARM64 打包脚本
REM  需要在ARM64设备上运行，或使用交叉编译环境
REM ============================================================
setlocal

set PROJECT_DIR=%~dp0..
set BACKEND_DIR=%PROJECT_DIR%\backend
set FRONTEND_DIR=%PROJECT_DIR%\frontend
set OUTPUT_DIR=%PROJECT_DIR%\dist\arm64

echo.
echo ============================================
echo   打包 Windows ARM64 可执行文件
echo ============================================
echo.

REM 检查是否在ARM64环境
echo 当前架构: %PROCESSOR_ARCHITECTURE%
if /i "%PROCESSOR_ARCHITECTURE%"=="AMD64" (
    echo [注意] 当前为x64环境，将使用交叉编译。
    echo 建议安装ARM64版Python以获得原生性能。
    echo.
    set PYTHON_ARCH=--target-arch arm64
) else if /i "%PROCESSOR_ARCHITECTURE%"=="ARM64" (
    echo [OK] 当前为ARM64原生环境。
    set PYTHON_ARCH=
) else (
    echo [警告] 未识别的架构: %PROCESSOR_ARCHITECTURE%
)

REM 1. 构建前端
echo [1/4] 构建前端...
cd /d "%FRONTEND_DIR%"
call npm install
call npm run build
if errorlevel 1 (
    echo 前端构建失败!
    exit /b 1
)

REM 2. 安装后端依赖
echo [2/4] 安装后端依赖...
cd /d "%BACKEND_DIR%"
pip install -r requirements.txt pyinstaller --quiet
if errorlevel 1 (
    echo 后端依赖安装失败!
    exit /b 1
)

REM 3. PyInstaller打包 (ARM64)
echo [3/4] PyInstaller打包 (ARM64)...
cd /d "%BACKEND_DIR%"
pyinstaller ^
    --name "SmartClassroom-ARM64" ^
    --distpath "%OUTPUT_DIR%" ^
    --workpath "%PROJECT_DIR%\build\arm64" ^
    --specpath "%PROJECT_DIR%\build" ^
    --onefile ^
    --console ^
    --add-data "config;config" ^
    --add-data "core;core" ^
    --add-data "api;api" ^
    --add-data "mqtt;mqtt" ^
    --add-data "services;services" ^
    --add-data "utils;utils" ^
    --add-data "%FRONTEND_DIR%\dist;%FRONTEND_DIR%\dist" ^
    --hidden-import=pymysql ^
    --hidden-import=paho.mqtt.client ^
    --hidden-import=rest_framework ^
    --hidden-import=corsheaders ^
    --collect-all django ^
    --collect-all rest_framework ^
    --collect-all corsheaders ^
    %PYTHON_ARCH% ^
    main.py

if errorlevel 1 (
    echo PyInstaller打包失败!
    echo.
    echo ARM64打包注意事项:
    echo   1. 推荐使用ARM64版本的Python (从python.org下载)
    echo   2. 确保所有依赖包都有ARM64 wheel
    echo   3. 如pymysql无ARM64 wheel，使用 --no-binary :all: 编译
    exit /b 1
)

REM 4. 复制附加文件
echo [4/4] 复制附加文件...
copy "%PROJECT_DIR%\scripts\setup_mariadb.py" "%OUTPUT_DIR%\setup_mariadb.py"
copy "%PROJECT_DIR%\simulators\sensor_simulator.py" "%OUTPUT_DIR%\sensor_simulator.py"
copy "%PROJECT_DIR%\simulators\device_simulator.py" "%OUTPUT_DIR%\device_simulator.py"
echo.

echo ============================================
echo   打包完成!
echo   输出: %OUTPUT_DIR%\SmartClassroom-ARM64.exe
echo ============================================
echo.

endlocal
