# -*- coding: utf-8 -*-
"""
智能教室考勤系统 - 便携包构建脚本
自动下载 Python嵌入式版 + MariaDB Portable + 安装依赖 + 组装完整包

用法:
    python build_portable.py              # 自动检测架构
    python build_portable.py --arch amd64 # 指定x64
    python build_portable.py --arch arm64 # 指定ARM64
    python build_portable.py --skip-db    # 跳过MariaDB(仅SQLite模式)
"""

import os
import sys
import shutil
import zipfile
import argparse
import platform
import subprocess
import urllib.request
import tempfile

# ============ 配置 ============
PYTHON_VERSION = '3.11.9'
PYTHON_VERSION_SHORT = '311'

# Python嵌入式版下载地址
PYTHON_URLS = {
    'amd64': f'https://www.python.org/ftp/python/{PYTHON_VERSION}/python-{PYTHON_VERSION}-embed-amd64.zip',
    'arm64': f'https://www.python.org/ftp/python/{PYTHON_VERSION}/python-{PYTHON_VERSION}-embed-arm64.zip',
}

# MariaDB下载地址
MARIADB_URLS = {
    'amd64': 'https://dlm.mariadb.com/3740826/MariaDB/mariadb-10.11.10/winx64-packages/mariadb-10.11.10-winx64.zip',
    # ARM64 MariaDB需要使用社区编译版或自行编译
    'arm64': '',
}

# get-pip.py
GETPIP_URL = 'https://bootstrap.pypa.io/get-pip.py'

PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))
BUILD_DIR = os.path.join(PROJECT_DIR, 'build', 'portable')
OUTPUT_DIR = os.path.join(PROJECT_DIR, 'dist')


def log(msg, level='INFO'):
    colors = {'INFO': '\033[32m', 'WARN': '\033[33m', 'ERROR': '\033[31m', 'STEP': '\033[36m'}
    reset = '\033[0m'
    print(f'{colors.get(level, "")}  [{level}] {msg}{reset}')


def download_file(url, dest, desc=''):
    """下载文件，显示进度"""
    if not url:
        log(f'无下载链接: {desc}', 'WARN')
        return False
    log(f'下载 {desc or url}...')
    try:
        def progress(block_num, block_size, total_size):
            downloaded = block_num * block_size
            if total_size > 0:
                pct = min(100, downloaded * 100 // total_size)
                mb = downloaded / (1024 * 1024)
                total_mb = total_size / (1024 * 1024)
                print(f'\r  进度: {pct:3d}% ({mb:.1f}/{total_mb:.1f} MB)', end='', flush=True)
        urllib.request.urlretrieve(url, dest, progress)
        print()
        return True
    except Exception as e:
        print()
        log(f'下载失败: {e}', 'ERROR')
        return False


def detect_arch():
    """检测当前架构"""
    machine = platform.machine().lower()
    if machine in ('arm64', 'aarch64'):
        return 'arm64'
    return 'amd64'


def step_download_python(arch, runtime_dir):
    """步骤1: 下载Python嵌入式版"""
    log('步骤 1/5: 下载 Python 嵌入式版', 'STEP')
    python_dir = os.path.join(runtime_dir, 'python')
    os.makedirs(python_dir, exist_ok=True)

    url = PYTHON_URLS.get(arch, '')
    if not url:
        log(f'Python {arch} 嵌入式版无下载链接', 'ERROR')
        return False

    zip_path = os.path.join(BUILD_DIR, f'python-{arch}.zip')
    if not download_file(url, zip_path, f'Python {PYTHON_VERSION} ({arch})'):
        return False

    log('解压 Python...')
    with zipfile.ZipFile(zip_path, 'r') as z:
        z.extractall(python_dir)

    # 启用pip: 修改python311._pth文件，取消import site的注释
    pth_files = [f for f in os.listdir(python_dir) if f.endswith('._pth')]
    for pth in pth_files:
        pth_path = os.path.join(python_dir, pth)
        with open(pth_path, 'r') as f:
            content = f.read()
        content = content.replace('#import site', 'import site')
        with open(pth_path, 'w') as f:
            f.write(content)
        log(f'已启用 import site ({pth})')

    os.remove(zip_path)
    log('Python 嵌入式版就绪')
    return True


def step_install_deps(runtime_dir):
    """步骤2: 安装Python依赖"""
    log('步骤 2/5: 安装 Python 依赖', 'STEP')
    python_dir = os.path.join(runtime_dir, 'python')
    python_exe = os.path.join(python_dir, 'python.exe')

    if not os.path.isfile(python_exe):
        log('python.exe 不存在', 'ERROR')
        return False

    # 下载并运行get-pip.py
    getpip_path = os.path.join(BUILD_DIR, 'get-pip.py')
    if not download_file(GETPIP_URL, getpip_path, 'get-pip.py'):
        return False

    log('安装 pip...')
    subprocess.run([python_exe, getpip_path, '--no-warn-script-location'],
                   check=True, capture_output=True)

    # 安装项目依赖
    requirements = os.path.join(PROJECT_DIR, 'backend', 'requirements.txt')
    log('安装项目依赖...')
    result = subprocess.run(
        [python_exe, '-m', 'pip', 'install', '-r', requirements,
         '--no-warn-script-location', '--quiet'],
        capture_output=True, text=True
    )
    if result.returncode != 0:
        log(f'依赖安装失败: {result.stderr}', 'ERROR')
        return False

    log(f'Python 依赖安装完成')
    return True


def step_download_mariadb(arch, runtime_dir):
    """步骤3: 下载MariaDB Portable"""
    log('步骤 3/5: 下载 MariaDB Portable', 'STEP')

    url = MARIADB_URLS.get(arch, '')
    if not url:
        if arch == 'arm64':
            log('ARM64版MariaDB暂无官方下载，将使用SQLite模式', 'WARN')
            log('如需MariaDB，请手动下载ARM64编译版放入 runtime/mariadb/', 'WARN')
        return True  # 不阻断流程

    mariadb_dir = os.path.join(runtime_dir, 'mariadb')
    zip_path = os.path.join(BUILD_DIR, f'mariadb-{arch}.zip')

    if not download_file(url, zip_path, f'MariaDB ({arch})'):
        return True  # 不阻断，可用SQLite回退

    log('解压 MariaDB...')
    with zipfile.ZipFile(zip_path, 'r') as z:
        z.extractall(BUILD_DIR)

    # 找到解压后的目录
    for item in os.listdir(BUILD_DIR):
        item_path = os.path.join(BUILD_DIR, item)
        if os.path.isdir(item_path) and item.startswith('mariadb-') and item != 'mariadb':
            if os.path.isdir(mariadb_dir):
                shutil.rmtree(mariadb_dir)
            os.rename(item_path, mariadb_dir)
            break

    os.remove(zip_path)

    # 初始化数据目录
    mysqld = os.path.join(mariadb_dir, 'bin', 'mysqld.exe')
    data_dir = os.path.join(mariadb_dir, 'data')
    if os.path.isfile(mysqld) and not os.path.isdir(data_dir):
        log('初始化 MariaDB 数据目录...')
        subprocess.run(
            [mysqld, '--initialize-insecure', f'--datadir={data_dir}'],
            capture_output=True, timeout=60
        )

    log('MariaDB 就绪')
    return True


def step_copy_app(portable_dir):
    """步骤4: 复制应用代码"""
    log('步骤 4/5: 复制应用代码与前端构建', 'STEP')

    app_dir = os.path.join(portable_dir, 'app')
    os.makedirs(app_dir, exist_ok=True)

    # 复制后端代码
    backend_src = os.path.join(PROJECT_DIR, 'backend')
    for item in os.listdir(backend_src):
        src = os.path.join(backend_src, item)
        dst = os.path.join(app_dir, item)
        if item in ('__pycache__', 'data', '.pytest_cache'):
            continue
        if os.path.isdir(src):
            shutil.copytree(src, dst, dirs_exist_ok=True,
                          ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
        else:
            shutil.copy2(src, dst)

    # 复制前端构建产物
    frontend_dist = os.path.join(PROJECT_DIR, 'frontend', 'dist')
    if os.path.isdir(frontend_dist):
        dest_dist = os.path.join(app_dir, '..', 'frontend', 'dist')
        os.makedirs(os.path.dirname(dest_dist), exist_ok=True)
        shutil.copytree(frontend_dist, dest_dist, dirs_exist_ok=True)
        log('前端构建产物已复制')
    else:
        log('前端未构建，请先运行: cd frontend && npm run build', 'WARN')

    # 复制模拟器
    sim_dir = os.path.join(portable_dir, 'simulators')
    os.makedirs(sim_dir, exist_ok=True)
    sim_src = os.path.join(PROJECT_DIR, 'simulators')
    if os.path.isdir(sim_src):
        for f in os.listdir(sim_src):
            if f.endswith('.py'):
                shutil.copy2(os.path.join(sim_src, f), sim_dir)

    # 复制资源目录（图标等）
    assets_src = os.path.join(PROJECT_DIR, 'assets')
    assets_dst = os.path.join(portable_dir, 'assets')
    if os.path.isdir(assets_src):
        shutil.copytree(assets_src, assets_dst, dirs_exist_ok=True)
        log('资源文件已复制')

    # 生成 ICO 图标
    png_icon = os.path.join(assets_dst, 'icon.png')
    ico_icon = os.path.join(assets_dst, 'icon.ico')
    if os.path.isfile(png_icon) and not os.path.isfile(ico_icon):
        tools_dir = os.path.join(PROJECT_DIR, 'tools')
        sys.path.insert(0, tools_dir)
        try:
            from png2ico import png_to_ico
            png_to_ico(png_icon, ico_icon)
            log('ICO 图标已生成')
        except Exception as e:
            log(f'ICO 生成失败({e})，将使用系统默认图标', 'WARN')

    log('应用代码复制完成')
    return True


def step_create_launchers(portable_dir, arch):
    """步骤5: 创建启动脚本 + 编译启动器EXE"""
    log('步骤 5/5: 创建启动脚本 + 编译启动器', 'STEP')

    # 复制启动脚本
    for bat in ['run.bat', 'stop.bat', 'first_run.bat']:
        src = os.path.join(PROJECT_DIR, bat)
        if os.path.isfile(src):
            shutil.copy2(src, portable_dir)

    # ---- 编译 SmartClassroom.exe ----
    launcher_src = os.path.join(PROJECT_DIR, 'launcher.py')
    exe_output = os.path.join(portable_dir, 'SmartClassroom.exe')

    if os.path.isfile(launcher_src):
        log('编译 SmartClassroom.exe 启动器...')

        # 确保PyInstaller已安装（使用系统Python）
        try:
            import PyInstaller
        except ImportError:
            subprocess.run(
                [sys.executable, '-m', 'pip', 'install', 'pyinstaller', 'pystray', 'Pillow', '--quiet'],
                capture_output=True
            )

        exe_result = subprocess.run([
            sys.executable, '-m', 'PyInstaller',
            '--name', 'SmartClassroom',
            '--onefile',
            '--windowed',
            '--distpath', portable_dir,
            '--workpath', os.path.join(BUILD_DIR, 'launcher_work'),
            '--specpath', os.path.join(BUILD_DIR),
            '--hidden-import', 'pystray',
            '--hidden-import', 'pystray._win32',
            '--hidden-import', 'PIL',
            '--collect-all', 'pystray',
            '--noconfirm',
            '--clean',
            launcher_src,
        ], capture_output=True, text=True)

        if os.path.isfile(exe_output):
            size_mb = os.path.getsize(exe_output) / (1024 * 1024)
            log(f'SmartClassroom.exe 已编译 ({size_mb:.1f} MB)')
        else:
            log(f'启动器编译失败，回退到 bat 启动:\n{exe_result.stderr[-500:]}', 'WARN')
    else:
        log('launcher.py 不存在，跳过EXE编译', 'WARN')

    # ---- 创建模拟器快捷启动脚本 ----
    sensor_bat = os.path.join(portable_dir, 'start_sensor_sim.bat')
    with open(sensor_bat, 'w', encoding='utf-8') as f:
        f.write(f'@echo off\nchcp 65001 >nul\n')
        f.write(f'set "PYTHON=%~dp0runtime\\python\\python.exe"\n')
        f.write(f'if not exist "%PYTHON%" set "PYTHON=python"\n')
        f.write(f'echo 启动传感器模拟器...\n')
        f.write(f'"%PYTHON%" "%~dp0simulators\\sensor_simulator.py" --broker localhost --port 1883 --classroom 1 --interval 5\n')
        f.write('pause\n')

    device_bat = os.path.join(portable_dir, 'start_device_sim.bat')
    with open(device_bat, 'w', encoding='utf-8') as f:
        f.write(f'@echo off\nchcp 65001 >nul\n')
        f.write(f'set "PYTHON=%~dp0runtime\\python\\python.exe"\n')
        f.write(f'if not exist "%PYTHON%" set "PYTHON=python"\n')
        f.write(f'echo 启动设备控制模拟器...\n')
        f.write(f'"%PYTHON%" "%~dp0simulators\\device_simulator.py" --broker localhost --port 1883 --classroom 1\n')
        f.write('pause\n')

    # ---- 版本信息 ----
    info_file = os.path.join(portable_dir, 'VERSION.txt')
    with open(info_file, 'w', encoding='utf-8') as f:
        f.write(f'智能教室考勤与座位使用分析系统\n')
        f.write(f'Version: 1.0.0\n')
        f.write(f'Architecture: {arch}\n')
        f.write(f'Python: {PYTHON_VERSION} (embedded)\n')
        f.write(f'Database: MariaDB Portable / SQLite fallback\n')
        f.write(f'MQTT: paho-mqtt + amqtt embedded broker\n')
        f.write(f'Port: 8089\n')

    log('启动脚本已创建')
    return True


def main():
    parser = argparse.ArgumentParser(description='构建智能教室便携包')
    parser.add_argument('--arch', choices=['amd64', 'arm64'], default=None,
                       help='目标架构 (默认自动检测)')
    parser.add_argument('--skip-db', action='store_true',
                       help='跳过MariaDB下载 (仅SQLite模式)')
    parser.add_argument('--output', default=None,
                       help='输出目录 (默认 dist/)')
    args = parser.parse_args()

    arch = args.arch or detect_arch()
    output = args.output or OUTPUT_DIR
    pkg_name = f'SmartClassroom-{arch}'
    portable_dir = os.path.join(BUILD_DIR, pkg_name)

    print()
    print('╔══════════════════════════════════════════════════╗')
    print('║   智能教室系统 - 便携包构建器                   ║')
    print(f'║   目标架构: {arch:<38s}║')
    print('╚══════════════════════════════════════════════════╝')
    print()

    # 清理旧构建
    if os.path.isdir(portable_dir):
        shutil.rmtree(portable_dir)
    os.makedirs(portable_dir, exist_ok=True)
    os.makedirs(os.path.join(portable_dir, 'runtime'), exist_ok=True)
    os.makedirs(os.path.join(portable_dir, 'data'), exist_ok=True)

    runtime_dir = os.path.join(portable_dir, 'runtime')

    # 执行构建步骤
    ok = True
    ok = ok and step_download_python(arch, runtime_dir)
    ok = ok and step_install_deps(runtime_dir)
    if not args.skip_db:
        step_download_mariadb(arch, runtime_dir)
    ok = ok and step_copy_app(portable_dir)
    ok = ok and step_create_launchers(portable_dir, arch)

    if not ok:
        log('构建过程中出现错误', 'ERROR')
        sys.exit(1)

    # 打包为zip
    os.makedirs(output, exist_ok=True)
    zip_path = os.path.join(output, f'{pkg_name}.zip')
    log(f'打包: {zip_path}')
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
        for root, dirs, files in os.walk(portable_dir):
            # 跳过__pycache__
            dirs[:] = [d for d in dirs if d != '__pycache__']
            for file in files:
                filepath = os.path.join(root, file)
                arcname = os.path.join(pkg_name, os.path.relpath(filepath, portable_dir))
                z.write(filepath, arcname)

    size_mb = os.path.getsize(zip_path) / (1024 * 1024)

    print()
    print('╔══════════════════════════════════════════════════╗')
    print(f'║   构建完成!                                     ║')
    print(f'║   输出: {os.path.relpath(zip_path, PROJECT_DIR):<40s}║')
    print(f'║   大小: {size_mb:.1f} MB{" " * 34}║')
    print(f'║                                                  ║')
    print(f'║   使用方法:                                      ║')
    print(f'║   1. 解压 {pkg_name}.zip                      ║')
    print(f'║   2. 运行 run.bat                                ║')
    print(f'║   3. 浏览器访问 http://localhost:8089            ║')
    print('╚══════════════════════════════════════════════════╝')
    print()


if __name__ == '__main__':
    main()
