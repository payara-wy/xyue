<template>
  <div class="fade-in">
    <div class="page-header">
      <h2>📊 教室使用率</h2>
      <p>分析教室利用率与跨教室对比</p>
    </div>

    <div class="controls-bar">
      <select v-model="selectedId" @change="fetchUtilization">
        <option v-if="!store.classrooms.length" disabled value="">加载中...</option>
        <option v-for="c in store.classrooms" :key="c.id" :value="c.id">
          {{ c.name }}
        </option>
      </select>
      <button class="btn btn-primary" @click="fetchUtilization" :disabled="loading">
        🔄 刷新
      </button>
      <button class="btn btn-outline" @click="fetchComparison" :disabled="compLoading">
        📋 全部教室对比
      </button>
    </div>

    <div v-if="loading" class="loading">
      <div class="spinner"></div>
    </div>

    <template v-else-if="utilData">
      <!-- Overall utilization big number -->
      <div class="card">
        <div class="big-number">
          <div class="big-number-value">{{ (utilData.overall_utilization * 100).toFixed(1) }}%</div>
          <div class="big-number-label">整体利用率</div>
        </div>
      </div>

      <!-- Charts -->
      <div class="charts-row">
        <div class="chart-card">
          <h3>⏰ 时段利用率</h3>
          <Bar
            v-if="timeSlotChartData"
            :data="timeSlotChartData"
            :options="chartOptions('利用率 (%)')"
          />
        </div>
        <div class="chart-card">
          <h3>📅 工作日利用率</h3>
          <Bar
            v-if="weekdayChartData"
            :data="weekdayChartData"
            :options="chartOptions('占用次数')"
          />
        </div>
      </div>
    </template>

    <!-- Comparison table -->
    <div class="card" v-if="comparison">
      <div class="card-title">教室使用率排行</div>
      <div class="table-wrapper">
        <table>
          <thead>
            <tr>
              <th>排名</th>
              <th>教室名称</th>
              <th>楼栋</th>
              <th>座位数</th>
              <th>课程数</th>
              <th>使用率</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(item, idx) in comparison" :key="item.classroom_id || idx">
              <td>
                <span :style="{ fontWeight: idx < 3 ? '700' : '400', color: idx < 3 ? 'var(--primary)' : 'inherit' }">
                  {{ idx + 1 }}
                </span>
              </td>
              <td>{{ item.classroom_name || item.name }}</td>
              <td>{{ item.building || '-' }}</td>
              <td>{{ item.total_seats || '-' }}</td>
              <td>{{ item.course_count || '-' }}</td>
              <td>
                <div style="display:flex;align-items:center;gap:8px;">
                  <div class="progress-bar" style="flex:1;">
                    <div
                      class="fill"
                      :class="getProgressColor(item.utilization_rate)"
                      :style="{ width: (item.utilization_rate * 100).toFixed(0) + '%' }"
                    ></div>
                  </div>
                  <span style="font-size:12px;white-space:nowrap;">
                    {{ (item.utilization_rate * 100).toFixed(1) }}%
                  </span>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <div v-if="!loading && !utilData" class="empty-state">
      <div class="empty-state-icon">📊</div>
      <div class="empty-state-text">请选择教室查看使用率数据</div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useAppStore } from '../stores'
import { getClassroomUtilization, getUtilizationCompare } from '../api'
import { Bar } from 'vue-chartjs'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js'

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend)

const store = useAppStore()
const selectedId = ref(store.selectedClassroomId)
const utilData = ref(null)
const loading = ref(false)
const comparison = ref(null)
const compLoading = ref(false)

const timeSlotChartData = computed(() => {
  if (!utilData.value || !utilData.value.time_slot_stats) return null
  const stats = utilData.value.time_slot_stats
  return {
    labels: stats.map(s => s.time_slot || s.slot || ''),
    datasets: [{
      label: '利用率 (%)',
      data: stats.map(s => ((s.utilization || s.rate || 0) * 100).toFixed(1)),
      backgroundColor: 'rgba(67, 97, 238, 0.7)',
      borderRadius: 4
    }]
  }
})

const weekdayChartData = computed(() => {
  if (!utilData.value || !utilData.value.weekday_stats) return null
  const stats = utilData.value.weekday_stats
  return {
    labels: stats.map(s => s.weekday || s.day || ''),
    datasets: [{
      label: '占用次数',
      data: stats.map(s => s.occupied_count || s.count || 0),
      backgroundColor: 'rgba(46, 196, 182, 0.7)',
      borderRadius: 4
    }]
  }
})

function chartOptions(yLabel) {
  return {
    responsive: true,
    plugins: {
      legend: { display: false }
    },
    scales: {
      y: {
        beginAtZero: true,
        title: { display: true, text: yLabel }
      }
    }
  }
}

async function fetchUtilization() {
  if (!selectedId.value) return
  loading.value = true
  try {
    const res = await getClassroomUtilization(selectedId.value)
    utilData.value = res.data
    store.selectedClassroomId = selectedId.value
  } catch (e) {
    console.error('Failed to fetch utilization:', e)
    utilData.value = null
  } finally {
    loading.value = false
  }
}

async function fetchComparison() {
  compLoading.value = true
  try {
    const res = await getUtilizationCompare()
    comparison.value = res.data
  } catch (e) {
    console.error('Failed to fetch comparison:', e)
    comparison.value = null
  } finally {
    compLoading.value = false
  }
}

function getProgressColor(rate) {
  if (rate >= 0.7) return 'green'
  if (rate >= 0.4) return 'yellow'
  return 'red'
}

onMounted(() => {
  if (selectedId.value) {
    fetchUtilization()
  }
  fetchComparison()
})
</script>
