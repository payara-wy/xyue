# -*- coding: utf-8 -*-
"""全局配置 - 集中管理所有配置项，自动检测运行模式"""

import os
import sys
import platform


# ============ 路径检测 ============

def detect_environment():
    """检测运行环境：开发模式 / PyInstaller / 便携包"""
    env = {
        'frozen': getattr(sys, 'frozen', False),
        'portable': False,
        'base_path': '',
        'app_path': '',
        'runtime_path': '',
        'data_path': '',
        'arch': platform.machine().lower(),  # amd64 / arm64
    }

    if env['frozen']:
        # PyInstaller打包模式
        env['base_path'] = os.path.dirname(sys.executable)
        env['app_path'] = env['base_path']
        env['data_path'] = os.path.join(env['base_path'], 'data')
    else:
        # 开发 或 便携包模式
        app_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        parent_dir = os.path.dirname(app_dir)

        # 便携包：SmartClassroom/app/ + SmartClassroom/runtime/
        runtime_dir = os.path.join(parent_dir, 'runtime')
        if os.path.isdir(os.path.join(runtime_dir, 'python')) or \
           os.path.isdir(os.path.join(runtime_dir, 'mariadb')):
            env['portable'] = True
            env['base_path'] = parent_dir
            env['app_path'] = app_dir
            env['runtime_path'] = runtime_dir
            env['data_path'] = os.path.join(parent_dir, 'data')
        else:
            # 纯开发模式
            env['base_path'] = app_dir
            env['app_path'] = app_dir
            env['data_path'] = os.path.join(app_dir, 'data')

    os.makedirs(env['data_path'], exist_ok=True)
    return env


ENV = detect_environment()
BASE_PATH = ENV['base_path']
APP_PATH = ENV['app_path']
DATA_DIR = ENV['data_path']
RUNTIME_DIR = ENV['runtime_path']
PORTABLE_MODE = ENV['portable']
ARCH = ENV['arch']

# ============ 服务器 ============
SERVER_HOST = '0.0.0.0'
SERVER_PORT = int(os.getenv('SERVER_PORT', '8089'))
DEBUG = os.getenv('DJANGO_DEBUG', '0') == '1'

# ============ 数据库 (MariaDB/MySQL) ============
DB_HOST = os.getenv('DB_HOST', '127.0.0.1')
DB_PORT = int(os.getenv('DB_PORT', '3307'))
DB_NAME = os.getenv('DB_NAME', 'smart_classroom')
DB_USER = os.getenv('DB_USER', 'root')
DB_PASSWORD = os.getenv('DB_PASSWORD', 'smartroom123')

# MariaDB路径：便携包用 runtime/mariadb，开发模式用 data/mariadb
if PORTABLE_MODE:
    MARIADB_PORTABLE_DIR = os.path.join(RUNTIME_DIR, 'mariadb')
else:
    MARIADB_PORTABLE_DIR = os.path.join(DATA_DIR, 'mariadb')

MARIADB_DATA_DIR = os.path.join(MARIADB_PORTABLE_DIR, 'data')
MARIADB_BIN_DIR = os.path.join(MARIADB_PORTABLE_DIR, 'bin')
MARIADB_USE_EMBEDDED = os.getenv('USE_EMBEDDED_DB', '1') == '1'

# ============ MQTT ============
MQTT_BROKER_HOST = '0.0.0.0'
MQTT_BROKER_PORT = 1883
MQTT_CLIENT_ID = 'smart_classroom_server'
MQTT_USERNAME = ''
MQTT_PASSWORD = ''

# MQTT主题定义
MQTT_TOPICS = {
    'SENSOR_OCCUPANCY': 'classroom/{classroom_id}/sensor/occupancy',
    'SENSOR_HEARTBEAT': 'classroom/{classroom_id}/sensor/heartbeat',
    'DEVICE_CMD': 'classroom/{classroom_id}/device/{device_type}/cmd',
    'DEVICE_STATUS': 'classroom/{classroom_id}/device/{device_type}/status',
    'ALERT_PUSH': 'classroom/{classroom_id}/alert',
}

# ============ 考勤规则 ============
ATTENDANCE_RULES = {
    'late_threshold_minutes': 10,
    'early_leave_threshold_minutes': 10,
}

# ============ 告警 ============
ALERT_CONFIG = {
    'idle_check_minutes': 30,
    'energy_alert_enabled': True,
}
