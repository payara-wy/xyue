# -*- coding: utf-8 -*-
"""Django URL路由 - 根配置"""

from django.urls import path, include, re_path
from django.conf import settings
from django.views.static import serve as static_serve
from django.http import HttpResponse
import os


def index_view(request):
    """返回前端SPA入口页面"""
    dist_dir = getattr(settings, 'FRONTEND_DIST', '')
    index_path = os.path.join(dist_dir, 'index.html')
    if os.path.isfile(index_path):
        with open(index_path, 'r', encoding='utf-8') as f:
            return HttpResponse(f.read(), content_type='text/html')
    return HttpResponse(
        '<h1>Smart Classroom</h1><p>Frontend not built. Run: cd frontend && npm run build</p>',
        content_type='text/html'
    )


urlpatterns = [
    # API路由
    path('api/', include('core.urls')),

    # SPA fallback - 所有非API路由返回index.html
    path('', index_view),
]

# 静态文件服务（生产模式下由Django服务）
dist_dir = getattr(settings, 'FRONTEND_DIST', '')
if os.path.isdir(dist_dir):
    urlpatterns += [
        re_path(r'^(?P<path>assets/.*|favicon\.ico|logo\.\w+)$',
                static_serve, {'document_root': dist_dir}),
    ]

# SPA fallback必须在最后
urlpatterns += [
    re_path(r'^(?!api/).*$', index_view),
]
