@echo off
chcp 65001 >nul 2>&1
setlocal EnableDelayedExpansion

REM ============================================================
REM  智能教室考勤系统 - 一键启动
REM  打开即运行：自动初始化 → 启动全部服务 → 创建桌面快捷方式
REM ============================================================

title 智能教室考勤系统
cd /d "%~dp0"

REM ── 静默模式检测 (通过快捷方式启动时自动静默) ──
set "SILENT=0"
if "%~1"=="--silent" set "SILENT=1"

if "!SILENT!"=="0" (
    echo.
    echo  ╔════════════════════════════════════════════════╗
    echo  ║   智能教室考勤与座位使用分析系统               ║
    echo  ║   Smart Classroom Attendance System  v1.0      ║
    echo  ╚════════════════════════════════════════════════╝
    echo.
)

REM ── 检测架构 ──
if /i "%PROCESSOR_ARCHITECTURE%"=="ARM64" (
    set "ARCH=arm64"
) else (
    set "ARCH=amd64"
)

REM ── 定位 Python ──
set "PYTHON="
if exist "%~dp0runtime\python\python.exe" (
    set "PYTHON=%~dp0runtime\python\python.exe"
) else (
    where python >nul 2>&1
    if !errorlevel! equ 0 (
        set "PYTHON=python"
    ) else (
        echo  [错误] 未找到 Python 运行时
        echo         请运行 build_portable.py 构建便携包
        pause
        exit /b 1
    )
)

REM ── 定位 MariaDB ──
set "MYSQLD="
set "USE_SQLITE=0"
if exist "%~dp0runtime\mariadb\bin\mysqld.exe" (
    set "MYSQLD=%~dp0runtime\mariadb\bin\mysqld.exe"
) else if exist "%~dp0data\mariadb\bin\mysqld.exe" (
    set "MYSQLD=%~dp0data\mariadb\bin\mysqld.exe"
) else (
    set "USE_SQLITE=1"
)

REM ============================================================
REM  自动初始化（首次运行时静默完成）
REM ============================================================
if not exist "%~dp0data\.initialized" (
    if "!SILENT!"=="0" echo  [INIT] 首次运行，正在初始化系统...

    REM 创建数据目录
    if not exist "%~dp0data" mkdir "%~dp0data"

    REM 初始化 MariaDB 数据目录
    if defined MYSQLD (
        set "MDB_DIR=%~dp0runtime\mariadb"
        if not exist "!MDB_DIR!\bin" set "MDB_DIR=%~dp0data\mariadb"
        if not exist "!MDB_DIR!\data\mysql" (
            "!MYSQLD!" --initialize-insecure --datadir="!MDB_DIR!\data" >nul 2>&1
        )
    )

    REM Django 迁移
    set "DJANGO_SETTINGS_MODULE=config.django_settings"
    pushd "%~dp0app"
    "!PYTHON!" manage.py migrate --run-syncdb --verbosity=0 >nul 2>&1
    if !errorlevel! neq 0 (
        set "USE_SQLITE=1"
        "!PYTHON!" manage.py migrate --run-syncdb --verbosity=0 >nul 2>&1
    )
    popd

    REM 标记初始化完成
    echo %date% %time% > "%~dp0data\.initialized"
    if "!SILENT!"=="0" echo  [OK]   初始化完成
)

REM ============================================================
REM  创建桌面快捷方式（仅首次）
REM ============================================================
if not exist "%~dp0data\.shortcut_created" (
    if "!SILENT!"=="0" echo  [LINK] 正在创建桌面快捷方式...
    call :create_shortcut
    echo 1 > "%~dp0data\.shortcut_created"
)

REM ============================================================
REM  设置开机自启动（仅首次询问）
REM ============================================================
if not exist "%~dp0data\.autostart_configured" (
    if "!SILENT!"=="0" (
        echo.
        set /p "AUTOSTART=  是否开机自动启动? (Y/N): "
    ) else (
        set "AUTOSTART=N"
    )
    if /i "!AUTOSTART!"=="Y" (
        call :enable_autostart
        if "!SILENT!"=="0" echo  [OK]   已设置开机自启动
    )
    echo configured > "%~dp0data\.autostart_configured"
)

REM ============================================================
REM  启动 MariaDB
REM ============================================================
if "!USE_SQLITE!"=="0" (
    if "!SILENT!"=="0" echo  [1/3] 启动 MariaDB ...

    set "MDB_DIR=%~dp0runtime\mariadb"
    if not exist "!MDB_DIR!\bin" set "MDB_DIR=%~dp0data\mariadb"

    REM 检查是否已在运行
    "!PYTHON!" -c "import socket;s=socket.socket();s.settimeout(1);s.connect(('127.0.0.1',3307));s.close()" >nul 2>&1
    if !errorlevel! neq 0 (
        start "" /B "!MDB_DIR!\bin\mysqld.exe" ^
            --port=3307 --datadir="!MDB_DIR!\data" ^
            --bind-address=127.0.0.1 --character-set-server=utf8mb4 ^
            --collation-server=utf8mb4_unicode_ci --skip-grant-tables ^
            --console 2>nul

        set "MDB_READY=0"
        for /L %%i in (1,1,30) do (
            if !MDB_READY! equ 0 (
                "!PYTHON!" -c "import socket;s=socket.socket();s.settimeout(1);s.connect(('127.0.0.1',3307));s.close()" >nul 2>&1
                if !errorlevel! equ 0 ( set "MDB_READY=1" ) else ( timeout /t 1 /nobreak >nul )
            )
        )
        if !MDB_READY! equ 0 (
            if "!SILENT!"=="0" echo  [WARN] MariaDB 超时，回退 SQLite
            set "USE_SQLITE=1"
        ) else (
            if "!SILENT!"=="0" echo  [OK]   MariaDB 就绪
        )
    ) else (
        if "!SILENT!"=="0" echo  [OK]   MariaDB 已在运行
    )
) else (
    if "!SILENT!"=="0" echo  [1/3] 数据库: SQLite 模式
)

REM ============================================================
REM  启动应用服务
REM ============================================================
if "!SILENT!"=="0" echo  [2/3] 启动 应用服务 ...
set "DJANGO_SETTINGS_MODULE=config.django_settings"

REM 检查是否已在运行
"!PYTHON!" -c "import urllib.request;urllib.request.urlopen('http://127.0.0.1:8089/api/classrooms/',timeout=2)" >nul 2>&1
if !errorlevel! neq 0 (
    pushd "%~dp0app"
    start "SmartClassroom-Server" /MIN "!PYTHON!" main.py
    popd
)

REM 等待就绪
set "APP_READY=0"
for /L %%i in (1,1,45) do (
    if !APP_READY! equ 0 (
        "!PYTHON!" -c "import urllib.request;urllib.request.urlopen('http://127.0.0.1:8089/api/classrooms/',timeout=2)" >nul 2>&1
        if !errorlevel! equ 0 ( set "APP_READY=1" ) else ( timeout /t 1 /nobreak >nul )
    )
)

REM ============================================================
REM  打开浏览器 + 系统通知
REM ============================================================
if "!SILENT!"=="0" echo  [3/3] 打开 浏览器 ...
start "" "http://localhost:8089"

REM Windows Toast 通知
powershell -WindowStyle Hidden -Command "[System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms')|Out-Null;$n=New-Object System.Windows.Forms.NotifyIcon;$n.Icon=[System.Drawing.SystemIcons]::Information;$n.Visible=$true;$n.ShowBalloonTip(5000,'智能教室系统','系统已启动 - http://localhost:8089',[System.Windows.Forms.ToolTipIcon]::Info);Start-Sleep 6;$n.Dispose()" >nul 2>&1

echo.
echo  ╔════════════════════════════════════════════════╗
echo  ║   ✓ 系统已启动                                 ║
echo  ║                                                ║
echo  ║   Web界面:  http://localhost:8089              ║
echo  ║   MQTT:     mqtt://localhost:1883              ║
echo  ║                                                ║
echo  ║   桌面快捷方式已创建                           ║
echo  ║   关闭此窗口 或 双击 stop.bat 停止服务         ║
echo  ╚════════════════════════════════════════════════╝
echo.

REM ── 守护循环 ──
:keepalive
timeout /t 10 /nobreak >nul
"!PYTHON!" -c "import urllib.request;urllib.request.urlopen('http://127.0.0.1:8089/api/classrooms/',timeout=3)" >nul 2>&1
if !errorlevel! neq 0 (
    echo  [AUTO] 检测到服务停止，正在重启...
    pushd "%~dp0app"
    start "SmartClassroom-Server" /MIN "!PYTHON!" main.py
    popd
)
goto keepalive

REM ============================================================
REM  函数：创建桌面快捷方式
REM ============================================================
:create_shortcut
set "DESKTOP=%USERPROFILE%\Desktop"
set "LNK_PATH=!DESKTOP!\智能教室考勤系统.lnk"
set "TARGET=%~dp0run.bat"
set "ICON_PATH=%~dp0assets\icon.ico"

REM 用VBS创建快捷方式
set "VBS=%TEMP%\sc_shortcut.vbs"
(
    echo Set WshShell = CreateObject^("WScript.Shell"^)
    echo Set oShortcut = WshShell.CreateShortcut^("!LNK_PATH!"^)
    echo oShortcut.TargetPath = "!TARGET!"
    echo oShortcut.WorkingDirectory = "%~dp0"
    echo oShortcut.Arguments = "--silent"
    if exist "!ICON_PATH!" (
        echo oShortcut.IconLocation = "!ICON_PATH!,0"
    ) else (
        echo oShortcut.IconLocation = "%%SystemRoot%%\System32\shell32.dll,176"
    )
    echo oShortcut.Description = "智能教室考勤与座位使用分析系统"
    echo oShortcut.WindowStyle = 7
    echo oShortcut.Save
) > "!VBS!"
cscript //nologo "!VBS!" >nul 2>&1
del "!VBS!" >nul 2>&1

REM 同时创建停止服务的快捷方式
set "STOP_LNK=!DESKTOP!\停止教室系统.lnk"
set "VBS2=%TEMP%\sc_stop.vbs"
(
    echo Set WshShell = CreateObject^("WScript.Shell"^)
    echo Set oShortcut = WshShell.CreateShortcut^("!STOP_LNK!"^)
    echo oShortcut.TargetPath = "%~dp0stop.bat"
    echo oShortcut.WorkingDirectory = "%~dp0"
    echo oShortcut.IconLocation = "%%SystemRoot%%\System32\shell32.dll,28"
    echo oShortcut.Description = "停止智能教室所有服务"
    echo oShortcut.Save
) > "!VBS2!"
cscript //nologo "!VBS2!" >nul 2>&1
del "!VBS2!" >nul 2>&1
exit /b 0

REM ============================================================
REM  函数：设置开机自启动
REM ============================================================
:enable_autostart
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" ^
    /v "SmartClassroom" /t REG_SZ ^
    /d "\"%~dp0run.bat\" --silent" /f >nul 2>&1
exit /b 0

endlocal
